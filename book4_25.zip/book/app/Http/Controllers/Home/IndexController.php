<?php

namespace App\Http\Controllers\Home;

use App\Model\Comment;
use App\Model\Novel;
use Illuminate\Http\Request;
use App\Model\Cate;
use App\Http\Controllers\Controller;
use App\Model\User;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use App\Model\Poster;
class IndexController extends Controller
{
    //
    
    
    public function index( ){
             $cate=Cate::all();
             $paihang=Novel::orderBy('favorate','desc') -> take(7)-> get();
             
             $data=Novel::where('cate', '玄幻')->orderBy(\DB::raw('RAND()')) ->take(12) ->get();           
             $zhaiwen=Novel::where('cate', '宅文')->orderBy(\DB::raw('RAND()')) ->take(12) ->get();
             $chuanyue=Novel::where('cate', '穿越')->orderBy(\DB::raw('RAND()')) ->take(12) ->get();
             $girl=Novel::where('cate', '女生')->orderBy(\DB::raw('RAND()')) ->take(12) ->get();
             $boy=Novel::where('cate', '男生')->orderBy(\DB::raw('RAND()')) ->take(12) ->get();
             
             $xuanyi=Novel::where('cate','悬疑')->orderBy('favorate','desc') -> take(10)-> get();
             $jiakong=Novel::where('cate','架空')->orderBy('favorate','desc') -> take(10)-> get();
             $xiandai=Novel::where('cate','现代')->orderBy('favorate','desc') -> take(10)-> get();
             $suiji=Novel::orderBy(\DB::raw('RAND()')) ->take(6) ->get();    
             $poster=Poster::where('p_id',0)->orderBy('replynum','desc') -> take(10)-> get();
             return view('home.index')->with('cate', $cate)->with('data',$data)->with('paihang',$paihang)->with('zhaiwen',$zhaiwen)->with('boy',$boy)->with('girl',$girl)
                     ->with('chuanyue',$chuanyue)->with('xuanyi',$xuanyi)->with('jiakong',$jiakong)->with('xiandai',$xiandai)->with('poster',$poster)->with('suiji',$suiji);
    
    
    
    }
      public function in_list($catename){
         
             $name=Cate::where('enname',$catename)->first()->name;
             $data=Novel::where('cate',$name)->paginate(40);
             $chapternum=[];
             foreach($data as $v){
             $chapternum[]= count(explode('@', $v->chapter))-1;     
             }
             if(!$chapternum){
                 
                 $chapternum=[];
             }
               $cate=Cate::all();
               
             $xuanyi=Novel::where('cate','悬疑')->orderBy('favorate','desc') -> take(10)-> get();
             $jiakong=Novel::where('cate','架空')->orderBy('favorate','desc') -> take(10)-> get();
             $xiandai=Novel::where('cate','现代')->orderBy('favorate','desc') -> take(10)-> get();
             $poster=Poster::where('p_id',0)->orderBy('replynum','desc') -> take(10)-> get();
           return view('home.list')->with('cate_name','shouye')->with('cate', $cate)->with('data',$data)->with('chapternum',$chapternum)
                   ->with('xuanyi',$xuanyi)->with('jiakong',$jiakong)->with('xiandai',$xiandai)->with('poster',$poster);
    }
    
      public function in_content(Request $request){
          $id=$request->get('id');
          $data=Novel::find($id);
          $comment=Comment::where('book_id',$id)->orderBy('date', 'desc')->paginate(10);
          $data->chapter= explode('@', $data->chapter);
          $data->chapter= array_filter( $data->chapter);
          $count=count(  $data->chapter);
       
          $cate=Cate::all(); 
          $tuijian=Novel::where('cate', $data->cate)->orderBy(\DB::raw('RAND()')) ->take(4) ->get();   
     
          if(session('user')){
              $name=session('user_name');      
              $user=User::where('name',$name)->first(); 
              $array= explode("@",$user->favorate );     
              if(in_array($id, $array)){
                  $shoucang='yishoucang';
                  } else {
                      $shoucang='weicang';
                  }
                  
               }else{
                  $shoucang='weicang';
               }
           return view('home.content')->with('cate', $cate)->with('data',$data)->with('comment',$comment)->with('shoucang',$shoucang)->with('tuijian',$tuijian)->with('count',$count); 
    }
      public function search(Request $request){
          
          $num=10;
          $input= Input::except('_token');
          $keyword=$input['keyword'];
//          $data1=Novel:: where('title','like','%'.$keyword.'%')->get();
          $res=Novel:: where('title','like','%'.$keyword.'%')->paginate($num);
         
           if($request->get('zuopin'))  {
               
             $res=Novel:: where('title','like','%'.$keyword.'%')->paginate($num);
           }
//            if($request->get('zuozhe'))  {
//               
//              $res=Novel:: where('author','like','%'.$keyword.'%')->get() ; 
//           }
          
          
             
          $cate=Cate::all();
          $count=count($res);
//          $page=ceil($count);
    return view('home.search')->with('res', $res)->with('cate',$cate)
            ->with('count',$count);      
    }
    public function chapter(Request $request){
        
 
        
        $id=$request->get('id');
        
        $chapter=$request->get('chapter');
        $data=Novel::find($id);
        
        $array=explode("@", $data->chapter);
        $count=count($array);//计算章节数
        if($chapter<1 || $chapter>=$count){//如果传进来的章节数不符合要求  
                   
                   return redirect()->back();
               }       
        $chaptername=  $array[$chapter];
        $date=$data->date;
        $path="novel/".$date.'/'.$chapter.'.txt';
        if(file_exists($path)){
      
        $txt= file_get_contents($path);
          }
          else{
        
          $txt="无";
        } 
         
//        view()->share('cate', '$cate');
    return view('home.chapter')->with('txt',$txt)->with('chapter',$chapter)->with('data',$data)->with('chaptername',$chaptername);     
    }
    
    public function tainfo($nickname){
        
     $user=User::where('nickname',$nickname)->first();
     $array= explode("@",$user->favorate );
      $data=Novel::find($array);   

        return view('home.tainfo')->with('data',$data)->with('nickname',$nickname);
        
    }
     public function tabook($nickname){
        
        $data=Novel::where('author',"$nickname")->get();
 
        return view('home.tabook')->with('data',$data)->with('nickname',$nickname);
        
    }
    
}
