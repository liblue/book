<?php

namespace App\Http\Controllers\Home;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Model\User;
class LoginController extends Controller
{
    //
    public function login(){
        
       if(  $input = Input::except('_token')){
        
           
              $url=$input['url'];
          if( !preg_match('/^\d+$/i', $input['tel'])){ //判断是否数字开头 
            $user=User::where('nickname', $input['tel'])->first();
          }else{
            $user=User::where('tel', $input['tel'])->first();
          }
             $input['password']=bcrypt($input['password']);
         
     
          if(!$user){    
              return redirect()->back()->withInput()->withErrors('查无此人'); 
          }else if(Hash::check($input['password'],$user->password)){
              return redirect()->back()->withInput()->withErrors('用户名或密码错误！'); 
          }else{
           session(['user'=>$user]);
           session(['user_name'=>$user->name]);
           session(['user_nickname'=>$user->nickname]);
           session(['user_favorates'=>$user->favorates]);
           session()->save();
           return redirect('/');   
              
          }
        
          
          
          
         }else{
           $url=url()->previous();
           return view("home/login")->with('url',$url);
            }
       
       
}
    public function logout(Request $request){

       $url=url()->previous();
       $request->session()->flush();
        return redirect($url);
 
        
    }
}
