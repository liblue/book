<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    //
    
     public function __construct(){  
          
          if(!session('user')){
              return view('admin/admin_login');     
          }
          else
          {
              return redirect('houtai');
          }
            
        }  
    
    
}
