<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Support\Facades\Input;
use App\Model\Admin;



class LoginController extends Controller
{
    //
    public function index(){

     return view('admin/admin_login');        
    }
    
    public function login(){
//    $this->middleware('auth');
        
       $input = Input::all();
//       $user = Admin::where('name',$input['username'])->first();
       session(['user'=>$input['username']]);
     
       return redirect('houtai');

    
    
}
public function logout(Request $request){
    
       $request->session()->flush();
         return redirect('admin_log');
}





  }
