<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Model\Poster;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PosterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        
      
         $num=5;
         $re=Poster::where('p_id',0)->get();
         $fenye=ceil(count($re)/$num);
         
         $data=Poster::where('p_id',0)->paginate($num);
     
         if($request->get('page')){//分页传参
           $page=$request->get('page');
           }else{
          $page=1;
           }
        
         return view('admin/poster_list',compact('data',$data))->with('fenye',$fenye)->with('page',$page);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
        public function delete(Request $request)
    {
          $id=  $request->input('data');
     
         
         Poster::destroy($id);
         
         
        return $id;
        
        
        
    }
}
