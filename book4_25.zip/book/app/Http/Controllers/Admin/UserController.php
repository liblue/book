<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\Model\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
      
        $num=5;
        $re=User::get();
        $fenye=ceil(count($re)/$num);
        $data=User::paginate($num);
        if($request->get('page')){//分页传参
          $page=$request->get('page');
         }else{
          $page=1;
         }
           
        if($request->get('souname')){

            $souname=$request->get('souname');
            $data= User::where('nickname',$souname)->first();
         return view('admin/user_list',compact('data',$data));    
           }
         return view('admin/user_list',compact('data',$data))->with('fenye',$fenye)->with('page',$page);
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($data)
    {
        //
        
        $data=[
            
            "status"=>1,
            
            
        ];
        return data;
        
        
        
    }
        
    
    public function delete(Request $request)
    {
        //
         $id=  $request->input('data');
         

         
      User::destroy($id);
        return $id;
    }
     public function info()
    {
        //
       
        return view('admin/user_info');
    }
     public function search(Request $request)
    {
         
         
         $input = $request->input();
         $nickname= $input['username'];
         
        if($input['username']==null){
        
             return redirect('admin/user');
         }
         $data= User::where('nickname',$nickname)->first();
         return view('admin/user_sousuo')->with('data',$data);
    }
   
    
 
}
