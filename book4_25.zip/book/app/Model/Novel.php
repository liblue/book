<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Novel extends Model
{
    //
    
    protected $table="novels";
    protected $primaryKey='id';
    public $timestamps=false;
     protected $guarded=[];
}
