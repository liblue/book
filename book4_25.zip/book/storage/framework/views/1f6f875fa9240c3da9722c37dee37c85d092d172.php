<html>
    
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>KIT ADMIN</title>
    <link rel="stylesheet" href="http://localhost/novel/public/admin/plugins/layui/css/layui.css" media="all">
    <link rel="stylesheet" type="text/css" href="http://localhost/novel/public/admin/build/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://localhost/novel/public/admin/build/css/app.css" media="all">


<link id="layuicss-buildcssnprogresscss" rel="stylesheet" href="./build/css/nprogress.css" media="all">
<link id="layuicss-layer" rel="stylesheet" href="http://localhost/novel/public/admin/plugins/layui/css/modules/layer/default/layer.css?v=3.0.3" media="all">
<link id="layuicss-buildcssmessagecss" rel="stylesheet" href="./build/css/message.css" media="all"></head>
<body>

                
                <div class="layui-layout layui-layout-admin kit-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">KIT ADMIN</div>
            <div class="layui-logo kit-logo-mobile">K</div>
            <ul class="layui-nav layui-layout-left kit-nav">
                <li class="layui-nav-item"><a href="http://localhost/novel/public/controller">控制台</a></li>
                <li class="layui-nav-item"><a href="javascript:;">商品管理</a></li>
                <li class="layui-nav-item"><a href="javascript:;" id="pay"><i class="fa fa-gratipay" aria-hidden="true"></i> 捐赠我</a></li>
                <li class="layui-nav-item">
                    <a href="javascript:;">其它系统<span class="layui-nav-more"></span></a>
                    <dl class="layui-nav-child">
                        <dd><a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="导航栏" kit-target="" data-id="3"><i class="layui-icon"></i><span> 导航栏</span></a></dd>
                        <dd><a href="javascript:;">消息管理</a></dd>
                        <dd><a href="javascript:;">授权管理</a></dd>
                    </dl>
                </li>
            <span class="layui-nav-bar" style="left: 102px; top: 45px; width: 0px; opacity: 0;"></span></ul>
            <ul class="layui-nav layui-layout-right kit-nav">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://m.zhengjinfan.cn/images/0.jpg" class="layui-nav-img"> Van
                    <span class="layui-nav-more"></span></a>
                    <dl class="layui-nav-child">
                        <dd><a href="javascript:;">基本资料</a></dd>
                        <dd><a href="javascript:;">安全设置</a></dd>
                    </dl>
                </li>
                <li class="layui-nav-item"><a href="javascript:;"><i class="fa fa-sign-out" aria-hidden="true"></i> 注销</a></li>
            <span class="layui-nav-bar" style="left: 105.766px; top: 45px; width: 0px; opacity: 0;"></span></ul>
        </div>
 <div class="layui-side layui-bg-black kit-side">
            <div class="layui-side-scroll">
                <div class="kit-side-fold"><i class="fa fa-navicon" aria-hidden="true"></i></div>
              
                <ul class="layui-nav layui-nav-tree" lay-filter="kitNavbar" kit-navbar="">
                    <li class="layui-nav-item">
                        <a class="" href="javascript:;"><i class="fa fa-plug" aria-hidden="true"></i><span> 基本元素</span><span class="layui-nav-more"></span></a>
                        <dl class="layui-nav-child">
                            
                             <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="导航栏" kit-target="" data-id="3"><i class="layui-icon"></i><span> 导航栏</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" kit-target="" data-options="{url:'https://www.baidu.com',icon:'',title:'百度一下',id:'5'}"><i class="layui-icon"></i><span> 百度一下</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="导航栏" kit-target="" data-id="3"><i class="layui-icon"></i><span> 导航栏</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" data-url="http://localhost/novel/public/admin_list" data-icon="" data-title="列表四" kit-target="" data-id="4"><i class="layui-icon"></i><span> 列表四</span></a>
                            </dd>
                            <dd>
                                <a href="javascript:;" kit-target="" data-options="{url:'https://www.baidu.com',icon:'',title:'百度一下',id:'5'}"><i class="layui-icon"></i><span> 百度一下</span></a>
                            </dd>
                        </dl>
                    </li>
                     <li class="layui-nav-item layui-nav-itemed">
                        <a href="javascript:;"><i class="fa fa-plug" aria-hidden="true"></i><span> 组件</span><span class="layui-nav-more"></span></a>
                        <dl class="layui-nav-child">
                            <dd><a href="javascript:;" kit-target="" data-options="{url:'navbar.html',icon:'',title:'Navbar',id:'6'}"><i class="layui-icon"></i><span> Navbar</span></a></dd>
                            <dd><a href="javascript:;" kit-target="" data-options="{url:'tab.html',icon:'',title:'TAB',id:'7'}"><i class="layui-icon"></i><span> Tab</span></a></dd>
                            <dd><a href="javascript:;" kit-target="" data-options="{url:'onelevel.html',icon:'',title:'OneLevel',id:'50'}"><i class="layui-icon"></i><span> OneLevel</span></a></dd>
                            <dd><a href="javascript:;" kit-target="" data-options="{url:'app.html',icon:'',title:'App',id:'8'}"><i class="layui-icon"></i><span> app.js主入口</span></a></dd>
                        </dl>
                    </li>
                     <li class="layui-nav-item layui-nav-itemed">
                        <a href="javascript:;"><i class="fa fa-plug" aria-hidden="true"></i><span> 用户管理</span><span class="layui-nav-more"></span></a>
                        <dl class="layui-nav-child">
                            <dd><a href="javascript:;" kit-target="" data-options="{url:&quot;http://localhost/novel/public/roof&quot;,icon:&quot;&quot;,title:&quot;Navbar&quot;,id:&quot;6&quot;}"><i class="layui-icon"></i><span> Navbar</span></a></dd>

                            <dd><a href="javascript:;" kit-target="" data-options="{url:&quot;http://localhost/novel/public/roof&quot;,icon:&quot;&quot;,title:&quot;TAB&quot;,id:&quot;7&quot;}"><i class="layui-icon"></i><span> Tab</span></a></dd>
                            <dd><a href="javascript:;" kit-target="" data-options="{url:&quot;http://localhost/novel/public/one&quot;,icon:&quot;&quot;,title:&quot;OneLevel&quot;,id:&quot;50&quot;}"><i class="layui-icon"></i><span> OneLevel</span></a></dd>

                            <dd><a href="javascript:;" kit-target="" data-options="{url:'onelevel.html',icon:'',title:'OneLevel',id:'50'}"><i class="layui-icon"></i><span> OneLevel</span></a></dd>
                            <dd><a href="javascript:;" kit-target="" data-options="{url:'app.html',icon:'',title:'App',id:'8'}"><i class="layui-icon"></i><span> app.js主入口</span></a></dd>
                        </dl>
                    </li>
                    <li class="layui-nav-item">
                        <a href="javascript:;" data-url="/components/table/table.html" data-name="table" kit-loader=""><i class="fa fa-plug" aria-hidden="true"></i><span> 表格(page)</span></a>
                    </li>
                    <li class="layui-nav-item">
                        <a href="javascript:;" data-url="/views/form.html" data-name="form" kit-loader=""><i class="fa fa-plug" aria-hidden="true"></i><span> 表单(page)</span></a>
                    </li>
                <span class="layui-nav-bar"></span></ul>
            </div>
        </div>
     
     
     <div class="layui-body" id="container">
            <div class="layui-tab layui-tab-card kit-tab" lay-filter="kitTab">
                <ul class="layui-tab-title">
            
                  
<!--                    <li class="" lay-id="6"><i class="layui-icon"></i>&nbsp;Navbar<i class="layui-icon layui-unselect layui-tab-close">ဆ</i></li>
                    <li class="" lay-id="7"><i class="layui-icon"></i>&nbsp;TAB<i class="layui-icon layui-unselect layui-tab-close">ဆ</i></li>
                    <li class="" lay-id="8"><i class="layui-icon"></i>&nbsp;App<i class="layui-icon layui-unselect layui-tab-close">ဆ</i></li>
                    <li class="layui-this" lay-id="4"><i class="layui-icon"></i>&nbsp;列表四<i class="layui-icon layui-unselect layui-tab-close">ဆ</i></li>-->
                </ul>
                    <div class="kit-tab-tool">操作&nbsp;<i class="fa fa-caret-down"></i></div><div class="kit-tab-tool-body layui-anim layui-anim-upbit"><ul>
                            <li class="kit-item" data-target="refresh">刷新当前选项卡</li><li class="kit-line"></li>
                            <li class="kit-item" data-target="closeCurrent">关闭当前选项卡</li><li class="kit-item" data-target="closeOther">关闭其他选项卡</li>
                            <li class="kit-line"></li><li class="kit-item" data-target="closeAll">关闭所有选项卡</li>
                        </ul></div>
                    <div class="layui-tab-content">
                        <!--<div class="layui-tab-item" lay-item-id="-1"><iframe src="main.html" style="height: 820px;"></iframe></div>-->
                        <div class="layui-tab-item" lay-item-id="50"><iframe src="onelevel.html" style="height: 820px;"></iframe></div>
                        <div class="layui-tab-item" lay-item-id="6"><iframe src="navbar.html" style="height: 820px;"></iframe></div>
                        <div class="layui-tab-item" lay-item-id="7"><iframe src="tab.html" style="height: 820px;"></iframe></div>
                        <div class="layui-tab-item" lay-item-id="8"><iframe src="app.html" style="height: 820px;"></iframe></div>
                        <div class="layui-tab-item layui-show" lay-item-id="4"><iframe src="http://localhost/luntan/public/admin_list" style="height: 820px;"></iframe>
                        </div>
                    </div>
            </div>
        </div>




    <script src="http://localhost/novel/public/admin/plugins/layui/layui.js"></script>
        <script src="http://localhost/novel/public/admin/plugins/layui/xadmin.js"></script>

    <script src="http://localhost/novel/public/admin/build/js/app.js"></script>
    <script src="http://localhost/novel/public/admin/build/js/loader.js"></script>
    <script src="http://localhost/novel/public/admin/build/js/message.js"></script>
    <script src="http://localhost/novel/public/admin/build/js/navbar.js"></script>
    <script src="http://localhost/novel/public/admin/build/js/nprogress.js"></script>
    <script src="http://localhost/novel/public/admin/build/js/onelever.js"></script>
    <script src="http://localhost/novel/public/admin/build/js/pjax.js"></script>
    <script src="http://localhost/novel/public/admin/build/js/tab.js"></script>
    
    


    <script>
        var message;
        layui.config({
            base: 'admin/build/js/'
        }).use(['app', 'message'], function() {
            var app = layui.app,
                $ = layui.jquery,
                layer = layui.layer;
            //将message设置为全局以便子页面调用
            message = layui.message;
            //主入口
            app.set({
                type: 'iframe'
            }).init();
            $('#pay').on('click', function() {
                layer.open({
                    title: false,
                    type: 1,
                    content: '<img src="http://localhost/novel/public/admin/build/images/pay.png" />',
                    area: ['500px', '250px'],
                    shadeClose: true
                });
            });
        });
    </script>


</div></body>
</html>