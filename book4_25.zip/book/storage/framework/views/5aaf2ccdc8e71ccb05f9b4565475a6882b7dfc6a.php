    


<?php $__env->startSection('content'); ?>   
    
<div class="container">
    <div class="ly-wrap">

        <div class="ly-main">
            
        
            <!--mod-box start-->
                       <div class="mod-box ly-mt60">
                <div class="mod-tit1 ly-mr30">
					<h3><i></i>最近更新小说</h3>
                    <a class="ly-fr" href="https://www.hbooker.com/book_list" target="_blank">查看更多 &gt;</a>
                </div>

                <div class="mod-body">
                    <div class="book-list-table-wrap">
                        <table class="ly-mt30 book-list-table" width="100%">
                            <tr>
                                <th><span>序号</span></th>
                             
                                <th><span>小说书名</span></th>
                                <th><span>章节数</span></th>
                                <th><span>小说作者</span></th>
                                <th>更新时间</th>
                            </tr>
                            
                            <?php foreach($data as $k=>$v): ?>
                                                                                                <tr>
                                        <td><p class="code center"><?php echo e($k+1); ?></p></td>
                                        
                                        <td><p class="name"><a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" title="<?php echo e($v->title); ?>" target="_blank"><?php echo e($v->title); ?></a></p></td>
                                        <td><p class="num center"><?php echo e($chapternum[$k]); ?></p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/198347" target="_blank"><?php echo e($v->author); ?></a></p></td>
                                        <td><p class="date center"><?php echo e(date('Y-m-d',$v->date)); ?></p></td>
                                    </tr>
                                    
                                    <?php endforeach; ?>
                                                                   
                                                                                    </table>
                        
                        
                        <?php echo $data->links(); ?>

                    </div>
                </div>
            </div>
                        <!--mod-box end-->
        </div>
        <div class="ly-side index-side">
            <!-- 公告 begin -->
            <div class="big-event">
                                                                                        <div><a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://www.hbooker.com/resources/imagesactivity/zhengwen_nov_banner.jpg" alt="活动"></a></div>
                                                                                                <div><a href="https://www.hbooker.com/index/fuli" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_notice/20170601112204377.jpg" alt=""></a></div>
                                                                        </div>
            <!-- 公告 end -->
            <div class="recomm-tit ly-mt30">
                <h4>精选荣誉榜单</h4>
            </div>

                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">热帖</div>
                    <div class="sub-tit"><i>TOP 10</i> 精挑细选</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                       <ul>
                    
                               <?php foreach($poster as $k=>$v): ?>
                           
                                                    <li  class="top2">
                                     <a href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                    <span class="num">0.8万</span><i class="icon-top"><?php echo e($k+1); ?></i><?php echo e($v->title); ?>    </a>
                            </li>
                            
                             <?php endforeach; ?>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">现代强推</div>
                    <div class="sub-tit"><i>TOP 10</i></div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <?php foreach($xiandai as $k=>$v): ?>
                        <?php if($k<3): ?>
                        
                             <li class="top2">
                                 <?php else: ?>
                                  <li>
                                      <?php endif; ?>
                                <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <span class="num"><?php echo e($v->favorate); ?></span><i class="icon-top icon-top2"><?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                            </li>
                              <?php endforeach; ?>  
                              
                                                    
                                                   
                                            </ul>
                </div>
                                <!--recomm-list end-->
              
                            <!--recomm-list start-->
                                
                                <!--recomm-list end-->
              
                            <!--recomm-list start-->
                               <div class="recomm-list">
                    <div class="tit">架空强推</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                       <?php foreach($jiakong as $k=>$v): ?>
                                                     <?php if($k<3): ?>
                        
                             <li class="top2">
                                 <?php else: ?>
                                  <li>
                                      <?php endif; ?>
                                <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <span class="num"><?php echo e($v->favorate); ?></span><i class="icon-top icon-top2"><?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                            </li>
                            <?php endforeach; ?>  
                                                    
                                            
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">悬疑强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>

                    <ul>
                                     <?php foreach($xuanyi as $k=>$v): ?>
                                                     <?php if($k<3): ?>
                        
                             <li class="top2">
                                 <?php else: ?>
                                  <li>
                                      <?php endif; ?>
                                <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <span class="num"><?php echo e($v->favorate); ?></span><i class="icon-top icon-top2"><?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                            </li>
                            <?php endforeach; ?>  
                                                     
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            
                            <!--recomm-list start-->
                                <!--recomm-list end-->
                    </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
    
    
    
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>