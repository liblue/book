<?php $__env->startSection('content'); ?>

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="<?php echo e(url('tainfo')); ?>/<?php echo e($nickname); ?>" >TA的书架</a></li>
                    <li><a href="javascript:" class="selected">TA的作品</a></li>
                  
                   
                </ul>
            </div>
            
        </div>
      
        <div class="ly-fl bookshelf" style="width: 80%">
     
           

                
                <table class="layui-table">

  <thead>
    <tr>
        <th><input type="checkbox" class="selectAll" id="selectAll" name="choice"></th>
         <th>封面</th>
      <th>书名</th>
     
      <th>创作时间</th>
      
       <th>状态</th>
       <th>收藏</th>
     
    </tr> 
  </thead>
  <tbody>
      
      <?php foreach($data as $k=>$v): ?>
    <tr>
        <td  align="left"> <input type="checkbox" class="subSelect" name="choice" value="<?php echo e($v->date); ?>"></td>
       <input type="hidden" value="<?php echo e($v->date); ?>" name="date" >
              <td><img src="<?php echo e(asset($v->pic_addr)); ?>" width="50px" height="50px"/></td>
              <td><a  href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>"><?php echo e($v->title); ?></a></td>
      <td><?php echo e(date("Y-m-d",$v->date)); ?></td>
     
      <td>
          <?php if($v->status===1): ?>
          连载中
      <?php else: ?>
      已完结
      <?php endif; ?>
      </td>
        <td><?php echo e($v->favorate); ?></td>
     
    </tr>
       <?php endforeach; ?>


  </tbody>
     
</table>
             
       
        </div>

        <!--我的关注,我的粉丝 start-->
       
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>

<script>
//      $("document").ready(function(){
// $("#selectAll").click(function(){   
//  if(this.checked){   
//   $("input[name='choice']").each(function(){this.checked=true;});
//   
//  }else{   
//   $("input[name='choice']").each(function(){this.checked=false;});   
//
//  }   
// });}
//   

   
    function fun(){
    
      $('input:checkbox[name=choice]:checked').each(function(i){
        date = $(this).val();
//        alert(date);
         $.post("<?php echo e(url('author/delete')); ?>",{'_token':'<?php echo e(csrf_token()); ?>','date':date},function(data){
            if(data.status == 0){
//                alert(data.msg);
            location.reload(true)
            }
            else{
                alert('no');
            }
    });
      });
      
//       location.href = location.href;
    }
    </script>

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>