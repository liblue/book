<?php $__env->startSection('content'); ?>   
    
<div class="container bbs-painter">
    <div class="ly-wrap">

      
  <div class="breakcrumb">
            <a href="<?php echo e(url('/')); ?>">首页</a> &gt;
            论坛</a>
          
          
        </div>
  

        <div class="ly-mt45 clearfix">
            <div class="ly-main">
                <div class="bbs-table">
                    <div class="bbs-publish">
                    	                        <a href="<?php echo e('forum/create'); ?>" class="btn btn-blue">发帖</a>
                    </div>
                    <table class="book-list-table ly-mt20" width="100%">
                        <tr>
                            <th colspan="4">
                                <span class="bname">综合讨论区</span>
                            </th>
                        </tr>
                        <tr>
                            <th width="600">
									<span class="type">
                                                                            
                                                                            <?php if($type==1): ?>
										<a href="<?php echo e(url('forum')); ?>?quanbu=1" class="selected" >全部</a>
										<a href="<?php echo e(url('forum')); ?>?new=2"  >最新</a>
										<a href="<?php echo e(url('forum')); ?>?hot=3"  >热门</a>
                                                                                <?php elseif($type==2): ?>
                                                                                <a href="<?php echo e(url('forum')); ?>?quanbu=1"  >全部</a>
										<a href="<?php echo e(url('forum')); ?>?new=2"  class="selected" >最新</a>
										<a href="<?php echo e(url('forum')); ?>?hot=3"  >热门</a>
                                                                                <?php else: ?>
                                                                                <a href="<?php echo e(url('forum')); ?>?quanbuquanbu=1" >全部</a>
										<a href="<?php echo e(url('forum')); ?>?new=2"  >最新</a>
										<a href="<?php echo e(url('forum')); ?>?hot=3" class="selected" >热门</a>
                                                                               <?php endif; ?>                                               
                                                                                
																		</span>
                            </th>
                            <th width="150"><span>作者</span></th>
                            <th width="150"><span>回复/查看</span></th>
                        
                        </tr>
                        
                        <?php foreach($data as $k=>$v): ?>
                        
                                                    <tr>
                                <td>
                                    <p class="title">
                                        <i class="up"></i>
                                        
                                        <?php if($k < 3): ?>
                                        <a class="hot-topic" href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                                                                <?php echo e($v->title); ?></a>  
                                       <?php else: ?>
                                       <a href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                                                                <?php echo e($v->title); ?></a>  
                                          <?php endif; ?>
                                    </p>
                                </td>
                                <td>
                                    <div class="author clearfix">
                                        <div class="img ly-fl">
						<img class="lazyload" alt="" data-original="https://avatar.kuangxiangit.com/novel/img-2018-01/668727/avatar/thumb_23e24663c3bd6ab8bec6a79386f0c084.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                            <div class='medal medal_3_40'></div>                                        </div>
                                        <div class="ly-fl">
                                            <span><?php echo e($v->poster); ?></span>
                                            <br>
                                            <?php echo e(date('m-d h:i:s',$v->date)); ?>                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p class="num1">
                                        <span><?php echo e($v->replynum); ?></span>                                    </p>
                                </td>
                            
                            </tr>
                            
                          
                                                   
                                   <?php endforeach; ?>                     
                                                    
                                                    
                                                 
                                                   
                                                   
                                            </table>

                    <div class="pagination" style="margin-right:0">
                        <div class="PageIn">
                            <ul>
                             
                                <?php for($i = 0; $i <$fenye; $i++): ?>
                      
                      <?php if(($i+1)==$page): ?>
                      <li class="selected"><a href='<?php echo e(url('forum')); ?>?page=<?php echo e($i+1); ?>'><?php echo e($i+1); ?>   </a></li>
                      <?php else: ?>
                       <li><a href='<?php echo e(url('forum')); ?>?page=<?php echo e($i+1); ?>'><?php echo e($i+1); ?> </a></li>
                      <?php endif; ?>
                      <?php endfor; ?>
                                   
                                    
                                
                                <input type="hidden" value="1" name="curr_page" id="curr_page">
                                <input type="hidden" value="http://www.hbooker.com/bbs/zonghe/all" name="curr_url" id="curr_url">
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <div class="ly-side">
                <div class="mod-box bbs-side">
                    <div class="mod-tit1">
                        <h3><i></i><span class="selected">本区信息</span></h3>
                    </div>
                    <div class="mod-bd ly-mt30 box-shadow">
                        <div class="manager-box clearfix">
                            <h3 class="tit">本区管理员</h3>
                                                            <div class="img ly-fl">
                                    <a target="_blank" href="http://www.hbooker.com/bookshelf/reader_book_shelf/281494"><img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-07/281494/avatar/thumb_8e4015f36f2f99be46057e825b2759f8.png" src="http://www.hbooker.com/resources/images/avatar-default-m.png"></a>
                                </div>
                                <div class="cnt">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/reader_book_shelf/281494" target="_blank">刀客骑兵</a></p>
                                    <p class="level">LV.6 出类拔萃</p>
                                </div>
                                                            <div class="img ly-fl">
                                    <a target="_blank" href="http://www.hbooker.com/bookshelf/reader_book_shelf/782671"><img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-04/782671/avatar/thumb_b89296bbf83dc1e6a45bd6b3f4149786.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png"></a>
                                </div>
                                <div class="cnt">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/reader_book_shelf/782671" target="_blank">机器人EVA</a></p>
                                    <p class="level">LV.12 笑傲江湖</p>
                                </div>
                                                            <div class="img ly-fl">
                                    <a target="_blank" href="http://www.hbooker.com/bookshelf/reader_book_shelf/47613"><img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2016-08/47613/avatar/thumb_c404c7d41bbf55c629122c17528761e9.jpg" src="http://www.hbooker.com/resources/images/avatar-default-f.png"></a>
                                </div>
                                <div class="cnt">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/reader_book_shelf/47613" target="_blank">天才Wo酱米修号</a></p>
                                    <p class="level">LV.12 笑傲江湖</p>
                                </div>
                            <!--                            <p class="msg">今日发帖：<span>500</span></p>-->
<!--                            <p class="msg">今日回复：<span>500</span></p>-->
<!--                            <p class="msg">当前在线：<span>500人</span></p>-->
<!--                            <a class="apply-for-manager" href="javascript:;">申请管理员</a>-->
                        </div>
                    </div>
                </div>
                <div class="mod-box bbs-side ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i><span class="selected">本区最热话题</span></h3>
                    </div>
                    <div class="mod-bd ly-mt30 box-shadow">
                        <ul>
                             <?php foreach($hotposter as $k=>$v): ?>
                                                            <li>
                                    <a href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                        <?php if($k<3): ?>
                                        <i class="top">
                                            <?php else: ?>
                                            <i>
                                                
                                            <?php endif; ?>
                                        <?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                                </li>
                                
                                  <?php endforeach; ?>
                                                           
                                
                                
                                                    </ul>
                    </div>
                </div>
                <div class="mod-box bbs-side ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i><span class="selected">最新话题</span></h3>
                    </div>
                    <div class="mod-bd ly-mt30 box-shadow">
                        <ul>
                             <?php foreach($data as $k=>$v): ?>
                            
                                                            <li>
                                    <a href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                        
                                        <?php if($k<3): ?>
                                        <i class="top">
                                            <?php else: ?>
                                            <i>
                                                
                                            <?php endif; ?>
                                            <?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                                </li>
                                
                                   <?php endforeach; ?>  
                                                            
                                                    </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.ziyuan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>