<?php $__env->startSection('content'); ?>   
<div class="container">
    <div class="ly-wrap">

      <div class="breakcrumb">
            <a href="<?php echo e(url('/')); ?>">首页</a> &gt;
            <a href="<?php echo e(url('forum')); ?>">论坛</a> &gt;
            发帖
        </div>

        <div class="bbs-publish">
			
			
			            <a href="<?php echo e(url('item')); ?>?date=<?php echo e($data->date); ?>&target=louzhu" class="btn-blue">只看楼主</a>
			            <a href="javascript:;" class="btn btn-blue" onclick="scrollEnd()">回复</a>
            <a href="<?php echo e('forum/create'); ?>" class="btn btn-blue">发帖</a>
            <a href="<?php echo e('forum'); ?>" class="back">返回论坛</a>
        </div>
<script>
    
    function reply(obj){
     
       form= $(obj).next()  ;
        if( form.is(':hidden')){
        form.show();
        }else{
               form.hide();      } 
                
    }
    
    
      function quxiao(obj){
        form=$(obj).parent();
               form.hide();   
    }
    
    function answer(obj,a_id,poster){
            
         content=$(obj).prev().val();

         a=$(obj).parent().parent();
        
//answer= ' <li class="clearfix J_ReviewComment " data-comment-id="4113386" data-reply-id="744593" data-reader-id="182447" data-reader-name="̑̑盖亚">'+
//                                                            '<div class="img ly-fl">'+
//                                                             '<img alt="" class="lazyload"  src="http://www.hbooker.com/resources/images/avatar-default-m.png">'+
//                                                             '<div class="medal medal_26_40"></div></div>'+
//                                                            '<div class="ly-fl box-bd">'+
//                                                                '<div class="clearfix">'+
//                                                                    '<div class="ly-fl">'+
//                            '<p class="name"><a href="http://www.hbooker.com/bookshelf/182447" target="_blank"></a> <i class="icon-level-h"></i></p>'+
//                                                                    '</div><div class="ly-fr">'+
//                                                                        '<div class="time">2018-03-08 16:51:37</div></div></div>'+
//                                                                '<div class="desc-content"> <b>  @ </b><b></b> </div><hr></div></li>'+
//
//
//      a.prepend(answer);


       $.post("<?php echo e(url('answer')); ?>",{'_token':'<?php echo e(csrf_token()); ?>','a_id':a_id,'content':content,'poster':poster},function(data){
           
              
              location.reload(true);
             form=$(obj).parent();
               form.hide();
       });

    }
    
    
    
    
    
</script>


          


        <div class="bbs-detail ly-mt20" data-bbstype="1" id="bbs-detail">
            <div class="hd clearfix">
                <div class="bbs-detail-left"> 回复：<i><?php echo e($data_num); ?></i></div>
                <div class="J_BBSTitle bbs-detail-right"><?php echo e($data->title); ?></div>
                             
                            </div>
            <div class="bd">
                <ul>
<!--                    楼主-->
                                        <li class="clearfix" id="bbs-host" data-bbs-id="475867" data-reader-id="464416">
                        <div class="bbs-detail-left post-starter">
                            <div class="img">
                                <img alt="" class="lazyload" data-original="<?php echo e(url('home/images/tou.png')); ?>" src="<?php echo e(url('home/images/tou.png')); ?>" />
                                <div class='medal medal_2_99'></div>                                <i class="icon-sex icon-female"></i>
                            </div>
                            <div class="userinfo">
				<p class="name"><a href="<?php echo e(url('tainfo')); ?>/<?php echo e($data->poster); ?>" target="_blank"><?php echo e($data->poster); ?></a> <i class='icon-level-h'>• 初V</i></p>
									<p class="level">经验等级：LV.9世外高人</p>
								                            </div>
                            <div class="foll-box">
<!--                                                                                                            <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="464416"><i>&plus;</i> 关注</a>-->
                                                                                                </div>
                            <div class="floor-num">
                               楼主
                            </div>
                        </div>
                        <div class="bbs-detail-right">
                            <div class="opt clearfix">
                                <div class="post-time ly-fl">
                                    发表时间：<span><?php echo e(date('Y-m-d h:i:s',$data->date)); ?></span>
                                                                            <a href="<?php echo e(url('item')); ?>?date=<?php echo e($data->date); ?>&target=louzhu">只看楼主</a>
                                                                    </div>
                            </div>
                            <div class="desc-box">
                                <div class="desc"><?php echo e($data->content); ?><br></div>
                            </div>
                  
                          
		<a href="javascript:;" class="bbs-reply" onclick="jump_comment_form()">回复</a>
                        </div>
                    </li>
                    <!--                    普通用户-->
         
                            <?php foreach($data1 as $k=>$v): ?>
                           <li class="clearfix J_BbsComment" data-bbs-id="475867" data-comment-id="4113374" data-reader-id="1795068">
                            <div class="bbs-detail-left">
                                <div class="img">
                                    <img alt="" class="lazyload" data-original="<?php echo e(url('home/images/tou.png')); ?>" src="<?php echo e(url('home/images/tou.png')); ?>">
                                                                        <i class="icon-sex icon-male"></i>
                                </div>
                                <div class="userinfo">
                                    <p class="name"><a href="<?php echo e(url('tainfo')); ?>/<?php echo e($v->poster); ?>" target="_blank"><?php echo e($v->poster); ?></a> <i class='icon-level-h'>• 高V</i></p>
                                    
                                </div>
                                <div class="foll-box">
<!--                                 <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="1795068"><i>&plus;</i> 关注</a>-->
                                                                            <!--                                    <a href="javascript:;" class="foll J_Follow"><i>+</i> 关注</a>-->
                                </div>
                                <div class="floor-num">
                                    <?php echo e($k+1); ?>F
                                </div>
                            </div>
                            <div class="bbs-detail-right">
                                <div class="opt clearfix">
                                    <div class="post-time ly-fl">
            发表时间：<span><?php echo e(date('Y-m-d h:i:s',$v->date)); ?></span>
                                    </div>
                                 
                                </div>
                                <div class="J_DescBox desc-box">
                                    <div class="J_Desc desc"><?php echo e($v->content); ?></div>
                                    <div class="comment-list" id="commentid_4113374">

                             <ul class="J_CommentList">
                                    
                                <?php if(isset($v->pinglun)): ?>
                                    <?php foreach($v->pinglun as $k=>$value): ?>
                                    <li class="clearfix J_ReviewComment " data-comment-id="4113386" data-reply-id="744593" data-reader-id="182447" data-reader-name="̑̑盖亚">
                                                            <div class="img ly-fl">
                                                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-03/182447/avatar/thumb_26466c59b0e9f3eb44a71863f0ad3322.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                <div class='medal medal_26_40'></div>                                                            </div>
                                                            <div class="ly-fl box-bd">
                                                                <div class="clearfix">
                                                                    <div class="ly-fl">
                                                                        <p class="name"><a href="http://www.hbooker.com/bookshelf/182447" target="_blank"><?php echo e($value->answer); ?></a> <i class='icon-level-h'>• 高V</i></p>
                                                                    </div>
                                                                    <div class="ly-fr">
                                                                        <div class="time"><?php echo e(date('Y-m-d h:i:s',$value->date)); ?></div>
                                                                    </div>
                                                                </div>
                                                                <div class="desc-content">
                                                                    <b>  @ </b><b><?php echo e($value->poster); ?>：</b>
                                                            <?php echo e($value->content); ?>    
                                                                </div>
                                                              
                                            <hr>
                                                            </div>
                                                </li>


                                                   <?php endforeach; ?> 
                                                   <?php endif; ?>
      <!--上面显示-->   

                                
             
                 <a  onclick="reply(this)" class="J_FormReply bbs-reply">回复</a>
                 <form   style="display:none"> 
                 <input type="text"  placeholder="请输入评论" >
                 <input  type="button"  onclick="answer(this,'<?php echo e($v->id); ?>','<?php echo e($v->poster); ?>')" value="确定">
                 <input  type="button"  onclick="quxiao(this)"  value="取消">
                 </form>
             
                                </ul>
                     
                              </div>
                                </div>
                                        

                            </div>
                        </li>
                                <?php endforeach; ?>      
                                
                                
                                
                                
                              
                                       
              </ul>
            </div>
        </div>

        <div class="pagination" style="margin-right:0">
            <div class="PageIn">
                <ul>
                      <?php for($i = 0; $i <$fenye; $i++): ?>
                      
                      <?php if(($i+1)==$page): ?>
                      <li   class="selected"><a href='<?php echo e(url('item')); ?>?date=<?php echo e($data->date); ?>&page=<?php echo e($i+1); ?>'><?php echo e($i+1); ?>   </a></li>
                      <?php else: ?>
                       <li><a href='<?php echo e(url('item')); ?>?date=<?php echo e($data->date); ?>&page=<?php echo e($i+1); ?>'><?php echo e($i+1); ?> </a></li>
                      <?php endif; ?>
                      <?php endfor; ?>
                      
                      
                 
                </ul>
                <input type="hidden" value="1" name="curr_page" id="curr_page">
                <input type="hidden" value="change_comment_page(1)" name="curr_url" id="curr_url">
            </div>
        </div>
        <form action="<?php echo e(url('forum')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        <div class="bbs-form ly-mt60">
            <div class="titl">发表回复</div>
            <div>
                <input type="hidden" id="bbs_id" value="<?php echo e($data->id); ?>"  name="p_id">
                <div class="form-group" style="margin-top:5px">
                    <textarea name="content" id="editor" cols="30" rows="10" style="height: 120px;" placeholder="发表帖子，注意文明用语哦\^o^/"></textarea>
                    <div id="editor_content" style="display: none;"></div>
                </div>
                <div class="form-group action" style="text-align: right">
                    <span class="J_TopicWordsCount">0</span>/<span class="J_TopicWordsCountLimit">500</span>
                    <button type=submit id="add_coment_submit" type="button" class="ly-ml10">发表</button>
                </div>
            </div>
        </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.ziyuan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>