<?php $__env->startSection('content'); ?>   
    
<div class="container">
    <div class="ly-wrap">

        <div class="ly-main">
            
            <div class="first-col">
                <div class="banner banner-top J_Slider ly-fl">
                    <a href="javascript:;" class="slider-btn prev"></a>
                    <a href="javascript:;" class="slider-btn next"></a>
                    <ul>
                          <?php foreach($paihang as $k=>$v): ?>
                                 <li>
                                <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                          
                                    <img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" alt="">  </a>
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a  href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                              
                            </li>
                            <?php endforeach; ?>
                           
                                               
                                                                        </ul>
                </div>
                <ul class="topic ly-fl" id="J_Topic">
                      <?php foreach($data as $k=>$v): ?>
                                                                    <li>
                            <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                <img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t"><?php echo e($v->title); ?></div>
                                    <div class="n"><?php echo e($v->intro); ?></div>
                                    <div class="num">收藏：<?php echo e($v->favorate); ?><i></i></div>
                                </div>
                            </a>
                        </li>
                                     <?php endforeach; ?>                
                                                
                                                            </ul>
            </div>

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>玄幻推荐</h3>
                        <i class="line"></i>
                     
                    </div>
                     <div class="mod-body">
                      
               
                        <ul class="book-list book-list3 J_BookList">
                            
                            <?php foreach($data as $k=>$v): ?>
                                                        <li>
                                <a class="img" href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" >
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" ></div>
                                        <div class="n"><?php echo e($v->intro); ?></div>
                                        <div class="num">收藏：<?php echo e($v->favorate); ?><i></i></div>
                                    </div> 
                                                                    </a>
                                <div class="title"><a href="<?php echo e(url('novel')); ?>" title="我和Caster谈恋爱" target="_blank"><?php echo e($v->title); ?></a></div>
                                <div class="info"><span>【<?php echo e($v->author); ?>】</span></div>
                            </li>
                                                       <?php endforeach; ?>       
                                                    </ul>
                    
          
                </div>
            </div>
            <!--mod-box end-->



            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>穿越推荐</h3>
                        <i class="line"></i>
                  
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                             <?php foreach($chuanyue as $k=>$v): ?>
                                                        <li>
                                <a class="img" href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" >
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" ></div>
                                        <div class="n"><?php echo e($v->intro); ?></div>
                                        <div class="num">收藏：<?php echo e($v->favorate); ?><i></i></div>
                                    </div> 
                                                                    </a>
                                <div class="title"><a href="<?php echo e(url('novel')); ?>" title="我和Caster谈恋爱" target="_blank"><?php echo e($v->title); ?></a></div>
                                <div class="info"><span>【<?php echo e($v->author); ?>】</span></div>
                            </li>
                                                       <?php endforeach; ?>    
                                                                      </ul>
                    </div>
                            </div>
            <!--mod-box end-->




            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>男生推荐</h3>
                        <i class="line"></i>
                       
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                              <?php foreach($boy as $k=>$v): ?>
                                                        <li>
                                <a class="img" href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" >
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" ></div>
                                        <div class="n"><?php echo e($v->intro); ?></div>
                                        <div class="num">收藏：<?php echo e($v->favorate); ?><i></i></div>
                                    </div> 
                                                                    </a>
                                <div class="title"><a href="<?php echo e(url('novel')); ?>" title="我和Caster谈恋爱" target="_blank"><?php echo e($v->title); ?></a></div>
                                <div class="info"><span>【<?php echo e($v->author); ?>】</span></div>
                            </li>
                                                       <?php endforeach; ?>    
                                                          
                                                               
                                                          
                                                            
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->


   

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>女生推荐</h3>
                        <i class="line"></i>
                       
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                              <?php foreach($girl as $k=>$v): ?>
                                                        <li>
                                <a class="img" href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" >
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" ></div>
                                        <div class="n"><?php echo e($v->intro); ?></div>
                                        <div class="num">收藏：<?php echo e($v->favorate); ?><i></i></div>
                                    </div> 
                                                                    </a>
                                <div class="title"><a href="<?php echo e(url('novel')); ?>" title="我和Caster谈恋爱" target="_blank"><?php echo e($v->title); ?></a></div>
                                <div class="info"><span>【<?php echo e($v->author); ?>】</span></div>
                            </li>
                                                       <?php endforeach; ?>  
                                                        
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->

   

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>宅文推荐</h3>
                        <i class="line"></i>
                       
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                              <?php foreach($zhaiwen as $k=>$v): ?>
                                                        <li>
                                <a class="img" href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" >
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="<?php echo e(asset($v->pic_addr)); ?>" ></div>
                                        <div class="n"><?php echo e($v->intro); ?></div>
                                        <div class="num">收藏：<?php echo e($v->favorate); ?><i></i></div>
                                    </div> 
                                                                    </a>
                                <div class="title"><a href="<?php echo e(url('novel')); ?>" title="我和Caster谈恋爱" target="_blank"><?php echo e($v->title); ?></a></div>
                                <div class="info"><span>【<?php echo e($v->author); ?>】</span></div>
                            </li>
                                                       <?php endforeach; ?>  
                                                        
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->

            <!--mod-box start-->
                        <div class="mod-box ly-mt60">
             

                <div class="mod-body">
                    <div class="book-list-table-wrap">
                  
                    </div>
                </div>
            </div>
                        <!--mod-box end-->
        </div>
        <div class="ly-side index-side">
            <!-- 公告 begin -->
            <div class="big-event">
                                                                                        <div><a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://www.hbooker.com/resources/imagesactivity/zhengwen_nov_banner.jpg" alt="活动"></a></div>
                                                                                                <div><a href="https://www.hbooker.com/index/fuli" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_notice/20170601112204377.jpg" alt=""></a></div>
                                                                        </div>
            <!-- 公告 end -->
            <div class="recomm-tit ly-mt30">
                <h4>精选荣誉榜单</h4>
            </div>

                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">热帖</div>
                    <div class="sub-tit"><i>TOP 10</i> 精挑细选</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                    
                               <?php foreach($poster as $k=>$v): ?>
                           
                                                    <li  class="top2">
                                     <a href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                    <span class="num">0.8万</span><i class="icon-top"><?php echo e($k+1); ?></i><?php echo e($v->title); ?>    </a>
                            </li>
                            
                             <?php endforeach; ?>
                                            </ul>
                        
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">现代强推</div>
                    <div class="sub-tit"><i>TOP 10</i></div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <?php foreach($xiandai as $k=>$v): ?>
                        <?php if($k<3): ?>
                        
                             <li class="top2">
                                 <?php else: ?>
                                  <li>
                                      <?php endif; ?>
                                <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <span class="num"><?php echo e($v->favorate); ?></span><i class="icon-top icon-top2"><?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                            </li>
                              <?php endforeach; ?>  
                              
                                                    
                                                   
                                            </ul>
                </div>
                                <!--recomm-list end-->
              
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">架空强推</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                       <?php foreach($jiakong as $k=>$v): ?>
                                                     <?php if($k<3): ?>
                        
                             <li class="top2">
                                 <?php else: ?>
                                  <li>
                                      <?php endif; ?>
                                <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <span class="num"><?php echo e($v->favorate); ?></span><i class="icon-top icon-top2"><?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                            </li>
                            <?php endforeach; ?>  
                                                    
                                            
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">悬疑强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>

                    <ul>
                                     <?php foreach($xuanyi as $k=>$v): ?>
                                                     <?php if($k<3): ?>
                        
                             <li class="top2">
                                 <?php else: ?>
                                  <li>
                                      <?php endif; ?>
                                <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" target="_blank">
                                    <span class="num"><?php echo e($v->favorate); ?></span><i class="icon-top icon-top2"><?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                            </li>
                            <?php endforeach; ?>  
                                                     
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            
                            <!--recomm-list start-->
                                <!--recomm-list end-->
                    </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
    
    
    
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>