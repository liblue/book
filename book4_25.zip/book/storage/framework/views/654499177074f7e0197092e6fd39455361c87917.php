<?php $__env->startSection('nav'); ?>
   <li><a href="<?php echo e(url('user')); ?>" >我的信息</a></li>
               
                <li><a href="<?php echo e(url('author')); ?>" class='selected' >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="<?php echo e(url('author')); ?>" class="selected">我的作品</a></li>
                    <li><a href="<?php echo e(url('author/create')); ?>" >新建作品</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="<?php echo e(url('au_purse')); ?>">我的收入</a></li>
                    <li><a href="https://www.hbooker.com/reader/my_info">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
      
        <div class="ly-fl bookshelf" style="width: 80%">
     
            <button class="layui-btn" onclick="fun()">删除</button>

                
                <table class="layui-table">

  <thead>
    <tr>
        <th><input type="checkbox" class="selectAll" id="selectAll" name="choice"></th>
         <th>封面</th>
      <th>书名</th>
     
      <th>创作时间</th>
      
       <th>状态</th>
       <th>收藏</th>
      <th>管理</th>
     
    </tr> 
  </thead>
  <tbody>
      
      <?php foreach($data as $k=>$v): ?>
    <tr>
        <td  align="left"> <input type="checkbox" class="subSelect" name="choice" value="<?php echo e($v->date); ?>"></td>
       <input type="hidden" value="<?php echo e($v->date); ?>" name="date" >
              <td><img src="<?php echo e(asset($v->pic_addr)); ?>" width="50px" height="50px"/></td>
       <td><?php echo e($v->title); ?></td>
      <td><?php echo e(date("Y-m-d",$v->date)); ?></td>
     
      <td>
          <?php if($v->status===1): ?>
          连载中
      <?php else: ?>
      已完结
      <?php endif; ?>
      </td>
        <td><?php echo e($v->favorate); ?></td>
      <td>    <a href="<?php echo e(url('author/setshow/'.$v->date)); ?>"><button class="layui-btn layui-btn-primary">设置</button></a>
          <a  href="<?php echo e(url('author/info/'.$v->date)); ?>"> <button class="layui-btn layui-btn-primary">详情</button> </a>
          <a href="<?php echo e(url('author/write/'.$v->date)); ?>"><button class="layui-btn layui-btn-primary">添加章节</button></a></td>
    </tr>
       <?php endforeach; ?>


  </tbody>
     
</table>
             
       
        </div>

        <!--我的关注,我的粉丝 start-->
       
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>

<script>
//      $("document").ready(function(){
// $("#selectAll").click(function(){   
//  if(this.checked){   
//   $("input[name='choice']").each(function(){this.checked=true;});
//   
//  }else{   
//   $("input[name='choice']").each(function(){this.checked=false;});   
//
//  }   
// });}
//   

   
    function fun(){
    
      $('input:checkbox[name=choice]:checked').each(function(i){
        date = $(this).val();
//        alert(date);
         $.post("<?php echo e(url('author/delete')); ?>",{'_token':'<?php echo e(csrf_token()); ?>','date':date},function(data){
            if(data.status == 0){
//                alert(data.msg);
            location.reload(true)
            }
            else{
                alert('no');
            }
    });
      });
      
//       location.href = location.href;
    }
    </script>

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>