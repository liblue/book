@extends('layout.home')
    


@section('content')   
    
    
      


<div class="container">
    <div class="ly-wrap">
<!--        <a href="{{url('search')}}?zuopin=1"><button class="layui-btn layui-btn-warm">作品</button></a>  <a href="{{url('search')}}?zuozhe=2"><button class="layui-btn layui-btn-warm">作者</button></a>-->
        <div class="ly-main">
         
            <div class="search-result ly-mt30">有 <span>{{$count}}</span> 条符合关键词""的搜索结果</div>
            <div class="charts-box search-list ly-mt30">
                <div class="box-list">
                    <ul>
                        
                        
                           @foreach($res as $k=>$v)
                                                                                    <li data-book-id="100019390">
                                    <i>{{$k+1}}</i>
                                    <a href="{{url('content')}}?id={{$v->id}}" class="img ly-fl"><img src="{{$v->pic_addr}}" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a target="_blank"><!--<s class="search-ky">崩</s>-->{{$v->title}}</a></p>
                                        <p>小说作者：<a >{{$v->author}}</a></p>
                                        <p>日期：{{date('Y-m-d h:i:s',$v->date)}}</p>
                                        <div class="desc">{{$v->intro}}</div>
                                    </div>
                                   
                                </li>
                           @endforeach                   
                                                                
                                                           
                                                           
                                                            
                                                           
                                                                        </ul>
                </div>
            </div>
<!--            <div class="pagination">
                                    <div class="PageIn">
                        <ul>
                                <li class='selected'><a href='javascript:'>1</a></li>                  
                               
                            <input type="hidden" value="http://www.hbooker.com/get-search-book-list/3/" name="curr_url" id="curr_url">
                        </ul>
                    </div>
                            </div>-->
        </div>
  

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->







    
    
       
    @endsection
    
