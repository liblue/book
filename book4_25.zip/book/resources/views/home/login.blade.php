
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="332107236654575254534635167011671463757037317650747716" />
    <title>登录 - 欢乐书客</title>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <link rel="shortcut icon" type="image/x-icon" href=""/>
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">

    <link rel="stylesheet" type="text/css" href="{{asset('home/css/style.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/response.css')}}"/>
    <script type="text/javascript" language="javascript" src="{{asset('bootstrap/jquery.js')}}"></script>


</head>
<body>
<script type="text/javascript">
    function initResponse(){var d,b,a=window.innerWidth||document.documentElement.clientWidth,g=navigator.userAgent.toLowerCase(),h=/(msie) ([\w.]+)/,f=h.exec(g),c;if(f!==null&&f[1]==="msie"){c=f[2];if(c==="8.0"||c==="7.0"||c==="6.0"){a=a+21}}document.body.style.width="";var e=(document.body.className&&document.body.className.indexOf("sw-list-")!=-1);if(a>=1280||e){d=1}else{d=0}switch(d){case 1:b="s-layout-1190";break;case 0:b="s-layout-990";break;default:b="s-layout-990";break}document.body.className=b}initResponse();
</script>

<div class="header header-other">
    
    <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
                <li><a href="{{url('/')}}" class='selected'>首页</a></li>
                <li><a href="https://www.hbooker.com/index/rank_index" >排行</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/tongren" >同人</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index/comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index/game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs/zonghe">社区</a></li>
            </ul>
            <div class="ly-fr">
                <form action="" name="myform" id="" target="_blank" class="search-form">
                    <input name="keyword" autocomplete='off' type="text" autocomplete="off" x-webkit-speech="" data-type="1" x-webkit-grammar="builtin:translate" placeholder="搜索更多作品或作者" data-url="https://www.hbooker.com/get-search-book-list/{key}">
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>

</div>

<div class="login-header">欢乐书客，让阅读更精彩\^o^/</div>

<!--container start-->
<div class="container">
    <div class="ly-wrap">
        <div class="login-box">
            <form action="{{url('login')}}" class="form-box" method="post" name="J_LoginForm" id="J_LoginForm" >
                    {{csrf_field()}}
                <h3>登录</h3>
                <input type="hidden" value="{{$url}}" name="url">
                <div class="form-group">
                    <input type="text" placeholder="手机号/用户名" class="username" name="tel" id ="username">
                 
                </div>
                <div class="form-group">
                    <input type="password" placeholder="密码" class="password" name="password">
                </div>
                    @if(count($errors)>0)  
             @foreach($errors->all() as $value)
             <a style="color: red"> {{$value}}  </a>
             @endforeach  
                @endif 
                <div class="form-group code-group">
											<div id="embed-geetest-captcha"></div>
<!--						<p id="geetest-wait">正在加载验证码......</p>
						<p id="geetest-notice">请先拖动验证码到相应位置</p>-->
					
							
					                </div>
                <div class="form-btn">
                    <button id="geetest-submit" type="submit">登录</button>
                </div>
                <div class="form-ft clearfix">
                        <span class="tl">
                            <label><input checked="checked" value="1" type="checkbox">自动登录</label>
                        </span>
                        <span>
                            <a target="_self" href="{{url('register')}}">注册</a>
                        </span>
                        <span class="tr">
                            <a class="fpw" href="https://www.hbooker.com/signup/modify_passwd_page?redirect=https://www.hbooker.com/">忘记密码 ></a>
                        </span>
                </div>
            </form>
            <div class="login-ft">
                <div class="otherUser">
                    <div class="otherUser_T"><span></span><b></b></div>
                    <div class="otherUser_B">
                        <a href="https://www.hbooker.com/signup/qqlogin?redirect=https://www.hbooker.com/" class="qqLogin"></a>
						 <!--<a href="https://www.hbooker.com/signup/weixin_login" class="weixinLogin"></a>--> 
<!--                        <a href="javascript:;" class="qqLogin"></a>-->
                        <!-- <a href="javascript:;" class="wbLogin"></a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--container end-->

<script type="text/javascript" src='https://www.hbooker.com/resources/js/jquery-plugins/jquery.validate/jquery.validate.min.js'></script>
<script type="text/javascript" src='https://www.hbooker.com/resources/js/form.js'></script>
<script type="text/javascript">
    var errorStr = "";
    if(errorStr!="")
        HB.util.alert(errorStr);
</script>
<div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="https://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
<!--             <li>
                <dl>
                    <dt>安全认证</dt>
                    <dd><a logo_size="83x30" logo_type="realname" href="http://www.anquan.org" ><script src="http://static.anquan.org/static/outer/js/aq_auth.js"></script></a></dd>
                </dl>
            </li> -->
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
</body>
</html>