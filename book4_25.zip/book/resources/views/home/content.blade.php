@extends('layout.home')
    


@section('content')   






<div class="container">
    <div class="ly-wrap">



        <!--书页 start-->
        <div class="book-detail ly-mt45">

            <!-- ly-main -->
            <div class="ly-main">
                <div class="book-hd clearfix">
                    
                    <div class="ly-fl book-info">
                        <div class="book-title">
                            <h1>{{$data->title}}</h1>
                            
                        </div>
                        <!--act-tab start-->
                        <div class="book-bd act-tab">
                            <div>
                              
                                <ul class="act-tab-titles clearfix">
                                    <li class="selected"><a href="javascript:">作品简介</a></li>
                                    <li><a href="javascript:">作品信息</a></li>
                                    <li><a href="javascript:">作者信息</a></li>
                                </ul>
                            </div>
                            <div class="book-cnt">
                                <!--act-tab-content start-->
                                <div class="act-tab-content">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-count clearfix">
                                                <ul class="ly-fl">
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总收藏：<b class="J_Stock_Favor_total"> {{$data->favorate}}</b>
                                                    </li>
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 章节数：{{$count}}                                                   </li>
                                                </ul>
                                                <span class="ly-fl book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            	                                            </div>
                                            <div class="book-desc J_mCustomScrollbar">
                                                                                                {{$data->intro}}<br />
                                       </div>
                                        </div>
                                    
                           
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-property clearfix">
                                      
                                                <span><i class="icon-diamond">◆</i> 创作时间：{{date('Y-m-d',$data->date)}}</span>
<!--                                                <span><i class="icon-diamond">◆</i> 总点击: 4.2万</span>-->
                                                <span><i class="icon-diamond">◆</i> 总收藏：  {{$data->favorate}}</span>
                                                <span><i class="icon-diamond">◆</i> 周点击：0.1万</span>
                                                <span><i class="icon-diamond">◆</i> 小说类别：{{$data->cate}}</span>
<!--                                                <span><i class="icon-diamond">◆</i> 总推荐：<b class="J_Recommend_Rec_total">24</b></span>
                                                <span><i class="icon-diamond">◆</i> 月推荐：<b class="J_Recommend_Rec_month">19</b></span>
                                                <span><i class="icon-diamond">◆</i> 周推荐：<b class="J_Recommend_Rec_week">0</b></span>-->
                                                <span><i class="icon-diamond">◆</i> 章节数：{{$count}}</span>
<!--                                                <span><i class="icon-diamond">◆</i> 当月月票：0</span>
                                                <span><i class="icon-diamond">◆</i> 总刀片：0</span>
                                                <span><i class="icon-diamond">◆</i> 月刀片：0</span>
                                                <span><i class="icon-diamond">◆</i> 完成字数：302152</span>-->
                                                @if($data->status==1)
                                                <span><i class="icon-diamond">◆</i> 写作状态：连载中</span>
                                                @else
                                                 <span><i class="icon-diamond">◆</i> 写作状态：已完结</span>
                                                 @endif
                                                <span class="book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            </div>
                                        </div>
                        
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-author-info">
                                                <div><i class="icon-diamond">◆</i> 作者的其它作品：</div>
                                                <ul class="clearfix">
                                                    暂无其他作品
                                                </ul>
                                            </div>
                                        </div>
                                     
                             
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                            </div>
                        </div>
                        <!--act-tab end-->
                    </div>
                </div>
                <div class="book-ft">
                    <div class="book-chapter">

<!--                                                <div class="mod-box ly-mt60">
                            <div class="mod-tit1">
                                <h3><i></i>{{$data->title}}<span>最新章节试阅</span></h3>
                                <a class="ly-fr" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149" target="_blank">阅读本章 ></a>
                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-new">
                                    <div class="tit">第122章 听指挥      更新时间：2018-01-15 22:49:04</div>
                                    <div class="desc box-shadow">　　少有地，传奇灰矮人牧师制止了他，转头对伊泽说道：“都走到这里了，我们的利益应该是一致的，凭你的实力也很难独自走回去吧？你说，我们要怎么办？给出一个合理的建议，我想我们会接受的。”
　　伊泽先举起第..</div>
                                </div>
                            </div>
                        </div>-->
                        
                        <div class="mod-box ly-mt30">
                            <div class="mod-tit1">
                                <h3><i></i>章节列表</h3>
                                                                    
                                                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-list ly-mt30">
                                                                            <ul class="clearfix less">
                                                                                @foreach($data->chapter as $k=>$v)
                                                                                  @if($k <13)
                                                                                                 <li><a target="_blank" href="{{url('chapter')}}?id={{$data->id}}&chapter={{$k}}">第{{$k}}章 {{$v}}</a></li>
                                                                                                 @endif
                                                                                          @endforeach       
                                                                                                 
                                                                                                 
                                                                                               
                                                                                               
                                                                                    </ul>
                                       <ul class="clearfix less" id="chapter" style='display:none'>
                                                                                                 @foreach($data->chapter as $k=>$v)
                                                                                  @if($k>12)
                                                                                                  <li><a target="_blank" href="{{url('chapter')}}">第{{$k}}章 {{$v}}</a></li>
                                                                                                          @endif
                                                                                          @endforeach   
                                                         
                                                                                               
                                                                                           
                                                                                    </ul>
                                        
                                        @if(count($data->chapter)>12)
                                    <div class="read-all"  onclick="show()"><a id="J_ReadAll" href="javascript:;">+ 查看全部章节</a></div>
                                    @endif
                                                                                                                          
                                                                                                            </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt60">
                       
                        
                            <div class="mod-bd">
                                <div class="book-chapter-comment J_BookChapterComment" id="book_review_box">
                                    <textarea class="J_CommentInput comment-input" maxlength="1000" placeholder="快来吐槽这本书吧，注意文明用语哦\^o^/"  id="content"></textarea>
                                    <input type="hidden" value="{{$data->id}}" id="book_id">
                                    <div class="clearfix ly-mt10 repo">
                                        <div class="ly-fl">
                                            <div class="comment-face J_Face">
                                               
                                                <div class="J_FaceDialog face-dialog" style="display:block;visibility:hidden">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ly-fr"><span class="J_CommentWordsCount">0</span>/<span class="J_CommentWordsCountLimit">1000</span><a onclick="comment()" class="J_ReplayBtn replay-btn ly-ml10">评论</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt30">
                            <div class="comment-list">
                               <ul class="J_CommentList"  id="zhui">       
                                   
                                   
       @foreach($comment as $k=>$v)

        <li class="clearfix J_Review" data-review-id="1996149">
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/37507" target="_blank">{{$v->commenter}}</a> </p>
                   
                </div>
                <div class="ly-fr">
                                                                <div class="ly-fl"><div class="time">{{date('Y-m-d h:i:s',$v->date)}}</div></div>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">{{$v->content}}</div>
        </div>
    </li>
       @endforeach
      
       
<!--       {{ $comment->links() }}-->
    
<!--    <div class="pagination">
        
        
            <div class="PageIn">
            <ul>
            <li class="selected"><a href="javascript:">1</a></li>
            <li><a href="javascript:change_review_page(2)" data-ci-pagination-page="2">2</a></li><li><a href="javascript:change_review_page(3)" data-ci-pagination-page="3">3</a></li><li><a href="javascript:change_review_page(2)" data-ci-pagination-page="2" rel="next">&gt;&gt;</a></li>            <li class="pageSkip">
                <span class="ly-fl">跳转到:</span>
                <input type="text" value="1" class="ly-fl skipBox" name="directPageNum" id="directPageNum">
                <span class="ly-fl">{{ $comment->links() }}页</span>
                <a onclick="" href="javascript:void(0);" class="ly-fl pageSkipQd">确认</a>
            </li>
            <input type="hidden" value="1" name="curr_page" id="curr_page">
            <input type="hidden" value="change_review_page(1)" name="curr_url" id="curr_url">
            </ul>
        </div>
        </div>-->


                               
  </ul>
                                <!--<input type="hidden" value="" name="curr_url" id="curr_url">-->
                            </div>
                        </div>

                    </div>

               

                </div>
            </div>
            <!-- ly-main -->


            <!-- ly-side -->
            <div class="ly-side">

                <!-- 给作者打赏 start-->
                <div class="mod-box">
                    <div class="mod-tit1">
                        <h3><i></i>给作者打赏</h3>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-reward box-shadow">
                            <div class="smile"></div>
                            <button type="button" class="J_DaShang" data-type="shang">打赏~么么哒~~</button>
                            <button type="button" class="btn-primary J_DaShang" data-type="prop">不更新？寄刀片！</button>
                            <a href="{{url('chapter')}}?id={{$data->id}}&chapter=0" ><button type="button" class="J_DaShang" data-type="shang">点击阅读</button></a>
                             
<!--                             <input ype="button" onclick=="shoucang()" id="shoucang" class="btn-primary J_DaShang" data-type="prop" value="收藏">-->
                          
                               
<!--                                  <button type="button" onclick="qushoucang({{$data->id}})" id="yishoucang" class="btn-primary J_DaShang" data-type="prop">已收藏</button>-->
                               @if($shoucang==='yishoucang')
                               <button type="button" onclick="shoucang({{$data->id}})" id="shoucang" class="btn-primary J_DaShang" data-type="prop">已收藏</button>
                              @else
                               <button type="button" onclick="shoucang({{$data->id}})" id="shoucang" class="btn-primary J_DaShang" data-type="prop">收藏</button>
                              @endif
                           
                        </div>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-reward box-shadow">
                        <div class="book-cover" style="margin:auto">
                            <img src="{{asset($data->pic_addr)}}" alt="比企谷雪乃的养成日记">
                        		
                        </div>
                        </div>
                    </div>
                      
              
                </div>
                <!--给作者打赏 end-->

       

     


                <div class="fans-tit ly-mt45">
                    <h4>粉丝荣誉榜单</h4>
                </div>

                <!--铁杆粉丝榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i>推荐阅读</h3></a>
                    </div>
                    <div class="mod-bd ly-mt30" style="background:#fafafa">
                        <div class="book-fansboard">
                              @foreach($tuijian as $k=>$v)
                              <a href="{{url('content')}}?id={{$v->id}}"><ul>{{$v->title}}</ul></a>
                          @endforeach
                        </div>
                    </div>
                </div>
                <!--铁杆粉丝榜 end-->
    
            </div>
            <!-- ly-side -->

        </div>
        <!--书页 end-->


        <div class="go-top" id="J_GoTop">
            <a href="javascript:">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->


<script>
    
    
    function shoucang(id){
        
        if($("#denglu").val()==='meiyou'){//检测是否登陆       
             var url = "{{url('login')}}";//弹出窗口的url
             window.location.href=url;
        }
       if($("#shoucang").text()==='收藏'){
            $("#shoucang").text("已收藏");
            $.post("{{url('user/favorate')}}",{'_token':'{{csrf_token()}}','id':id},function(data){});
        }else{
            $("#shoucang").text("收藏");
            $.post("{{url('user/favorate')}}",{'_token':'{{csrf_token()}}','id':id},function(data){});
            
        }
        
        
    } 
      
    
    
    
    
    function comment(){
        
        
          if($("#denglu").val()==='meiyou'){//检测是否登陆       
             var url = "{{url('login')}}";//弹出窗口的url
             window.location.href=url;
        }
        content=$("#content").val();
        
        
        
        if(content.length === 0){
            alert('评论不能为空');
            $("#content").focus();
        return false;

        }else{

            book_id=$("#book_id").val();
      
      
      
            $.post("{{url('comment')}}",{'_token':'{{csrf_token()}}','content':content,'book_id':book_id},function(data){
            a= ' <li class="clearfix J_Review" data-review-id="1996149">'+
        '<div class="ly-fl bd">'+
           '<div class="clearfix">'+
                '<div class="ly-fl">'+
                    '<p class="name"><a href="https://www.hbooker.com/bookshelf/37507" target="_blank">'+data['commenter']+'</a> </p>'+
                   
                '</div>'+
               '<div class="ly-fr">'+
                                                                '<div class="ly-fl"><div class="time">刚刚</div></div>'+
                                        
                '</div>'+
            '</div>'+
            '<div class="desc-content J_DescContent">'+data['content']+'</div>'+
        '</div>'+
    '</li>';
            $("#zhui").prepend(a); 
            $("#content").val('');            
    });
        
    }
    }
    
    
    function show(){
        
          if($("#chapter").is(":hidden")){
        
        $("#chapter").show();
          $("#J_ReadAll").text("+ 收起");
    } 
    else{
        
          $("#chapter").hide();
        
           $("#J_ReadAll").text("+ 查看全部章节");
          
    }
    }
    </script>








@endsection

