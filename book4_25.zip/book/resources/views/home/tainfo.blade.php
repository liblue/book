@extends('layout.user')


@section('content')

<div class="container"  style="height:auto">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="javascript:" class="selected">TA的书架</a></li>
                    <li><a href="{{url('tabook')}}/{{$nickname}}">TA的作品</a></li>
                   
                </ul>
            </div>
            
        </div>
        
        <div class="ly-fl bookshelf">
            <div class="mod-box" id="J_BookShelf">
                <div class="mod-tit1">
                    <h3>
                        <i></i>
                                                                                    <span><a class="selected" href="javascript:;">TA的书架</a></span>
                                                                        </h3>
<!--                    <div class="ly-fr bookshelf-opt">
                        <a class="manage" href="javascript:;" id="J_manageBookself">+ 管理书架</a>
                  <a class="new" href="javascript:;" id="J_AddBookSelf">新建书架</a>
                       <a href="javascript:;" class="drop-down">移动至</a><b></b>
                    </div>-->
                </div>

                <div class="bookshelf-list clearfix" id="J_BookShelfList">
                    <ul>
                        
                       @foreach($data as $k=>$v)
                            <li>
                                <a class="img" href="{{url('content')}}?id={{$v->id}}"><img alt="{{$v->title}}" src="{{$v->pic_addr}}" data-original="{{$v->pic_addr}}" class="lazyload"></a>
                                <div class="mask"></div>
                                <div class="tit"><a data-book-id="100050877" href="{{url('content')}}?id={{$v->id}}" target="_blank">{{$v->title}}</a></div>
                                  <i class="new">更</i>
                                <div class="mask2"></div>
                             
                                <a target="_blank" href="https://www.hbooker.com/book/100050877" class="go">&nbsp;</a>
                            </li>
                        @endforeach                               
                     </ul>
                </div>
            </div>
        </div>

        <!--我的关注,我的粉丝 start-->
        
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>



@endsection