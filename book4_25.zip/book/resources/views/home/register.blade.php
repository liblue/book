
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="332107236654575254534635167011671463757037317650747716" />
    <title>注册页面</title>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <link rel="shortcut icon" type="image/x-icon" href=""/>
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/style.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/response.css')}}"/>
    <script type="text/javascript" language="javascript" src="{{asset('bootstrap/jquery.js')}}"></script>
    <script type="text/javascript" src="https://www.hbooker.com/resources/js/artDialog/6.0.4/dialog-min.js"></script>
    <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
    </script>
	<script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>
  
</head>
<body>


<div class="header header-other">
    
    <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
                <li><a href="{{url('/')}}" class='selected'>首页</a></li>
                <li><a href="{{url('paihang')}}" >排行</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/tongren" >同人</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index/comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index/game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs/zonghe">社区</a></li>
            </ul>
            <div class="ly-fr">
                <form action="search_result" name="myform" id="" target="_blank" class="search-form">
                    <input name="keyword" autocomplete='off' type="text" autocomplete="off" x-webkit-speech="" data-type="1" x-webkit-grammar="builtin:translate" placeholder="搜索更多作品或作者" data-url="search_result">
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>

</div><div class="login-header">欢乐书客，让阅读更精彩\^o^/</div>


<!--container start-->
<div class="container">
    <div class="ly-wrap">
        <div class="login-box">
            <form action="{{url('/user')}}" method="post" class="form-box" id="J_RegisterForm">
                  {{csrf_field()}}
           
                <ul class="login-title clearfix">
                    <li class="J_ChangeRegType mobileReg active" data-type="mobile"><a href="javascript:;">手机注册</a></li>
                    <li class="title-line"></li>
                    <li class="J_ChangeRegType emailReg" data-type="email"><a href="javascript:;">邮箱注册</a></li>

                </ul>
                <div class="type-mobile">
                    <div class="form-group">
                        <input type="text" placeholder="手机号" class="mobile" name="tel">
                        <div class="wrongBox">
                            <b>*</b>
                            <span class="tip-msg">目前仅支持中国大陆手机号</span>
                        </div>
                    </div>
                </div>
             							<div>
						<div id="embed-geetest-captcha">
                                                    
</div>
						
					                  
                </div>
   
                <div class="form-group">
                    <input type="password" placeholder="设置密码" class="password" maxlength="16" name="password">
                    <div class="wrongBox">
                        <b>*</b>
                        <!-- <span class="tip-msg">密码长度为6~16位，只能由a-z不限<br>&nbsp;&nbsp;&nbsp;大小写英文字母或0-9的数字组成！</span> -->
                        <span class="tip-msg">密码长度为6~16位，只能由a-z不限大小写英文字母或0-9的数字组成！</span>
                    </div>
                </div>

                <div class="form-btn">
                   
                    <button id="geetest-submit" type="submit">注册</button>
                </div>
                <div class="form-ft clearfix">
                        <span class="tl ly-fl" style="width:auto">
                            <label><input checked type="checkbox">我已阅读并同意</label><a href="https://www.hbooker.com/signup/protocol" target="_blank">《用户服务协议》</a>
                        </span>
                        <span class="ly-fr tr">
                            <a class="reg-login" href="https://www.hbooker.com/signup/login">直接登录 &gt;</a>
                        </span>
                </div>
            </form>
           
        </div>
    </div>
</div>
<!--container end-->






<div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="https://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

</body>
</html>