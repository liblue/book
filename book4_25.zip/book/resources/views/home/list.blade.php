@extends('layout.home')
    


@section('content')   
    
<div class="container">
    <div class="ly-wrap">

        <div class="ly-main">
            
        
            <!--mod-box start-->
                       <div class="mod-box ly-mt60">
                <div class="mod-tit1 ly-mr30">
					<h3><i></i>最近更新小说</h3>
                    <a class="ly-fr" href="https://www.hbooker.com/book_list" target="_blank">查看更多 &gt;</a>
                </div>

                <div class="mod-body">
                    <div class="book-list-table-wrap">
                        <table class="ly-mt30 book-list-table" width="100%">
                            <tr>
                                <th><span>序号</span></th>
                             
                                <th><span>小说书名</span></th>
                                <th><span>章节数</span></th>
                                <th><span>小说作者</span></th>
                                <th>更新时间</th>
                            </tr>
                            
                            @foreach($data as $k=>$v)
                                                                                                <tr>
                                        <td><p class="code center">{{$k+1}}</p></td>
                                        
                                        <td><p class="name"><a href="{{url('content')}}?id={{$v->id}}" title="{{$v->title}}" target="_blank">{{$v->title}}</a></p></td>
                                        <td><p class="num center">{{$chapternum[$k]}}</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/198347" target="_blank">{{$v->author}}</a></p></td>
                                        <td><p class="date center">{{date('Y-m-d',$v->date)}}</p></td>
                                    </tr>
                                    
                                    @endforeach
                                                                   
                                                                                    </table>
                        
                        
                        {!! $data->links() !!}
                    </div>
                </div>
            </div>
                        <!--mod-box end-->
        </div>
        <div class="ly-side index-side">
            <!-- 公告 begin -->
            <div class="big-event">
                                                                                        <div><a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://www.hbooker.com/resources/imagesactivity/zhengwen_nov_banner.jpg" alt="活动"></a></div>
                                                                                                <div><a href="https://www.hbooker.com/index/fuli" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_notice/20170601112204377.jpg" alt=""></a></div>
                                                                        </div>
            <!-- 公告 end -->
            <div class="recomm-tit ly-mt30">
                <h4>精选荣誉榜单</h4>
            </div>

                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">热帖</div>
                    <div class="sub-tit"><i>TOP 10</i> 精挑细选</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                       <ul>
                    
                               @foreach($poster as $k=>$v)
                           
                                                    <li  class="top2">
                                     <a href="{{url('item')}}?date={{$v->date}}" target="_blank">
                                    <span class="num">0.8万</span><i class="icon-top">{{$k+1}}</i>{{$v->title}}    </a>
                            </li>
                            
                             @endforeach
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">现代强推</div>
                    <div class="sub-tit"><i>TOP 10</i></div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        @foreach($xiandai as $k=>$v)
                        @if($k<3)
                        
                             <li class="top2">
                                 @else
                                  <li>
                                      @endif
                                <a href="{{url('content')}}?id={{$v->id}}" target="_blank">
                                    <span class="num">{{$v->favorate}}</span><i class="icon-top icon-top2">{{$k+1}}</i>{{$v->title}}</a>
                            </li>
                              @endforeach  
                              
                                                    
                                                   
                                            </ul>
                </div>
                                <!--recomm-list end-->
              
                            <!--recomm-list start-->
                                
                                <!--recomm-list end-->
              
                            <!--recomm-list start-->
                               <div class="recomm-list">
                    <div class="tit">架空强推</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                       @foreach($jiakong as $k=>$v)
                                                     @if($k<3)
                        
                             <li class="top2">
                                 @else
                                  <li>
                                      @endif
                                <a href="{{url('content')}}?id={{$v->id}}" target="_blank">
                                    <span class="num">{{$v->favorate}}</span><i class="icon-top icon-top2">{{$k+1}}</i>{{$v->title}}</a>
                            </li>
                            @endforeach  
                                                    
                                            
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">悬疑强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>

                    <ul>
                                     @foreach($xuanyi as $k=>$v)
                                                     @if($k<3)
                        
                             <li class="top2">
                                 @else
                                  <li>
                                      @endif
                                <a href="{{url('content')}}?id={{$v->id}}" target="_blank">
                                    <span class="num">{{$v->favorate}}</span><i class="icon-top icon-top2">{{$k+1}}</i>{{$v->title}}</a>
                            </li>
                            @endforeach  
                                                     
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            
                            <!--recomm-list start-->
                                <!--recomm-list end-->
                    </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
    
    
    
    
    
    


@endsection