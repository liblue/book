
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<title>多终端展示页面--小贝壳</title>
<script type="text/javascript">
//<![CDATA[
window.__cfRocketOptions = {byc:0,p:0,petok:"062f1c41bacb59ed5e20377c6ba85446ce8015fe-1523438998-86400"};
//]]>
</script>
<script type="text/javascript" src="https://edge.yunjiasu.com/cdn-cgi/scripts/935cb224/cloudflare-static/rocket.min.js"></script>
<link href="css/demo.css" rel="stylesheet" media="all">
<!--[if IE]>
			<style type="text/css">
				li.purchase a {
					padding-top: 5px;
					background-position: 0px -4px;
				}
				li.remove_frame a {
					padding-top: 5px;
					background-position: 0px -3px;
				}
			</style>
		<![endif]-->
<script type="text/rocketscript">
        var txt = "jquery-minicolors-master";
        window.g1 = txt.substr(0, 3);
        window.g2 = txt.substr(0, 19);
    </script>
<script data-rocketsrc="js/pace.min.js" charset="gbk" type="text/rocketscript"></script>
<link href="css/pace-theme-barber-shop.css" rel="stylesheet">
<script data-rocketsrc="js/jquery-1.8.3.min.js" type="text/rocketscript"></script>
<script type="text/rocketscript">
	/*
	SHOW.html?url= 网址 &title=标题
	外部网址不需要带 http://  ，可以使用 相对路径，支持 ../ 跳到上层目录。
	*/
	(function ($) {
                $.getUrlParam = function () {
                    var args=new Object();    var query=location.search.substring(1);//获取查询串  
    var pairs=query.split("&");//在逗号处断开   
    for(var   i=0;i<pairs.length;i++)   
    {   
        var pos=pairs[i].indexOf('=');//查找name=value   
            if(pos==-1)   continue;//如果没有找到就跳过   
            var argname=pairs[i].substring(0,pos);//提取name   
            var value=pairs[i].substring(pos+1);//提取value   
            args[argname]=decodeURI(value);//存为属性   
    } return args; }
            })(jQuery);
        var theme_list_open = false;
        $(document).ready(function () {
            function fixHeight() {
                var headerHeight = $("#switcher").height();
                $("#iframe").attr("height", $(window).height() + "px");
            }
            $(window).resize(function () {
                fixHeight();
            }).resize();
            $('.icon-monitor').addClass('active');
            $(".icon-mobile-3").click(function () {
                $("#by").css("overflow-y", "auto");
                $('#iframe-wrap').removeClass().addClass('mobile-width-3');
                $('.icon-tablet,.icon-mobile-1,.icon-monitor,.icon-mobile-2,.icon-mobile-3').removeClass('active');
                $(this).addClass('active');
                return false;
            });
            $(".icon-mobile-2").click(function () {
                $("#by").css("overflow-y", "auto");
                $('#iframe-wrap').removeClass().addClass('mobile-width-2');
                $('.icon-tablet,.icon-mobile-1,.icon-monitor,.icon-mobile-2,.icon-mobile-3').removeClass('active');
                $(this).addClass('active');
                return false;
            });
            $(".icon-mobile-1").click(function () {
                $("#by").css("overflow-y", "auto");
                $('#iframe-wrap').removeClass().addClass('mobile-width');
                $('.icon-tablet,.icon-mobile,.icon-monitor,.icon-mobile-2,.icon-mobile-3').removeClass('active');
                $(this).addClass('active');
                return false;
            });
            $(".icon-tablet").click(function () {
                $("#by").css("overflow-y", "auto");
                $('#iframe-wrap').removeClass().addClass('tablet-width');
                $('.icon-tablet,.icon-mobile-1,.icon-monitor,.icon-mobile-2,.icon-mobile-3').removeClass('active');
                $(this).addClass('active');
                return false;
            });
            $(".icon-monitor").click(function () {
                $("#by").css("overflow-y", "hidden");
                $('#iframe-wrap').removeClass().addClass('full-width');
                $('.icon-tablet,.icon-mobile-1,.icon-monitor,.icon-mobile-2,.icon-mobile-3').removeClass('active');
                $(this).addClass('active');
                return false;
            });
        });
    </script>
<script type="text/rocketscript">
        function Responsive($a) {
            if ($a == true) $("#Device").css("opacity", "100");
            if ($a == false) $("#Device").css("opacity", "0");
            $('#iframe-wrap').removeClass().addClass('full-width');
            $('.icon-tablet,.icon-mobile-1,.icon-monitor,.icon-mobile-2,.icon-mobile-3').removeClass('active');
            $(this).addClass('active');
            return false;
        };
    </script>
</head>
<body id="by" style="overflow-y: hidden" class=" pace-done"><div class="pace  pace-inactive"><div class="pace-progress" data-progress-text="当前演示demo为外网数据加载可能有点慢，请耐心等待！100%" data-progress="99">
<div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
<div id="switcher">
<div class="center">
<ul>
<div id="Device">
<li class="device-monitor"><a href="javascript:">
<div class="icon-monitor active">
</div>
</a></li>
<li class="device-mobile"><a href="javascript:">
<div class="icon-tablet">
</div>
</a></li>
<li class="device-mobile"><a href="javascript:">
<div class="icon-mobile-1">
</div>
</a></li>
<li class="device-mobile-2"><a href="javascript:">
<div class="icon-mobile-2">
</div>
</a></li>
<li class="device-mobile-3"><a href="javascript:">
<div class="icon-mobile-3">
</div>
</a></li>
</div>

<li class="remove_frame"><a href="" id='remove_url' title="移除框架"></a></li>
</ul>
</div>
</div>
<div id="iframe-wrap">
<iframe id="iframe" src="" frameborder="0" width="100%" height="918px">
        </iframe>
</div>
<script type="text/rocketscript">
	var arg=$.getUrlParam();
	var title=arg['title'];
	var deveiceID=arg['deveiceID'];
	if(title)$("#title").text(title);
	var url=arg['url'];
	if(url.indexOf(".")>-1 && url.indexOf(".。")==1)if(url.indexOf("http")==-1)url="http://"+url;
	$("#iframe").attr("src",url);$("#remove_url").attr("href",url);
        $(document).ready(function () {
		if(deveiceID)$('#Device li:eq('+deveiceID+') a div').click()
            $(".fdr").click(function () {
                $(".fdad").hide();
            });
        });
    </script>
</body></html> 