<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Model\Novel;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class AutobookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=Novel::where('author','本站')->get();
//         $data=Novel::where('author','本站')->select();//不可以
//        dd($data);
        
       return view('admin/autobook_list',compact('data',$data));   
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
       return view('admin/autobook_add', compact('data',$data));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
         $input = $request->except('_token');
         
//         $input['myfile']->getClientOriginalName()=time.'jpg';
         //封面图片名字
             $name=time().'.jpg';
//             $path='public/photo';
             //封面地址
             $path='photo';
           $input['myfile']->move($path,$name);
      unset($input['myfile']);
      //封面地址
      $input['pic_addr']='photo/'.$name;
      //添加小说日期
      $input['date']=time();  
       $input['author']="本站"; 
            Novel::create($input);  
             $path='novel'.'/'.$input['date'];
          mkdir($path,0777,true) ;
          
     
       return redirect('admin/autobook');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
