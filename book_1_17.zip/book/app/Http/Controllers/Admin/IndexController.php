<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    //
    
    function index(){
        
          return view('admin/index');
    }
    function admin_list(){
        
        
          return view('admin/admin_list');   
    }
    
     function admin_add(){
        
        
          return view('admin/admin_add');   
    }
      function admin_edit(){
        
        
          return view('admin/admin_edit');   
    }
 
    
    
    
    
}
