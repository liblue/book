<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Model\Cate;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    //
    
    
    public function index( ){
             $cate=Cate::all();
             $cate_name='shouye';
//        view()->share('cate', '$cate');
    return view('home.index')->with('cate_name',$cate_name)->with('cate', $cate);
    
    
    
    }
      public function in_list(Request $request,$cate_name){
             
          
    
             $cate=Cate::all();
//        view()->share('cate', '$cate');
           return view('home.list')->with('cate_name',$cate_name)->with('cate', $cate);
    
    
    
    }
    
      public function in_content(Request $request){
          
                   $cate=Cate::all();
             $cate_name='shouye';
//        view()->share('cate', '$cate');
    return view('home.content')->with('cate_name',$cate_name)->with('cate', $cate); 
        
        
    }
      public function search(Request $request){
          
                   $cate=Cate::all();
             $cate_name='shouye';
//        view()->share('cate', '$cate');
    return view('home.search')->with('cate_name',$cate_name)->with('cate', $cate);   

        
        
    }
    
    
}
