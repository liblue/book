<?php

namespace App\Http\Controllers\Home;
use App\Model\Novel;

use Illuminate\Support\Facades\Input;
//
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
//use DateTime;
 use Request;
//use Illuminate\Support\Facades\Redirect;
class NovelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
      
        $user_name= session('user_name');
        
    //查找当前用户的作品
    
        $data=Novel::where('author',$user_name)->get();
//        dd($data);
//       foreach($data as $v)
//       {
//           
//           if($data->pic_addr==""){
//               
//               dd();
//           }
//       }
//    
        return view('home/author/index',compact('data'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
  
    return view('home/author/add');   
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
 {

    $imgname = $_FILES['myfile']['name'];
       if($imgname){
         
           
      
       $imgname=time().'.jpg';
    $tmp = $_FILES['myfile']['tmp_name'];
    $filepath = 'photo/';
    if(move_uploaded_file($tmp,$filepath.$imgname)){
      
    }else{
       
    } 
 }

     
     
       $input = Input::except('_token');

       unset($input['myfile']);
       
     if($imgname=="")
     {
         $input['pic_addr']="photo/1514362997.jpg";
     }
     else{
        $input['pic_addr']=$filepath . $imgname;
     }
//           dd($input);
            //添加小说创建日期
            $input['date']=time();
            //添加小说作者  就是登录用户
            $input['author']= session('user_name');

             $re = Novel::create($input);  
             
             //创建文件夹  存放小说
             $path='novel'.'/'.$input['date'];
            
                  
                mkdir($path,0777,true) ;
           
          
        
            if($re){ 
                return redirect('author');
            }else{
                return back()->with('errors','数据填充失败，请稍后重试！');
            }

            
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
    //写章节界面
     public function write($date)
    {
        //
    
           return view('home/author/write')->with('file_name',$date); 
    }
    
    //写入新的章节存入数据库并且放入文件夹
       public function putcon(Request $request)
    {
        //
             $input = Input::except('_token');

          
             $novel=Novel::where('date',$input['file_name'])->first();//在数据库找到这本小说
//             $content=$input['file_name'];
             $chapter=$novel->chapter;//小说的章节字段

            
             $array =  explode ( "@" ,  $chapter );//将字段分为数组
             //查看当前章节数
             $counter=count($array);
             $array[]=$input['chapter'];//将新的章节拼接上去
             
             
             //建立一个空数组放入更新的值 
             $temp=[];
             //拼接这次章节
             $temp['chapter']=implode('@',$array);
             $novel->update($temp);
             //共有几个章节
            
             
     
             $path='novel'.'/'.$input['file_name'].'/'.$counter.'.txt';//存放文件路径
             file_put_contents($path,$input['content']);//存入novel/日期文件夹/第n个txt
        
         session(['file_name'=>$input['file_name']]);
//         return Redirect::to("author/detail/{$content}");
//         return redirect()->action('',['content'=>$content]);
//           return redirect('author/info');//正确可用

//         return redirect()->action('Home\NovelController@info')->with('content',$content);
//         return
           return redirect('author');
         
    }
    
      //添加每一章节之后的返回
//       public function info(Request $request){
//                $content=98;
//      $content= $request->input('content');   
//      dd($content);
//        $date=(session('file_name'));
//        $novel=Novel::where('date',$date)->first();
//        $chapter =  explode ( "@" , $novel->chapter );
//    //将数组翻转  将新的一章显示在前面
//        $chapter= array_reverse($chapter);
//        //去掉空值
//       $chapter=array_filter($chapter);
//       
//       $count=count($chapter);
//      
//        return view('home.author.info')->with('chapter', $chapter)->with('count',$count);
//        
//    }
    //查看此书的详情
       public function info($date){
//dd($date);
        $novel=Novel::where('date',$date)->first();
        $chapter =  explode ( "@" , $novel->chapter );
    //将数组翻转  将新的一章显示在前面
        $chapter= array_reverse($chapter);
        //去掉空值
       $chapter=array_filter($chapter);
       $count=count($chapter);
       $path='novel'.'/'.$date.'/'.$count.'.txt';
       if(file_exists($path))
       {
       $content= file_get_contents($path);
       }
       else{
           $content="";
       } 
        return view('home.author.info')->with('chapter', $chapter)->with('count',$count)->with('content',$content)->with('date',$date);
    
      }
      //删除一本书
      public function delete(){
          $input = Input::except('_token');

        $re = Novel::where('date',$input['date'])->delete();//删除  日期是文件夹名称

       if($re){
        $data = [
                'status' => 0,
                'msg' => '文章删除成功！',
            ];
     
         return $data;
             }
      }
      
      //查看每一章的内容
    public function   change(){
        
     $input = Input::except('_token');
         $date=$input['date'];
//         file_put_contents('1.txt', $date);
       $path='novel'.'/'.$date.'/'.$input['chapter'].'.txt';//路径
       $content= file_get_contents($path);//从novel中取出每一张
         $data = [
                'status' => 0,
                'content' => $content,
              
            ];
     
         return $data;
    } 
    
function setshow($date){
    
       $novel=Novel::where('date',$date)->first();

    return view('home.author.set', compact('novel'));


}
     
function set(){
    $input=Input::except('_token');
      $id=$input['id'];
       $novel=Novel::find($id);
       $novel->update($input);
       
   return  redirect('author');



}
     
    
    
}
