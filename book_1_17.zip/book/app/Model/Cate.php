<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Cate extends Model
{
    //
       protected $table="cates";
    protected $primaryKey='id';
    public $timestamps=false;
    protected  $guarded=[];
}
