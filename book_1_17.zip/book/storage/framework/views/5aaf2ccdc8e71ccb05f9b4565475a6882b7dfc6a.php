    


<?php $__env->startSection('content'); ?>   
    
<div class="container">
    <div class="ly-wrap">

        <div class="ly-main">
            
        
            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>宅文推荐</h3>
                        <i class="line"></i>
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                        <li>
                                <a class="img" href="<?php echo e(url('content')); ?>" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17102341-79943-100049774.jpg" alt="我和Caster谈恋爱">
                                    <div class="mask"></div>
                                    <div class="info"><?php echo e(url('content')); ?>

                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-02/189853/avatar/thumb_85b543775ee54d6436914d2edadc95c1.jpeg" alt="">【殁言】</div>
                                        <div class="n">你问我美狄亚哪里好？体贴、温柔还有偶尔的小性子无时无刻都在吸引着我除了......咳咳，偶尔......不胜腰力</div>
                                        <div class="num">3806<i></i></div>
                                    </div> 
                                                                    </a>
                                <div class="title"><a href="<?php echo e(url('novel')); ?>" title="我和Caster谈恋爱" target="_blank">我和Caster谈恋爱</a></div>
                                <div class="info"><span>55.5万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        
                                                    </ul>
                    </div>
                
            </div>
            <!--mod-box end-->




   


   


            <!--mod-box start-->
                        <div class="mod-box ly-mt60">
             

                <div class="mod-body">
                    <div class="book-list-table-wrap">
                  
                    </div>
                </div>
            </div>
                        <!--mod-box end-->
        </div>
        <div class="ly-side index-side">
            <!-- 公告 begin -->
            <div class="big-event">
                                                                                        <div><a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://www.hbooker.com/resources/imagesactivity/zhengwen_nov_banner.jpg" alt="活动"></a></div>
                                                                                                <div><a href="https://www.hbooker.com/index/fuli" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_notice/20170601112204377.jpg" alt=""></a></div>
                                                                        </div>
            <!-- 公告 end -->
            <div class="recomm-tit ly-mt30">
                <h4>精选荣誉榜单</h4>
            </div>

                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">主编强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 精挑细选</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100038671" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170719/19-07-17155944-511-100038671.jpg" alt="">
                                <span class="num">69.4万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【未来幻想】变身二次元角色拯救世界吧</p>
                                <p class="author">正在旅行的穿越者</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050129" target="_blank">
                                    <span class="num">1.7万</span><i class="icon-top icon-top2">2</i>【异界幻想】穿越之后的我成了救世之神                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100049620" target="_blank">
                                    <span class="num">1.6万</span><i class="icon-top icon-top3">3</i>【游戏世界】少女安娜不需要眼泪                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100049886" target="_blank">
                                    <span class="num">11.2万</span><i class="icon-top">4</i>【动漫穿越】无限，王座之下                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100037286" target="_blank">
                                    <span class="num">0.8万</span><i class="icon-top">5</i>【异界幻想】圣堂游记                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">宅文强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 宅力无边</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                           <li class="top2">
                                <a href="https://www.hbooker.com/book/100044547" target="_blank">
                                    <span class="num">597.9万</span><i class="icon-top icon-top2">2</i>【动漫穿越】多元宇宙帝国崛起                                </a>
                            </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100044547" target="_blank">
                                    <span class="num">597.9万</span><i class="icon-top icon-top2">2</i>【动漫穿越】多元宇宙帝国崛起                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100044256" target="_blank">
                                    <span class="num">325.2万</span><i class="icon-top icon-top3">3</i>【动漫穿越】我们，卫宫一家，都是英灵                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100044876" target="_blank">
                                    <span class="num">444.6万</span><i class="icon-top">4</i>【动漫穿越】我彩虹小队就要教教你怎么拯救世界！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048490" target="_blank">
                                    <span class="num">10.1万</span><i class="icon-top">5</i>【超现实都市】简单的异能使用方式                                </a>
                            </li>
                                                   
                                            </ul>
                </div>
                                <!--recomm-list end-->
              
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">男生强推</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                      
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050152" target="_blank">
                                    <span class="num">3.7万</span><i class="icon-top icon-top2">1</i>【动漫穿越】穿越失败的救世主                                </a>
                            </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050152" target="_blank">
                                    <span class="num">3.7万</span><i class="icon-top icon-top2">2</i>【动漫穿越】穿越失败的救世主                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100048793" target="_blank">
                                    <span class="num">8.9万</span><i class="icon-top icon-top3">3</i>【女频】伏魔大萨满                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100050228" target="_blank">
                                    <span class="num">20.4万</span><i class="icon-top">4</i>【动漫穿越】我！穿越者！无敌！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100030856" target="_blank">
                                    <span class="num">125.4万</span><i class="icon-top">5</i>【异界幻想】爱丽丝梦游异境                                </a>
                            </li>
                                            
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">女生强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>

                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100049622" target="_blank">
                                    <span class="num">8.7万</span><i class="icon-top icon-top2">1</i>【动漫穿越】弑神者的打工日常                                </a>
                            </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100049622" target="_blank">
                                    <span class="num">8.7万</span><i class="icon-top icon-top2">2</i>【动漫穿越】弑神者的打工日常                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100049951" target="_blank">
                                    <span class="num">4.8万</span><i class="icon-top icon-top3">3</i>【动漫穿越】他以为是穿越者                                </a>
                            </li>
                                                
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            
                            <!--recomm-list start-->
                                <!--recomm-list end-->
                    </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
    
    
    
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>