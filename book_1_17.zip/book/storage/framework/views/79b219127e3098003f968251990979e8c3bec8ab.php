<?php $__env->startSection('nav'); ?>
   <li><a href="/" class='selected'>我的信息</a></li>
               
                <li><a href="<?php echo e(url('novel')); ?>" >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container"  style="height: 1000px">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="javascript:" class="selected">我的书架</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_reader_review_list">我的书评</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="https://www.hbooker.com/recharge/get_reader_wallet">充值中心</a></li>
                    <li><a href="<?php echo e(url('my_info')); ?>">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
        
        <div class="ly-fl bookshelf">
            <div class="mod-box" id="J_BookShelf">
                <div class="mod-tit1">
                    <h3>
                        <i></i>
                                                                                    <span><a class="selected" href="javascript:;">我的书架</a></span>
                                                                        </h3>
                    <div class="ly-fr bookshelf-opt">
                        <a class="manage" href="javascript:;" id="J_manageBookself">+ 管理书架</a>
                        <!--<a class="new" href="javascript:;" id="J_AddBookSelf">新建书架</a>-->
                        <!--<a href="javascript:;" class="drop-down">移动至</a><b></b>-->
                    </div>
                </div>

                <div class="bookshelf-list clearfix" id="J_BookShelfList">
                    <ul>
                            <li>
                                <a class="img" href="https://www.hbooker.com/book/100050877"><img alt="贪吃蛇的目标是吞噬星空" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171216/16-12-17173938-97846-100050877.jpg" class="lazyload"></a>
                                <div class="mask"></div>
                                <div class="tit"><a data-book-id="100050877" href="https://www.hbooker.com/book/100050877" target="_blank">贪吃蛇的目标是吞噬星空</a></div>
                                  <i class="new">更</i>
                                <div class="mask2"></div>
                                <div class="info">
                                    <table>
                                        <tr>
                                            <!--<td>阅读至:<br>--> <!-- test -->
                                            <td>更新至:
                                                <p>22  我们近月巫女对男人不感兴趣的（第二更）</p><!-- 截取14个字 -->
                                                更新时间:<br>
                                                2017-12-22 13:10:17<br>
                                            </td>

                                        </tr>
                                    </table>
                                    <div class="operate">
                                        <span class="J_deleteBook"><i class="icon icon-delete"></i></span>
                                        <div class="ly-fr bookshelf-l J_Bookshelf-l">
                                            <a href="javascript:;" class="drop-down">移动至<b></b></a>
                                            <ul style="display: none;">
                                                                                                <li><a href="javascript:;" data-book-id="100050877" data-shelf-id="2590455" title="我的书架">我的书架</a></li>
                                                                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <a target="_blank" href="https://www.hbooker.com/book/100050877" class="go">&nbsp;</a>
                            </li>
                                           
                     </ul>
                </div>
            </div>
        </div>

        <!--我的关注,我的粉丝 start-->
        
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>