    


<?php $__env->startSection('content'); ?>   
    
    
      


<div class="container">
    <div class="ly-wrap">
      
        <div class="ly-main">
            <div class="search-form ly-mt30">
                <form name="myform" action="http://www.hbooker.com/get-search-book-list" method="get" onsubmit="get_search_book_list();return false;">
                    <input type="text" name="keyword" id="keyword" autocomplete="off" data-type="0" value="3" placeholder="输入你感兴趣的作者作品" data-url="http://www.hbooker.com/get-search-book-list/{key}"></button>
                </form>
            </div>
            <div class="search-result ly-mt30">有 <span>32884</span> 条符合关键词""的搜索结果</div>
            <div class="charts-box search-list ly-mt30">
                <div class="box-list">
                    <ul>
                                                                                    <li data-book-id="100019390">
                                    <i>1</i>
                                    <a href="http://www.hbooker.com/book/100019390" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160927/27-09-16110331-5717-100019390.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100019390" target="_blank"><!--<s class="search-ky">崩</s>-->塔尔塔罗斯舰队的奇妙冒险</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/113296" target="_blank">奥蕾迦娜00032</a></p>
                                        <p>最近更新：2017-12-13 01:54:28 / 第343章：跳了跳了啊，蓝点集合</p>
                                        <div class="desc">巨大的要塞伫立在虚无的宇宙中，燃烧着橙色火焰的恒星安静的发出光芒照耀着这个星系里的一切，和无数年前一样。采矿驳船移动着笨重的身躯，缓慢的从船坞中行驶出来，跟上早已等候在前面的工业指挥舰后面。“船头指向XI-784号异常信号区，等待旗舰带跳。干完这一批，我们就有资源造战列舰了。”“了解，今天就挖完它吧！”“超载无人机，超载采矿无人机！”“最好是可以啦！”这是个关于某个由坐在电脑前的死宅们组成的军团，穿越到一个迷样未知世界，并不挣扎但仍旧求生的故事。</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100019390" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                     
                                    </div>
                                </li>
                                                         
                                                            
                                                           
                                                           
                                                            
                                                           
                                                                        </ul>
                </div>
            </div>
            <div class="pagination">
                                    <div class="PageIn">
                        <ul>
                            <li class='selected'><a href='javascript:'>1</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/2" data-ci-pagination-page="2">2</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/3" data-ci-pagination-page="3">3</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/2" data-ci-pagination-page="2" rel="next">>></a></li>                            <li class="pageSkip">
                                <span class="ly-fl">跳转到:</span>
                                <input type="text" id="directPageNum" name="directPageNum" class="ly-fl skipBox" value="1">
                                <span class="ly-fl">/<i>33</i>页</span>
                                <a class="ly-fl pageSkipQd" href="javascript:void(0);" onclick="">确认</a>
                            </li>
                            <input type="hidden" value="http://www.hbooker.com/get-search-book-list/3/" name="curr_url" id="curr_url">
                        </ul>
                    </div>
                            </div>
        </div>
  

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->







    
    
       
    <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>