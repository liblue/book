    

<?php $__env->startSection('content'); ?>   
    
<div class="container">
    <div class="ly-wrap">

        <div class="ly-main">
            
            <div class="first-col">
                <div class="banner banner-top J_Slider ly-fl">
                    <a href="javascript:;" class="slider-btn prev"></a>
                    <a href="javascript:;" class="slider-btn next"></a>
                    <ul>
                                                                                <li>
                                <a href="<?php echo e(url('novel')); ?>" target="_blank">
                          
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171205033229566.jpg" alt="">  </a>
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="http://app.hbooker.com/setting/event?item=tonggao_tz&noticeid=53" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                              
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/publicity_dec" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171212104114173.jpg" alt="">   </a>
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/publicity_dec" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                             
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171115095550417.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/yuanchuang" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20170901100447582.png" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/yuanchuang" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/book/100046943" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208024751496.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/book/100046943" target="_blank">
                                                驱魔人信条                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/book/100049742" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030210217.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/book/100049742" target="_blank">
                                                最强编辑                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/book/100000514" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171209044110807.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/book/100000514" target="_blank">
                                                比企谷雪乃的养成日记                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                                        </ul>
                </div>
                <ul class="topic ly-fl" id="J_Topic">
                                                                    <li>
                            <a href="https://www.hbooker.com/book/100047787" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030947512.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【咸鱼难翻身】</div>
                                    <div class="n">没错，我就是大流士lily！</div>
                                    <div class="num">6457人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100025268" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031005344.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【吾有八宗罪】</div>
                             
                                    <div class="num">64505人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047734" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171124023856998.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【幽幽之灵】</div>
                            
                                    <div class="num">3634人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047912" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031041982.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【咸鱼萝莉三】</div>
                             
                                    <div class="num">1205人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047681" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031055305.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【胖子可以变身】</div>
                               
                                    <div class="num">1882人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047146" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031111876.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【智神大人】</div>
                      
                                    <div class="num">114人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                            </ul>
            </div>

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>宅文推荐</h3>
                        <i class="line"></i>
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                        <li>
                                <a class="img" href="<?php echo e(url('content')); ?>" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17102341-79943-100049774.jpg" alt="我和Caster谈恋爱">
                                    <div class="mask"></div>
                                    <div class="info"><?php echo e(url('content')); ?>

                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-02/189853/avatar/thumb_85b543775ee54d6436914d2edadc95c1.jpeg" alt="">【殁言】</div>
                                        <div class="n">你问我美狄亚哪里好？体贴、温柔还有偶尔的小性子无时无刻都在吸引着我除了......咳咳，偶尔......不胜腰力</div>
                                        <div class="num">3806<i></i></div>
                                    </div> 
                                                                    </a>
                                <div class="title"><a href="<?php echo e(url('novel')); ?>" title="我和Caster谈恋爱" target="_blank">我和Caster谈恋爱</a></div>
                                <div class="info"><span>55.5万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        
                                                    </ul>
                    </div>
                
            </div>
            <!--mod-box end-->



            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>同人推荐</h3>
                        <i class="line"></i>
                  
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048120" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171205/05-12-17010424-56806-100048120.jpg" alt="我，女武神八重凛（八重傲天）！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/1418305/avatar/thumb_b4e53d2b37d9a60d83ff80f4cb744179.jpg" alt="">【凌小潇】</div>
                                            <div class="n">真正的八重凛已经死了，我只不过是她的复制品而已。一个用八重樱的基因制造出来的人造人而已。我不是很清楚我被制造出来的意义到底是什么。“为什么要来受死呢？”“女武神是脆弱的。”“律者也是。”ps：文中会直接出现对人物的特定称谓，非崩崩崩玩家可以先去科普一下游戏设定，当然并非崩崩崩玩家也能愉快的观看。</div>
                                            <div class="num">1643<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048120" title="我，女武神八重凛（八重傲天）！" target="_blank">我，女武神八重凛（八重傲天）！</a></div>
                                    <div class="info"><span>31.0万</span>︱<span>游戏世界</span></div>
                                </li>
                                                                                
                                                          
                                                           
                                                            
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049937" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171130/30-11-17091305-1814-100049937.jpg" alt="我所攻略的未来，被重叠了">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img/19975/avatar/thumb_bb4f0ad55a854a9a894056428c6f4e1e.jpg" alt="">【緋夜笑】</div>
                                            <div class="n">我，吴诚，是一位时空秩序维护者。我的工作是负责修正被扭曲的世界线。做为退休的奖励，选择在日本重生至17岁，本来打算就这样当一个普通高中生，悠闲的度过一生。但就在这个时候，身边的女性突然多了起来。为什么突然多一个干妹妹，还被父母如此放心的送到日本这边由我来照顾?为什么同桌每次上课的时候都要拿她的黑丝长腿蹭我的脚?为什么隔壁家突然搬来一个没什么存在感，却总是在不经意的时候撞见她?白、霞之丘诗羽、加藤惠……还有越来越多的女性闯入他安逸的生活“为什么……明明是我先的，不管是被他所拯救也好，喜欢上他也好，明明是我先的，为什么有这么多的碧池在跟我抢哥哥。”“闭嘴!!是我先的”xn总之这是个无数条世界线被重叠后交织出来的白学未来书友群：600936678欢迎加入水群和讨论剧情求月票求推荐票求打赏~~~</div>
                                            <div class="num">17083<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049937" title="我所攻略的未来，被重叠了" target="_blank">我所攻略的未来，被重叠了</a></div>
                                    <div class="info"><span>222.3万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                                      </ul>
                    </div>
                            </div>
            <!--mod-box end-->




            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>男生推荐</h3>
                        <i class="line"></i>
                       
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048661" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171101/01-11-17164210-53941.jpg" alt="老师，我不想结婚">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-03/1291625/avatar/thumb_35d5c4ad4e3a2b700983fa1b6bf62f79.jpg" alt="">【一天不吃肉就要死】</div>
                                            <div class="n">本来已经创造了一个美好的国家，没想到，人类是如此的贪婪，为了欲望，他们甚至蚕食同类。常树原本放弃了一切，只想做一个普通人，做一个普通的高中生...但那群人的触手又一次伸了过来</div>
                                            <div class="num">3792<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048661" title="老师，我不想结婚" target="_blank">老师，我不想结婚</a></div>
                                    <div class="info"><span>105.5万</span>︱<span>超现实都市</span></div>
                                </li>
                                                         
                                                               
                                                          
                                                               
                                                          
                                                            
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->


   

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>女生推荐</h3>
                        <i class="line"></i>
                       
                     
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100045193" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170914/14-09-17210835-54954.jpg" alt="咕哒子的圣杯战争">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【挨揍的会长】</div>
                                            <div class="n">“前辈，出现特异点，前后十年，迦勒底已完全消失在历史之中！有人在故意抹消我们的存在！”“……可以找到线索吗？”“没……不过……前……前辈！”“怎么了？那么慌张？”“那……那个是十年前的前辈吗？卡哇伊……”</div>
                                            <div class="num">731<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100045193" title="咕哒子的圣杯战争" target="_blank">咕哒子的圣杯战争</a></div>
                                    <div class="info"><span>21.4万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                         
                                                       
                                                           
                                                                     
                                                          
                                                         
                                                        
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->

   


            <!--mod-box start-->
                        <div class="mod-box ly-mt60">
             

                <div class="mod-body">
                    <div class="book-list-table-wrap">
                  
                    </div>
                </div>
            </div>
                        <!--mod-box end-->
        </div>
        <div class="ly-side index-side">
            <!-- 公告 begin -->
            <div class="big-event">
                                                                                        <div><a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://www.hbooker.com/resources/imagesactivity/zhengwen_nov_banner.jpg" alt="活动"></a></div>
                                                                                                <div><a href="https://www.hbooker.com/index/fuli" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_notice/20170601112204377.jpg" alt=""></a></div>
                                                                        </div>
            <!-- 公告 end -->
            <div class="recomm-tit ly-mt30">
                <h4>精选荣誉榜单</h4>
            </div>

                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">主编强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 精挑细选</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100038671" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170719/19-07-17155944-511-100038671.jpg" alt="">
                                <span class="num">69.4万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【未来幻想】变身二次元角色拯救世界吧</p>
                                <p class="author">正在旅行的穿越者</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050129" target="_blank">
                                    <span class="num">1.7万</span><i class="icon-top icon-top2">2</i>【异界幻想】穿越之后的我成了救世之神                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100049620" target="_blank">
                                    <span class="num">1.6万</span><i class="icon-top icon-top3">3</i>【游戏世界】少女安娜不需要眼泪                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100049886" target="_blank">
                                    <span class="num">11.2万</span><i class="icon-top">4</i>【动漫穿越】无限，王座之下                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100037286" target="_blank">
                                    <span class="num">0.8万</span><i class="icon-top">5</i>【异界幻想】圣堂游记                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">宅文强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 宅力无边</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                           <li class="top2">
                                <a href="https://www.hbooker.com/book/100044547" target="_blank">
                                    <span class="num">597.9万</span><i class="icon-top icon-top2">2</i>【动漫穿越】多元宇宙帝国崛起                                </a>
                            </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100044547" target="_blank">
                                    <span class="num">597.9万</span><i class="icon-top icon-top2">2</i>【动漫穿越】多元宇宙帝国崛起                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100044256" target="_blank">
                                    <span class="num">325.2万</span><i class="icon-top icon-top3">3</i>【动漫穿越】我们，卫宫一家，都是英灵                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100044876" target="_blank">
                                    <span class="num">444.6万</span><i class="icon-top">4</i>【动漫穿越】我彩虹小队就要教教你怎么拯救世界！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048490" target="_blank">
                                    <span class="num">10.1万</span><i class="icon-top">5</i>【超现实都市】简单的异能使用方式                                </a>
                            </li>
                                                   
                                            </ul>
                </div>
                                <!--recomm-list end-->
              
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">男生强推</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                      
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050152" target="_blank">
                                    <span class="num">3.7万</span><i class="icon-top icon-top2">1</i>【动漫穿越】穿越失败的救世主                                </a>
                            </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050152" target="_blank">
                                    <span class="num">3.7万</span><i class="icon-top icon-top2">2</i>【动漫穿越】穿越失败的救世主                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100048793" target="_blank">
                                    <span class="num">8.9万</span><i class="icon-top icon-top3">3</i>【女频】伏魔大萨满                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100050228" target="_blank">
                                    <span class="num">20.4万</span><i class="icon-top">4</i>【动漫穿越】我！穿越者！无敌！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100030856" target="_blank">
                                    <span class="num">125.4万</span><i class="icon-top">5</i>【异界幻想】爱丽丝梦游异境                                </a>
                            </li>
                                            
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">女生强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>

                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100049622" target="_blank">
                                    <span class="num">8.7万</span><i class="icon-top icon-top2">1</i>【动漫穿越】弑神者的打工日常                                </a>
                            </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100049622" target="_blank">
                                    <span class="num">8.7万</span><i class="icon-top icon-top2">2</i>【动漫穿越】弑神者的打工日常                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100049951" target="_blank">
                                    <span class="num">4.8万</span><i class="icon-top icon-top3">3</i>【动漫穿越】他以为是穿越者                                </a>
                            </li>
                                                
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            
                            <!--recomm-list start-->
                                <!--recomm-list end-->
                    </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
    
    
    
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>