<?php $__env->startSection('content'); ?>
   <div class="x-body">
   <form class="layui-form" action="<?php echo e(url('admin/autobook')); ?>" method="post"  enctype="multipart/form-data">
       <?php echo e(csrf_field()); ?>

  <div class="layui-form-item">
    <label class="layui-form-label">书名</label>
    <div class="layui-input-block">
      <input type="text" name="title" lay-verify="title" autocomplete="off" placeholder="请输入" class="layui-input">
    </div>
  </div>
     <div class="layui-form-item">
           <div  id = "result"> </div>
           <label class="layui-form-label">封面</label>
    <div class="layui-input-block">
   <div id="image-holder"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170801/01-08-17220808-50067.jpg" width="150px" height="200px" /></div>
   <input id="fileUpload" type="file"  name="myfile" /><br />
   <!--<input type="file" name="myfile" />-->
    </div>
     
  
  
  </div>
   
          <script>
        
        $("#fileUpload").on('change', function () {
 
    if (typeof (FileReader) !== "undefined") {
 
        var image_holder = $("#image-holder");
        image_holder.empty();
 
        var reader = new FileReader();
        reader.onload = function (e) {
            $("<img />", {
                "src": e.target.result,
                "class": "thumb-image",
                "height":"200px",
                "width":"150px"
             
                
            }).appendTo(image_holder);
 
        };
        
        image_holder.show();
        reader.readAsDataURL($(this)[0].files[0]);
    } else {
        alert("你的浏览器不支持FileReader.");
    }
});
        </script>
           <div class="layui-form-item">
    <label class="layui-form-label">进程</label>
    <div class="layui-input-block">
      <input type="radio" name="status" value="1" title="连载中" checked="">
      <input type="radio" name="status" value="2" title="已完结">
    
    </div>
  </div>
      <div class="layui-form-item">

    <div class="layui-inline">
      <label class="layui-form-label">类别</label>
      <div class="layui-input-inline" style="margin-left:30px">
        <select name="cate" lay-verify="required" lay-search="">
          <option value="玄幻">直接选择或搜索选择</option>
          <option value="玄幻">玄幻</option>
          <option value="女生">女生</option>
          <option value="悬疑">悬疑</option>
          <option value="修仙">修仙</option>
          <option value="穿越">穿越</option>
          <option value="现代">现代</option>
          <option value="架空">架空</option>
          <option value="宅文">宅文</option>
        </select>
      </div>
    </div>
  </div>
        
        
          <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">简介</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea" name="intro"></textarea>
    </div>
  </div>
          <div class="layui-form-item">
              <label for="L_repass" class="layui-form-label">
              </label>
              <input  type="submit" class="layui-btn" lay-filter="add"  value="增加" lay-submit="">
                 
              
          </div>
      </form>
    </div>
    <script>
        layui.use(['form','layer'], function(){
            $ = layui.jquery;
          var form = layui.form
          ,layer = layui.layer;
        
 
          
        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>