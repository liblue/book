<?php $__env->startSection('nav'); ?>
   <li><a href="<?php echo e(url('user')); ?>" >我的信息</a></li>
               
                <li><a href="/" class='selected' >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="<?php echo e(url('author')); ?>" >我的作品</a></li>
                    <li><a href="<?php echo e(url('author/create')); ?>" class="selected">新建作品</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="<?php echo e(url('au_purse')); ?>">我的收入</a></li>
                    <li><a href="https://www.hbooker.com/reader/my_info">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
        
        <div class="ly-fl bookshelf" style="width: 80%">
     
          

             
<form class="layui-form" action="<?php echo e(url('author/set')); ?>" method="post"  enctype="multipart/form-data">
    
     <?php echo e(csrf_field()); ?>

  <div class="layui-form-item">
    <label class="layui-form-label">书名</label>
    <div class="layui-input-block">
      <input type="hidden" name="id"  value="<?php echo e($novel->id); ?>">
        <input type="text" name="title" lay-verify="title" autocomplete="off" placeholder="请输入" class="layui-input" value="<?php echo e($novel->title); ?>">
    </div>
  </div>
     <div class="layui-form-item">
           <div id = "result"> </div>
           <label class="layui-form-label">封面</label>
    <div class="layui-input-block">
   <div id="image-holder"><img src="<?php echo e(asset($novel->pic_addr)); ?>" width="150px" height="200px" /></div>
   <input id="fileUpload" type="file"  name="myfile" /><br />
   <!--<input type="file" name="myfile" />-->
    </div>
     
  
  
  </div>
    <script>
        
        $("#fileUpload").on('change', function () {
 
    if (typeof (FileReader) !== "undefined") {
 
        var image_holder = $("#image-holder");
        image_holder.empty();
 
        var reader = new FileReader();
        reader.onload = function (e) {
            $("<img />", {
                "src": e.target.result,
                "class": "thumb-image",
                "height":"200px",
                "width":"150px"
             
                
            }).appendTo(image_holder);
 
        };
        
        image_holder.show();
        reader.readAsDataURL($(this)[0].files[0]);
    } else {
        alert("你的浏览器不支持FileReader.");
    }
});
        </script>
    

    <div class="layui-form-item">
    <label class="layui-form-label">进程</label>
    <div class="layui-input-block">
             <?php if($novel->status===1): ?>
      <input type="radio" name="status" value="1" title="连载中" checked="">
      <input type="radio" name="status" value="2" title="已完结">
      <?php else: ?>
     <input type="radio" name="status" value="1" title="连载中" >
      <input type="radio" name="status" value="2" title="已完结" checked="">
      <?php endif; ?>
    </div>
  </div>
      <div class="layui-form-item">

    <div class="layui-inline">
      <label class="layui-form-label">类别</label>
      <div class="layui-input-inline" style="margin-left:30px">
        <select name="cate" lay-verify="required" lay-search="">
          <option value="">直接选择或搜索选择</option>
         
          <option value="玄幻">玄幻</option>
          <option value="16">table</option>
          <option value="17">select</option>
          <option value="18">checkbox</option>
          <option value="19">switch</option>
          <option value="20">radio</option>
        </select>
      </div>
    </div>
  </div>
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">简介</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea" name="intro"><?php echo e($novel->intro); ?></textarea>
    </div>
  </div>

  <div class="layui-form-item">
    <div class="layui-input-block">
        <button class="layui-btn" type="submit"  lay-filter="demo1">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>
             
           
        </div>

        <!--我的关注,我的粉丝 start-->
        <div class="ly-side" style="display: none">
            <div class="mod-box fans">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的关注</span></h3>
                </div>
            </div>

            <div class="mod-box fans ly-mt45">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的粉丝</span></h3>
                </div>
            </div>
        </div>
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>

<script>
layui.use(['form', 'layedit', 'laydate'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  
  //日期
  laydate.render({
    elem: '#date'
  });
  laydate.render({
    elem: '#date1'
  });
  
  //创建一个编辑器
  var editIndex = layedit.build('LAY_demo_editor');
 

  

  //监听提交
  form.on('submit(demo1)', function(){
    if(value.length < 0){
       return '标题至少得5个字符啊';
     }
    return false;
  });
  
  
});
</script>


<script>
layui.use('upload', function(){
  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/upload/'
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
   ,done: function(res){ //res 不需要转换JSON，直接用即可
      if(res.code == 0){
      
layer.msg('上传成功！');
      }
    }
  
  });
  
});
</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>