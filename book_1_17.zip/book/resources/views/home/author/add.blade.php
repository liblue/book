@extends('layout.user')
@section('nav')
   <li><a href="{{url('myself')}}" >我的信息</a></li>
               
                <li><a href="/" class='selected' >我是作者</a></li>
@endsection

@section('content')

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="{{url('author')}}" >我的作品</a></li>
                    <li><a href="{{url('author/create')}}" class="selected">新建作品</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="{{url('au_purse')}}">我的收入</a></li>
                    <li><a href="https://www.hbooker.com/reader/my_info">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
        
        <div class="ly-fl bookshelf" style="width: 80%">
     
          

             
<form class="layui-form" action="{{url('author')}}" method="post"  enctype="multipart/form-data">
    
     {{csrf_field()}}
  <div class="layui-form-item">
    <label class="layui-form-label">书名</label>
    <div class="layui-input-block">
      <input type="text" name="title" lay-verify="title" autocomplete="off" placeholder="请输入" class="layui-input">
    </div>
  </div>
     <div class="layui-form-item">
           <div  id = "result"> </div>
           <label class="layui-form-label">封面</label>
    <div class="layui-input-block">
   <div id="image-holder"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170801/01-08-17220808-50067.jpg" width="150px" height="200px" /></div>
   <input id="fileUpload" type="file"  name="myfile" /><br />
   <!--<input type="file" name="myfile" />-->
    </div>
     
  
  
  </div>
    <script>
        
        $("#fileUpload").on('change', function () {
 
    if (typeof (FileReader) !== "undefined") {
 
        var image_holder = $("#image-holder");
        image_holder.empty();
 
        var reader = new FileReader();
        reader.onload = function (e) {
            $("<img />", {
                "src": e.target.result,
                "class": "thumb-image",
                "height":"200px",
                "width":"150px"
             
                
            }).appendTo(image_holder);
 
        };
        
        image_holder.show();
        reader.readAsDataURL($(this)[0].files[0]);
    } else {
        alert("你的浏览器不支持FileReader.");
    }
});
        </script>
    

    <div class="layui-form-item">
    <label class="layui-form-label">进程</label>
    <div class="layui-input-block">
      <input type="radio" name="status" value="1" title="连载中" checked="">
      <input type="radio" name="status" value="2" title="已完结">
    
    </div>
  </div>
      <div class="layui-form-item">

    <div class="layui-inline">
      <label class="layui-form-label">类别</label>
      <div class="layui-input-inline" style="margin-left:30px">
    
         
      <select name="cate" lay-verify="required" lay-search="">
          <option value="玄幻">直接选择或搜索选择</option>
          <option value="玄幻">玄幻</option>
          <option value="女生">女生</option>
          <option value="悬疑">悬疑</option>
          <option value="修仙">修仙</option>
          <option value="穿越">穿越</option>
          <option value="现代">现代</option>
          <option value="架空">架空</option>
          <option value="宅文">宅文</option>
        </select>
      </div>
    </div>
  </div>
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">简介</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea" name="intro"></textarea>
    </div>
  </div>

  <div class="layui-form-item">
    <div class="layui-input-block">
        <button class="layui-btn" type="submit"  lay-filter="demo1">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>
             
           
        </div>

        <!--我的关注,我的粉丝 start-->
        <div class="ly-side" style="display: none">
            <div class="mod-box fans">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的关注</span></h3>
                </div>
            </div>

            <div class="mod-box fans ly-mt45">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的粉丝</span></h3>
                </div>
            </div>
        </div>
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>

<script>
layui.use(['form', 'layedit', 'laydate'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  
  //日期
  laydate.render({
    elem: '#date'
  });
  laydate.render({
    elem: '#date1'
  });
  
  //创建一个编辑器
  var editIndex = layedit.build('LAY_demo_editor');
 

  

  //监听提交
  form.on('submit(demo1)', function(){
    if(value.length < 0){
       return '标题至少得5个字符啊';
     }
    return false;
  });
  
  
});
</script>


<script>
layui.use('upload', function(){
  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/upload/'
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
   ,done: function(res){ //res 不需要转换JSON，直接用即可
      if(res.code == 0){
      
layer.msg('上传成功！');
      }
    }
  
  });
  
});
</script>



@endsection
