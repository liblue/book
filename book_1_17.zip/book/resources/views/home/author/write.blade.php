@extends('layout.user')
@section('nav')
   <li><a href="{{url('myself')}}" >我的信息</a></li>
               
                <li><a href="{{url('author')}}" class='selected' >我是作者</a></li>
@endsection

@section('content')

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
<!--        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="{{url('author')}}" class="selected">我的作品</a></li>
                    <li><a href="{{url('author/create')}}" >新建作品</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="{{url('au_purse')}}">我的收入</a></li>
                    <li><a href="https://www.hbooker.com/reader/my_info">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>-->
        
        <div class="ly-fl bookshelf" style="width: 80%">
     
          
  <div class="layui-form-item">
      <a href="{{url('author')}}" ><button class="layui-btn layui-btn-primary"> 返回作品管理 </button>  </a>
    <div class="layui-input-block">
   
    </div>
  </div>
                
                          

<form class="layui-form" action="{{url('author/putcon')}}"  method="post">
        {{csrf_field()}}
  <div class="layui-form-item">
    <label class="layui-form-label">章节名</label>
    <div class="layui-input-block">
              <input type="hidden" name="file_name" value="{{$file_name}}">
      <input type="text" name="chapter" lay-verify="title" autocomplete="off" placeholder="请输入" class="layui-input">

    </div>
  </div>
  
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">内容</label>
    <div class="layui-input-block"  >
        <textarea placeholder="请输入内容" class="layui-textarea" name="content" style="min-height: 200px"></textarea>
    </div>
  </div>
<div class="layui-form-item layui-form-text">
    <label class="layui-form-label">备注</label>
    <div class="layui-input-block"  >
        <textarea placeholder="说点什么吧" class="layui-textarea"  style="min-height: 100px"></textarea>
    </div>
  </div>


  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit="" lay-filter="demo1">立即发布
      </button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
  
</form>
             
           
        </div>

        <!--我的关注,我的粉丝 start-->
        <div class="ly-side" style="display: none">
            <div class="mod-box fans">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的关注</span></h3>
                </div>
            </div>

            <div class="mod-box fans ly-mt45">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的粉丝</span></h3>
                </div>
            </div>
        </div>
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>



@endsection