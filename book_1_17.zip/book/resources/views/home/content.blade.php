@extends('layout.home')
    


@section('content')   






<div class="container">
    <div class="ly-wrap">



        <!--书页 start-->
        <div class="book-detail ly-mt45">

            <!-- ly-main -->
            <div class="ly-main">
                <div class="book-hd clearfix">
                    <div class="ly-fl book-img">
                        <div class="book-cover">
                            <img src="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17083025-15059-100050129.jpg" alt="穿越之后的我成了救世之神">
                        		
                        </div>
                        <ul class="book-operating">
                            <li><a class="read" href="https://www.hbooker.com/chapter-list/100050129/book_detail">点击阅读</a></li>
                            <li> <a class='J_ShouCang' href="javascript:">收藏</a> </li>
                          
                        </ul>
                    </div>
                    <div class="ly-fl book-info">
                        <div class="book-title">
                            <h1>穿越之后的我成了救世之神</h1>
                            <p><span>小说作者：</span><a href="https://www.hbooker.com/reader/2567964" target="_blank" class="">可乐面包</a></p>
                        </div>
                        <!--act-tab start-->
                        <div class="book-bd act-tab">
                            <div>
                                <span class="time-update ly-fr">更新时间：2018-01-15 22:49:04</span>
                                <ul class="act-tab-titles clearfix">
                                    <li class="selected"><a href="javascript:">作品简介</a></li>
                                    <li><a href="javascript:">作品信息</a></li>
                                    <li><a href="javascript:">作者信息</a></li>
                                </ul>
                            </div>
                            <div class="book-cnt">
                                <!--act-tab-content start-->
                                <div class="act-tab-content">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-count clearfix">
                                                <ul class="ly-fl">
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总点击：4.2万                                                    </li>
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总收藏：<b class="J_Stock_Favor_total">123</b>
                                                    </li>
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总字数：302152                                                    </li>
                                                </ul>
                                                <span class="ly-fl book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            	                                            </div>
                                            <div class="book-desc J_mCustomScrollbar">
                                                                                                一不小心穿越了，却意外成了一个精灵族人……<br />
伊泽表示，头顶上的那对呆萌呆萌的耳朵似乎不适合他冷酷潇洒的人设。<br />
而更加奇妙的是，他认识了肌肉萝莉牛头人、女pu装大侠兔女郎、喜欢打牌的地精小弟弟以及长发及袜的战争女神……<br />
于是他一咬牙，毅然决然地把长耳朵别进了腰带，骑上了黑龙，开始了他的拯救世界之旅。                                            </div>
                                        </div>
                                    
                           
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-property clearfix">
                                                <span><i class="icon-diamond">◆</i> 小说性质：免费书籍</span>
                                                <span><i class="icon-diamond">◆</i> 总点击: 4.2万</span>
                                                <span><i class="icon-diamond">◆</i> 月点击：1.1万</span>
                                                <span><i class="icon-diamond">◆</i> 周点击：0.1万</span>
                                                <span><i class="icon-diamond">◆</i> 小说类别：异界幻想</span>
                                                <span><i class="icon-diamond">◆</i> 总推荐：<b class="J_Recommend_Rec_total">24</b></span>
                                                <span><i class="icon-diamond">◆</i> 月推荐：<b class="J_Recommend_Rec_month">19</b></span>
                                                <span><i class="icon-diamond">◆</i> 周推荐：<b class="J_Recommend_Rec_week">0</b></span>
                                                <span><i class="icon-diamond">◆</i> 总月票：0</span>
                                                <span><i class="icon-diamond">◆</i> 当月月票：0</span>
                                                <span><i class="icon-diamond">◆</i> 总刀片：0</span>
                                                <span><i class="icon-diamond">◆</i> 月刀片：0</span>
                                                <span><i class="icon-diamond">◆</i> 完成字数：302152</span>
                                                <span><i class="icon-diamond">◆</i> 写作状态：连载中</span>
                                                <span class="book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            </div>
                                        </div>
                                >
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-author-info">
                                                <div><i class="icon-diamond">◆</i> 作者的其它作品：</div>
                                                <ul class="clearfix">
                                                    暂无其他作品
                                                </ul>
                                            </div>
                                        </div>
                                     
                             
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                            </div>
                        </div>
                        <!--act-tab end-->
                    </div>
                </div>
                <div class="book-ft">
                    <div class="book-chapter">

                                                <div class="mod-box ly-mt60">
                            <div class="mod-tit1">
                                <h3><i></i>穿越之后的我成了救世之神<span>最新章节试阅</span></h3>
                                <a class="ly-fr" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149" target="_blank">阅读本章 ></a>
                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-new">
                                    <div class="tit">第122章 听指挥      更新时间：2018-01-15 22:49:04</div>
                                    <div class="desc box-shadow">　　少有地，传奇灰矮人牧师制止了他，转头对伊泽说道：“都走到这里了，我们的利益应该是一致的，凭你的实力也很难独自走回去吧？你说，我们要怎么办？给出一个合理的建议，我想我们会接受的。”
　　伊泽先举起第..</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mod-box ly-mt30">
                            <div class="mod-tit1">
                                <h3><i></i>章节列表</h3>
                                                                    
                                                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-list ly-mt30">
                                                                            <ul class="clearfix less">
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                               
                                                                                    </ul>
                                    <ul class="clearfix less" id="chapter" style='display:none'>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101523149"><i class="line"></i>第122章 听指挥</a></li>
                                                                                               
                                                                                           
                                                                                    </ul>
                                    <div class="read-all"  onclick="show()"><a id="J_ReadAll" href="javascript:;">+ 查看全部章节</a></div>
                                                                                                                          
                                                                                                            </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt60">
                            <div name="book_detail_item" id="book_detail_item" class="mod-tit1">
                                <h3><i></i>书评区</h3>
                            </div>
                        
                            <div class="mod-bd">
                                <div class="book-chapter-comment J_BookChapterComment" id="book_review_box">
                                    <textarea class="J_CommentInput comment-input" maxlength="1000" placeholder="快来吐槽这本书吧，注意文明用语哦\^o^/"></textarea>
                                    <div class="clearfix ly-mt10 repo">
                                        <div class="ly-fl">
                                            <div class="comment-face J_Face">
                                                <div class="face-btn"><i></i>颜文字</div>
                                                <div class="J_FaceDialog face-dialog" style="display:block;visibility:hidden">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ly-fr"><span class="J_CommentWordsCount">0</span>/<span class="J_CommentWordsCountLimit">1000</span><a href="javascript:;" class="J_ReplayBtn replay-btn ly-ml10">发表</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt30">
                            <div class="comment-list">
                                <ul class="J_CommentList">

                                </ul>
                                <!--<input type="hidden" value="" name="curr_url" id="curr_url">-->
                            </div>
                        </div>

                    </div>

                    <div class="mod-box ly-mt30">
                        <div class="mod-tit1 ly-mr30">
                            <h3><i></i> 同类作品</h3>
                           
                        </div>
                        <div class="mod-bd">
                            <ul class="book-list book-list2 J_BookList">
                                                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100042908" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170826/26-08-17120916-36441-100042908.jpg" alt="盗贼与魔物娘">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/191213/avatar/thumb_c35388007b75291b9de6fa27cb43a9b2.jpg" alt="">小宁海</div>
                                                <div class="n">《魔物娘图鉴》世界观小说。魔物原本是人类的天敌，以残杀人类为乐，以人类血肉为食。这种情况在一个魅魔成为魔王后发生了改变，所有的魔物都变成了美丽可爱的魔物娘，且只有雌性，对人类的敌意也转变成了另一种强烈的情感。虽然人类和魔物的矛盾随着魔物的改变似乎消除了，但是事情并没有这么简单，更多的矛盾随着更深的隐情的曝光而激化。故事以一个带着异世界知识转生的盗贼的视角展开。“能来阴的，绝对不来硬的。”“没有什么问题是一把火解决不了的，如果有，那就在来一把。”“我才不管那些大道理呢！我又不是皇帝！我也不要做皇帝！”“我是纯爱主义者，你们这些魔物娘不准窥视我冰清玉洁的肉体！”</div>
                                                <div class="num">6547<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100042908" title="盗贼与魔物娘" target="_blank">盗贼与魔物娘</a></div>
                                        <div class="info"><span>248.8万</span>︱<span>异界幻想</span></div>
                                    </li>
                                                                      
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100044535" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c180109/09-01-18084158-33871-100044535.jpg" alt="十二岁当上皇后的我为什么要那么操劳">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-01/476834/avatar/thumb_559840f52925bba1d7d05e0aabbf03f8.jpeg" alt="">木风萝莉控</div>
                                                <div class="n">本喵要投诉！哪有使用诓骗的方法让人穿越的！哪有穿越过去还性转的！哪有穿越还附赠老公的！哪有穿越给的金手指还自称本产品的！</div>
                                                <div class="num">396<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100044535" title="十二岁当上皇后的我为什么要那么操劳" target="_blank">十二岁当上皇后的我为什么要那么操劳</a></div>
                                        <div class="info"><span>9.6万</span>︱<span>异界幻想</span></div>
                                    </li>
                                                                                                </ul>
                        </div>
                    </div>

                </div>
            </div>
            <!-- ly-main -->


            <!-- ly-side -->
            <div class="ly-side">

                <!-- 给作者打赏 start-->
                <div class="mod-box">
                    <div class="mod-tit1">
                        <h3><i></i>给作者打赏</h3>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-reward box-shadow">
                            <div class="smile"></div>
                            <button type="button" class="J_DaShang" data-type="shang">打赏~么么哒~~</button>
                            <button type="button" class="btn-primary J_DaShang" data-type="prop">不更新？寄刀片！</button>
                        </div>
                    </div>
                </div>
                <!--给作者打赏 end-->

                <!--粉丝支持 start-->
                <div class="mod-box ly-mt30">
                    <div class="mod-tit1">
                        <h3><i></i>粉丝支持</h3></a>
                    </div>
                    <div class="mod-bd ly-mt45">
                        <div class="book-fans-support box-shadow">
                            加载中...
                        </div>
                    </div>
                </div>
                <!--粉丝支持 end-->

                <!--本书名人榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i>本书名人榜</h3></a>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-leaderboard box-shadow">
                            <ul>
                                <li>
                                    加载中...
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--本书名人榜 end-->


                <div class="fans-tit ly-mt45">
                    <h4>粉丝荣誉榜单</h4>
                </div>

                <!--铁杆粉丝榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i>铁杆粉丝榜</h3></a>
                    </div>
                    <div class="mod-bd ly-mt30" style="background:#fafafa">
                        <div class="book-fansboard">
                            <ul>加载中...</ul>
                        </div>
                    </div>
                </div>
                <!--铁杆粉丝榜 end-->
    
            </div>
            <!-- ly-side -->

        </div>
        <!--书页 end-->


        <div class="go-top" id="J_GoTop">
            <a href="javascript:">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->


<script>
    
    function show(){
        
    if($("#chapter").is(":hidden")){
        
        $("#chapter").show();
          $("#J_ReadAll").text("+ 收起");
    } 
    else{
        
          $("#chapter").hide()
        
           $("#J_ReadAll").text("+ 查看全部章节");
          
    }
    }
    </script>








@endsection

