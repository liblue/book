-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?01 �?17 �?03:48
-- 服务器版本: 5.5.53
-- PHP 版本: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `novel`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) NOT NULL,
  `password` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- 表的结构 `cates`
--

CREATE TABLE IF NOT EXISTS `cates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `enname` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `cates`
--

INSERT INTO `cates` (`id`, `name`, `enname`) VALUES
(1, '玄幻', 'xuanhuan'),
(2, '女生', 'girl'),
(3, '悬疑', 'xuanyi'),
(4, '修仙', 'xiuxian'),
(5, '穿越', 'chuanyue'),
(6, '现代', 'modern'),
(7, '架空', 'jiakong'),
(8, '宅文', 'zhaiwen');

-- --------------------------------------------------------

--
-- 表的结构 `checks`
--

CREATE TABLE IF NOT EXISTS `checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `come` varchar(64) NOT NULL,
  `to` int(255) NOT NULL,
  `yuan` varchar(32) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `novels`
--

CREATE TABLE IF NOT EXISTS `novels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL,
  `author` varchar(32) NOT NULL,
  `intro` text NOT NULL,
  `pic_addr` varchar(64) NOT NULL,
  `content_addr` varchar(64) NOT NULL,
  `cate` varchar(32) NOT NULL,
  `date` varchar(32) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '连载是1完结是2',
  `chapter` text NOT NULL COMMENT '章节',
  `favorate` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=117 ;

--
-- 转存表中的数据 `novels`
--

INSERT INTO `novels` (`id`, `title`, `author`, `intro`, `pic_addr`, `content_addr`, `cate`, `date`, `status`, `chapter`, `favorate`) VALUES
(72, '2222', '用户1513908299', '2222', '', '', '玄幻', '1514342677', 2, '@11111@2222@333', 0),
(76, '555', '用户1513908299', '5555', '', '', '玄幻', '1514342964', 1, '', 0),
(70, '1111', '用户1513908299', '11111', '', '', '玄幻', '1514342524', 1, '', 0),
(81, 'adasd', '用户1513908299', 'asda', '', '', '玄幻', '1514346250', 1, '', 0),
(82, '546', '用户1513908299', '54', '', '', '玄幻', '1514346344', 1, '', 0),
(83, 'sdfasd', '用户1513908299', 'dsfsd', '', '', '玄幻', '1514356361', 1, '', 0),
(84, 'sdasd', '用户1513908299', 'asxdasd', '', '', '玄幻', '1514359016', 1, '', 0),
(85, 'dsfadsf', '用户1513908299', 'dfsda', 'photo/1514362997.jpg', '', '玄幻', '1514362997', 1, '', 1),
(86, '56', '用户1513908299', 'kjhk', 'photo/1514363210.jpg', '', '玄幻', '1514363210', 1, '', 1),
(87, 'dfsdfsdf', '用户1513908299', 'fdgdfg', 'photo/1514363625.jpg', '', '玄幻', '1514363625', 2, '', 1),
(88, 'dfgdfsgffd', '用户1513908299', 'dfgdfgdf', 'photo/1514363718.jpg', '', '玄幻', '1514363718', 1, '', 1),
(89, '334646第一本书', '用户1514425586', '334646第一本书', 'photo/1514425922.jpg', '', '玄幻', '1514425922', 1, '@334646第一本书第一章@334646第一本书第二章@disanzhnag ', 0),
(90, '334的第二本书', '用户1514425586', '334的第二本书', 'photo/1514426360.jpg', '', '玄幻', '1514426360', 2, '', 8),
(91, '电饭锅的第一本书', '用户1514518182', '四渡赤水的', 'photo/1514518784.jpg', '', '玄幻', '1514518784', 1, '@111@2222@西游记', 90),
(92, '大声说', '用户1514524563', '是的撒', 'photo/1514528583.jpg', '', '玄幻', '1514524613', 1, '@111@22@兰尼斯特有债必偿@凛冬将至@拜拉席恩消亡史@小玫瑰@荆棘女王', 6),
(97, '坦格利安家族的兴衰史', '用户1514524563', '龙母的三条龙', 'photo/1514876316.jpg', '', '玄幻', '1514876316', 1, '@丹妮莉丝', 12),
(98, '史塔克家族的悲剧', '用户1514524563', '大声说', 'photo/1514876343.jpg', '', '玄幻', '1514876343', 1, '', 0),
(100, '耶哥蕊特', '用户1514524563', '耶哥蕊特', 'photo/1514362997.jpg', '', '玄幻', '1514879499', 2, '@you know nothing', 0),
(101, '123456一', '用户1515573657', '11111', 'photo/1515573707.jpg', '', '玄幻', '1515573707', 1, '@1111@2222@3333', 0),
(102, 'ghjkl', '用户1515660522', 'qewrqw', 'photo/1515661311.jpg', '', '玄幻', '1515661311', 1, '', 0),
(103, '99999', '用户1515660522', '9999', 'photo/1515661344.jpg', '', '玄幻', '1515661344', 1, '', 0),
(104, '00000', '用户1515660522', '00000', 'photo/1515661401.jpg', '', '玄幻', '1515661401', 1, '', 0),
(105, '11111', '用户1515724472', '11111', 'photo/1514362997.jpg', '', '玄幻', '1515724523', 1, '', 0),
(109, '22222', '用户1516088772', '2222', 'photo/1516093551.jpg', '', '玄幻', '1516093551', 1, '', 0),
(108, '00223', '用户1516088772', '2222', 'photo/1516089791.jpg', '', '玄幻', '1516089791', 1, '@1111@2222@333', 0),
(110, '本站', '本站', '的点点滴滴', 'photo/1516157009jpg', '', '玄幻', '1516157009', 1, '', 0),
(111, '本站22222', '本站', '点点滴滴', 'photo/1516157122jpg', '', '玄幻', '1516157122', 1, '', 0),
(112, '本站3333', '本站', '点点滴滴', 'photo/1516157268jpg', '', '玄幻', '1516157268', 1, '', 0),
(113, '555555', '本站', '55555', 'photo/1516158251jpg', '', '玄幻', '1516158251', 1, '', 0),
(114, '4444555', '本站', '柔柔弱弱', 'photo/1516158322jpg', '', '悬疑', '1516158322', 1, '', 0),
(115, '11111', '用户1516158766', '1111', 'photo/1516158786.jpg', '', '女生', '1516158786', 1, '@1111@2222@武松打虎', 0),
(116, '55555', '本站', 'ssss', 'photo/1516159642jpg', '', '玄幻', '1516159642', 1, '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `nickname` varchar(64) NOT NULL,
  `gender` int(11) NOT NULL DEFAULT '1' COMMENT '性别 男1女2',
  `password` varchar(32) NOT NULL,
  `date` varchar(32) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `favorate` int(11) NOT NULL DEFAULT '0' COMMENT '收藏',
  `account` int(32) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '启用是1注销是2',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `name`, `nickname`, `gender`, `password`, `date`, `tel`, `favorate`, `account`, `status`) VALUES
(54, '用户1514873868', '秋水', 1, '$2y$10$fxnw7W0T0f19u5uxsFpkdeYef', '', '1784856694', 0, 0, 1),
(62, '用户1516158766', '用户1516158766', 1, '$2y$10$dlnb4L2wxB0wlyxWNmA09egWA', '1516158766', '111111', 0, 0, 1),
(59, '用户1516077948', '第二个', 1, '$2y$10$bufgweTrppexmxyuUfvkX.7my', '1516077948', '123456789', 0, 0, 1),
(60, '用户1516084051', '况北云', 1, '$2y$10$cvM7b7r4ibXR//vHuSOfuOcNj', '1516084051', '111111111', 0, 0, 1),
(61, '用户1516088772', '用户1516088772', 1, '$2y$10$6pLyG8zRzSYvxOvZq/QzMeHYE', '1516088772', '2222222222', 0, 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
