//寮规琛ㄥ崟 
(function($) {
    //闃呰椤甸潰
    var book_id;
  //鏂囧瓧鎻愮ず寮圭獥妯℃澘
    function createHtml(tips) {
        var html = '';
        html += '<div class="dialog-tips">'+ tips +'</div>';
        return html;
    }
    //鏀惰棌
    $(".J_ShouCang").click(function(event) {
        if (HB.userinfo.reader_id==0) {
            HB.util.loginDialog();
            return;
        }
        var self = $(this);
        if(self.prop('disabled')) return false;

        if ($(this).attr('data-list') == 1) {
            book_id = $(this).closest('li').attr('data-book-id');
        } else {
            book_id = HB.book.book_id;
        }

        if ($(this).hasClass('shoucanged')) {

            $.ajax({
                url: HB.config.rootPath + 'bookshelf/delete_shelf_book',
                data: {book_id: book_id},
                beforeSend: function() {
                    self.prop('disabled', true);
                },
                complete: function() {
                    self.prop('disabled', false);
                },
                success: function (res) {
                    if (res.code == 100000) {
                        if (self.attr('data-btn')=='1') {
                            self.removeClass('shoucanged').find('p').html("鏀惰棌");
                        } else {
                            self.removeClass('shoucanged').html("鏀惰棌");
                        }
                        //$("#J_BookReadBox").removeClass('book-read-box-fav');
                        if( typeof load_right === 'function' ) {
                            $(".J_Stock_Favor_total").text(parseInt($(".J_Stock_Favor_total").text())-1);
                        }
                    }
                    HB.util.alert(res.tip,1);
                }
            });
        } else {
            $.ajax({
                url: HB.config.rootPath + 'bookshelf/favor',
                data: {book_id: book_id},
                beforeSend: function() {
                    self.prop('disabled', true);
                },
                complete: function() {
                    self.prop('disabled', false);
                },
                success: function (res) {
                    if (res.code == 100000) {
                        if (self.attr('data-btn')=='1') {
                            self.addClass('shoucanged').find('p').html("宸叉敹钘�");
                        } else {
                            self.addClass('shoucanged').html("宸叉敹钘�");
                        }
                        if( typeof load_right === 'function' ) {
                            $(".J_Stock_Favor_total").text(parseInt($(".J_Stock_Favor_total").text())+1);
                        }
                        //var msg = res.tip ? res.tip : '鎮ㄥ凡鎴愬姛灏嗚繖鏈功鍔犲叆涔︽灦锛�';
                        //$("#J_BookReadBox").addClass('book-read-box-fav');
                        //HB.util.alert(res.tip,1);
                        $.ajax({
    						url: HB.config.rootPath + 'reader/auto_reg_daily_task',
    						success: function (res) {
    							if (res.code == 100000) {
    			                    // 鏂扮敤鎴锋敹钘忔垚鍔熺涓€鏈功鐨勬椂鍊欒烦鍑烘彁绀烘
    				                  var elem = createHtml("涓轰繚鎶ゆ偍鐨勮处鍙峰畨鍏紝<br/>璇峰敖蹇畬鍠勬偍鐨勪釜浜鸿祫鏂欍€�");
    				                  var d = dialog({
    				                      title:' ',
    				                      fixed: true,
    				                      width: "290px",
    				                      content: elem,
    				                      okValue: '鍘诲畬鍠�',
    				                      ok: function () {
    				                          location.href = HB.config.rootPath + 'reader/my_info';
    				                      },
    				                      cancelValue: '浠ュ悗',
    				                      cancel: function () {}
    				                  });
    				                  d.showModal();
    							} 
    							else{
    								var msg='宸叉敹钘�';
    								HB.util.alert(msg,1);
    							}
    						}
    					});
                    }
                }
            });
        }
    });
    //鎺ㄨ崘
    var dialogTuiJian, boxTuiJian;
    $(".J_TuiJian").click(function(event) {
        if (HB.userinfo.reader_id==0) {
            HB.util.loginDialog();
            return;
        }
        var self = $(this);

        if (self.attr('data-list') == 1) {
            book_id = self.closest('li').attr('data-book-id');
        } else {
            book_id = HB.book.book_id;
        }

        var elem = document.getElementById('J_TuiJianBox');
        dialogTuiJian = dialog({
            title:' ',
            fixed: true,
            content: elem
        });
        dialogTuiJian.showModal();
    });
    $(document).on('click', "#J_TuiJianBox .J_BoxSubmit", function () {
        var self = $(this);
        if(self.prop('disabled')) return false;

        boxTuiJian = self.closest('#J_TuiJianBox');
        var num = parseInt($("#J_TuiJianBox .J_NumResult").val());
        num = isNaN(num) ? 1 : num;

        $.ajax({
            url: HB.config.rootPath + 'book/give_recommend',
            data: {book_id: book_id, count: num},
            beforeSubmit: function() {
                self.prop("disabled", true);
            },
            complete: function () {
                self.prop("disabled", false);
            },
            success: function (res) {
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '鎶曟帹鑽愮エ鎴愬姛锛�';
                    // boxTuiJian.find(".J_HLB").text(res.data.prop_info.rest_hlb);
                    // boxTuiJian.find(".J_Recommend").text(res.data.prop_info.rest_recommend);
                    //$(".J_HLB").text(res.data.prop_info.rest_hlb);
                    $(".J_Recommend").text(res.data.prop_info.rest_recommend);
                    HB.util.alert(msg,1);
                    if( typeof load_right === 'function' ) {
                        $(".J_Recommend_Rec_total").text(parseInt($(".J_Recommend_Rec_total").text())+num);
                        $(".J_Recommend_Rec_month").text(parseInt($(".J_Recommend_Rec_month").text())+num);
                        $(".J_Recommend_Rec_week").text(parseInt($(".J_Recommend_Rec_week").text())+num);
                    }
                } else {
                    HB.util.alert(res.tip,1);
                }
                dialogTuiJian.close();
            }
        });
    });
    //鏈堢エ
    var dialogYuePiao, boxYuePiao;
    $("#J_YuePiao").click(function(event) {
        if (HB.userinfo.reader_id==0) {
            HB.util.loginDialog();
            return;
        }
        var self = $(this);
        var elem = document.getElementById('J_YuePiaoBox');
        dialogYuePiao = dialog({
            title:' ',
            fixed: true,
            content: elem
        });
        dialogYuePiao.showModal();
    });
    $(document).on('click', "#J_YuePiaoBox .J_BoxSubmit", function () {
        var self = $(this);
        if(self.prop('disabled')) return false;

        boxYuePiao = self.closest('#J_YuePiaoBox');
        var num = parseInt($("#J_YuePiaoBox .J_NumResult").val());
        num = isNaN(num) ? 1 : num;
        $.ajax({
            url: HB.config.rootPath + 'book/give_yp',
            data: {book_id: HB.book.book_id, count: num},
            beforeSubmit: function() {
                self.prop("disabled", true);
            },
            complete: function () {
                self.prop("disabled", false);
            },
            success: function (res) {
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '鎶曟湀绁ㄦ垚鍔燂紒';
                    HB.util.alert(msg,1);
                    // boxYuePiao.find(".J_HLB").text(res.data.prop_info.rest_hlb);
                    // boxYuePiao.find(".J_Stock").text(res.data.prop_info.rest_yp);
                    //$(".J_HLB").text(res.data.prop_info.rest_hlb);
                    $(".J_Stock").text(res.data.prop_info.rest_yp);
                    if( typeof load_right === 'function' ) {
                        load_right();
                    }
                } else {
                    HB.util.alert(res.tip,1);
                }
                dialogYuePiao.close();
            }
        });
    });

    //璁㈤槄
    var dialogDingYue;
    $("#J_DingYue").click(function(event) {
        if (HB.userinfo.reader_id==0) {
            HB.util.loginDialog();
            return;
        }
        if (HB.book.is_paid==0) {
            HB.util.alert("鍏嶈垂涔︾睄,鏃犻渶璁㈤槄");
            return;
        }
        var self = $(this);
        if ($(this).attr("data-dingyueall") == 1) {
            HB.util.alert("鎮ㄥ凡鍏ㄦ湰璁㈤槄锛�",3);
            return false;
        }
        var elem = document.getElementById('J_DingYueBox');
        dialogDingYue = dialog({
            title:' ',
            fixed: true,
            content: elem
        });
        dialogDingYue.showModal();
    });
    $(document).on('click', "#J_DingYueBox .J_BoxSubmit", function () {
        var self = $(this);
        if(self.prop('disabled')) return false;
        var num = $("#J_DingYueBox .J_NumResult[checked]").val();
        // alert(num);
		var buy_paid = false;
        var ajaxOpt = {
            beforeSubmit: function() {
                self.prop("disabled", true);
            },
            complete: function () {
                if(HB.book.chapter_id > 0 && buy_paid){
                    location.reload();
                }
                else{
                    self.prop("disabled", false);
                }
            },
            success: function (res) {
            	dialogDingYue.close();
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '璁㈤槄鎴愬姛锛�';
                    //HB.util.alert(msg,1);
                    if (num==1) {
                        $("#J_DingYue").attr("data-dingyueall", 1);
                    }

                    $(".J_HLB").text(res.data.prop_info.rest_hlb);
                    $(".J_Stock").text(res.data.prop_info.rest_yp);
                    buy_paid = true;
                    $.ajax({
						url: HB.config.rootPath + 'reader/auto_reg_daily_task',
						success: function (res) {
							if (res.code == 100000) {
			                    // 璁㈤槄鎴愬姛鍚庡脊妗嗘彁閱�
				                  var elem = createHtml("涓轰繚鎶ゆ偍鐨勮处鍙峰畨鍏紝<br/>璇峰敖蹇粦瀹氭墜鏈哄彿鎴栭偖绠便€�");
				                  var d = dialog({
				                      title:' ',
				                      fixed: true,
				                      width: "290px",
				                      content: elem,
				                      okValue: '鍘荤粦瀹�',
				                      ok: function () {
				                          location.href = HB.config.rootPath + 'reader/my_info';
				                      },
				                      cancelValue: '浠ュ悗',
				                      cancel: function () {}
				                  });
				                  d.showModal();
							} 
							else{
								var msg = res.tip ? res.tip : '璁㈤槄鎴愬姛锛�';
								HB.util.alert(msg,1);
							}
						}
					});
                } else {
                    HB.util.alert(res.tip,1);
                    setTimeout(function () {
                        //娆箰甯佷綑棰濅笉瓒虫彁閱�
                        var elem = createHtml('<p style="font-size: 18px;">鎮ㄧ殑娆箰甯佷綑棰濅笉瓒筹紝<br/>鏄惁鍓嶅線鍏呭€间腑蹇冦€�</p>');
                        var d = dialog({
                            title:' ',
                            fixed: true,
                            width: "290px",
                            content: elem,
                            okValue: '鍘诲厖鍊�',
                            ok: function () {
                                window.open(HB.config.rootPath + 'recharge/index');
                            },
                            cancelValue: '浠ュ悗',
                            cancel: function () {}
                        });
                        d.showModal();
                    }, 1000);
                }
                dialogDingYue.close();
            }
        };
        if(num==1){
            ajaxOpt.url = HB.config.rootPath + 'book/buy';
            ajaxOpt.data = {book_id: HB.book.book_id};
        }
        else{
            ajaxOpt.url = HB.config.rootPath + 'chapter/buy';
            //澧炲姞涓€涓猧s_auto_buy鍙戦€佸弬鏁�
            var is_auto_buy=$("input[name='is_auto_buy'][checked]").val();
            if (is_auto_buy==1) ajaxOpt.data = {chapter_id: HB.book.chapter_id,is_auto_buy:is_auto_buy};
            else ajaxOpt.data = {chapter_id: HB.book.chapter_id};

        }
        $.ajax(ajaxOpt);
    });

    //鎵撹祻
    var dialogDaShang, boxDaShang;
    $(".J_DaShang").each(function(){
        $(this).click(function(event) {
            if (HB.userinfo.reader_id==0) {
                HB.util.loginDialog();
                return;
            }
            var self = $(this),
                type = self.attr("data-type"),
                $type = $("#J_DaShangBox .account-type a[data-type='"+ type +"']");
            var elem = document.getElementById('J_DaShangBox');
            dialogDaShang = dialog({
                title:' ',
                fixed: true,
                content: elem
            });
            dialogDaShang.showModal();
            $type.click();
        });
    });

    $(document).on('click', "#J_DaShangBox .account-type li", function () {
        var self = $(this),
            i = self.index(),
            accountInfo = self.closest("#J_DaShangBox").find(".account-info");
        accountInfo.eq(i).show().siblings(".account-info").hide();
    });
    $(document).on('click', ".J_AccountShang .J_BoxSubmit", function () {
        var self = $(this);
        if(self.prop('disabled')) return false;

        boxDaShang = self.closest('#J_DaShangBox');
        //var num = $(".J_DaShangBox .J_NumResult[checked]").val();
        var accountShang = boxDaShang.find(".J_AccountShang"),
            prop_type = accountShang.find('.J_InputRadio a.selected').attr("data-prop-type"), //閬撳叿绫诲瀷
            prop_count = parseInt(accountShang.find('.J_InputRadio a.selected span').text()), //鎷ユ湁鐨勯亾鍏锋暟閲�
            prop_price = parseInt(accountShang.find('.J_InputRadio .J_NumResult[checked]').val()), //閬撳叿鍗曚环
            consume_num = parseInt(accountShang.find(".J_NumCalculate .J_NumResult").val()), //鎵撹祻鐨勯亾鍏锋暟閲�
            hlb_rest = parseInt(accountShang.find(".J_HLB").text()),
            consume_sum = 0;
        if (prop_count >= consume_num) {
            consume_sum = 0;
        } else if (prop_count > 0 && prop_count < consume_num) {
            consume_sum = (consume_num - prop_count) * prop_price;
        } else {
            consume_sum = consume_num * prop_price;
        }

    if (consume_sum > hlb_rest) {
        //娆箰甯佷綑棰濅笉瓒虫彁閱�
        var elem = createHtml('<p style="font-size: 18px;">鎮ㄧ殑娆箰甯佷綑棰濅笉瓒筹紝<br/>鏄惁鍓嶅線鍏呭€间腑蹇冦€�</p>');
        var d = dialog({
            title:' ',
            fixed: true,
            width: "290px",
            content: elem,
            okValue: '鍘诲厖鍊�',
            ok: function () {
                window.open(HB.config.rootPath + 'recharge/index');
            },
            cancelValue: '浠ュ悗',
            cancel: function () {}
        });
        d.showModal();
        dialogDaShang.close();
        return false;
    }
        $.ajax({
            url: HB.config.rootPath + 'book/give_reward_prop',
            data: {book_id: HB.book.book_id,
                prop_id: prop_type,
                num: consume_num
            },
            beforeSubmit: function() {
                self.prop("disabled", true);
            },
            complete: function () {
                self.prop("disabled", false);
            },
            success: function (res) {
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '鎵撹祻鎴愬姛锛�';
                    HB.util.alert(msg,1);

                    accountShang.find('.J_InputRadio a[data-prop-type="'+ prop_type +'"] span').text(res.data.prop_info.rest_prop_count);//鍓╀綑閬撳叿鏁伴噺
                    // $(".J_HLB").text(res.data.prop_info.rest_hlb);
                    $(".J_HLB").text(parseInt(res.data.prop_info.rest_hlb-res.data.prop_info.rest_gift_hlb));
                    //$(".J_Stock").text(res.data.prop_info.rest_yp);
                    if( typeof load_right === 'function' ) {
                        load_right();
                    }else{
                        load_down();
                    }
                } else {
                    HB.util.alert(res.tip,1);
                }
                dialogDaShang.close();
            }
        });
    });
    $(document).on('click', ".J_AccountProp .J_BoxSubmit", function () {
        var self = $(this);
        if(self.prop('disabled')) return false;
        boxDaShang = self.closest('#J_DaShangBox');
        var num = parseInt($(".J_AccountProp .J_NumResult").val());//鎶曞嚭鍒€鐗囨暟
        var consume_hlb = parseInt($(".J_AccountProp .J_Consume").text());
        if(consume_hlb > parseInt($(".J_AccountProp .J_HLB").text())){
            HB.util.alert("鎮ㄧ殑娆箰甯佷綑棰濅笉瓒�",1);
          //娆箰甯佷綑棰濅笉瓒虫彁閱�
            var elem = createHtml('<p style="font-size: 18px;">鎮ㄧ殑娆箰甯佷綑棰濅笉瓒筹紝<br/>鏄惁鍓嶅線鍏呭€间腑蹇冦€�</p>');
            var d = dialog({
                title:' ',
                fixed: true,
                width: "290px",
                content: elem,
                okValue: '鍘诲厖鍊�',
                ok: function () {
                    window.open(HB.config.rootPath + 'recharge/index');
                },
                cancelValue: '浠ュ悗',
                cancel: function () {}
            });
            d.showModal();
            dialogDaShang.close();
            return false;
        }
        $.ajax({
            url: HB.config.rootPath + 'book/give_blade',
            data: {book_id: HB.book.book_id, num: num},
            beforeSubmit: function() {
                self.prop("disabled", true);
            },
            complete: function () {
                self.prop("disabled", false);
            },
            success: function (res) {
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '鎶曞嚭閬撳叿鎴愬姛锛�';
                    HB.util.alert(msg,1);
                    $(".J_HLB").text(res.data.prop_info.rest_hlb);
                    //$(".J_Stock").text(res.data.prop_info.rest_yp);
                    $(".J_OwnBlade").text(res.data.prop_info.rest_total_blade);
                    //$(".J_OwnBlade").text();
                    if( typeof load_right === 'function' ) {
                        load_right();
                    }else{
                        load_down();
                    }
                } else {
                    HB.util.alert(res.tip,1);
                }
                dialogDaShang.close();
            }
        });
    });
})(jQuery);