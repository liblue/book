<html lang="en"><head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="2554576230602773526375">
    <meta name="baidu-site-verification" content="81BLZ1C2Te">
    <!-- 百度验证  -->
    <meta name="baidu-site-verification" content="23p76Y9LU3">
    <!--360验证-->
    <meta name="360-site-verification" content="1247af3cd890cf522c64a0188211dfba">
    <!--神马平台验证-->
    <meta name="shenma-site-verification" content="6ddf919e460df88fe12310e2097a23cc_1497866600">
    <title>1860战记最新章节(怨念法师),1860战记无弹窗全文阅读-欢乐书客</title>
    <meta name="keywords" content="1860战记,1860战记全文阅读,,1860战记最新章节">
    <meta name="description" content="1860战记是作者怨念法师倾情打造的一部战争历史小说，欢乐书客第一时间提供1860战记小说最新章节以及1860战记全文阅读。页面洁净清爽无广告，访问速度极快。">
    <!--<link rel="shortcut icon" type="image/x-icon" href=""/>-->
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">

    <link rel="stylesheet" type="text/css" href="https://www.hbooker.com/resources/css/style.css">
    <!--<link rel="stylesheet" type="text/css" href=''/>-->
    <link rel="stylesheet" type="text/css" href="https://www.hbooker.com/resources/css/response.css">
        <!--<script type="text/javascript" language="javascript" src=''></script>-->
    <script async="" src="https://www.hbooker.com/resources/js/sensorsdata/sensorsdata.min.js" charset="UTF-8"></script><script src="//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e"></script><script type="text/javascript" language="javascript" src="https://www.hbooker.com/resources/scripts/bootstrap/js/jquery.js"></script>
        <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
        HB.book = {book_id: 100035235, chapter_id: "", up_reader_id: 90233, is_paid: 1};
        HB.userinfo = {reader_id: 2700847,tel_num: '',license: '',redis_license: '', reader_name: '书客69271084732', avatar_thumb_url: 'https://www.hbooker.com/resources/images/avatar-default-m.png', vip_lv: 0};
        HB.urlinfo ={redirect:'https://www.hbooker.com/reader/modify_mobile?redirect=https%3A%2F%2Fwww.hbooker.com%2Fbook%2F100035235'};        
    </script>
    <script type="text/javascript" src="https://www.hbooker.com/resources/js/initResponse.js"></script>
    <script type="text/javascript" src="https://www.hbooker.com/resources/js/base.js"></script>
    <script type="text/javascript" src="https://www.hbooker.com/resources/js/artDialog/6.0.4/dialog-min.js"></script>

    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>
    <script>
		(function(para) {
		  var p = para.sdk_url, n = para.name, w = window, d = document, s = 'script',x = null,y = null;
		  w['sensorsDataAnalytic201505'] = n;
		  w[n] = w[n] || function(a) {return function() {(w[n]._q = w[n]._q || []).push([a, arguments]);}};
		  var ifs = ['track','quick','register','registerPage','registerOnce','clearAllRegister','trackSignup', 'trackAbtest', 'setProfile','setOnceProfile','appendProfile', 'incrementProfile', 'deleteProfile', 'unsetProfile', 'identify','login','logout','trackLink','clearAllRegister','getAppStatus'];
		  for (var i = 0; i < ifs.length; i++) {
		    w[n][ifs[i]] = w[n].call(null, ifs[i]);
		  }
		  if (!w[n]._t) {
		    x = d.createElement(s), y = d.getElementsByTagName(s)[0];
		    x.async = 1;
		    x.src = p;
		    x.setAttribute('charset','UTF-8');
		    y.parentNode.insertBefore(x, y);
		    w[n].para = para;
		  }
		})({
		  sdk_url: 'https://www.hbooker.com/resources/js/sensorsdata/sensorsdata.min.js',
		  name: 'sa',
		  web_url: 'https://sensorsdata.hbooker.com:4006/?project=production',
		  server_url: 'https://sensorsdata.hbooker.com:4006/sa?project=production',
		  heatmap:{}
		});
		sa.quick('autoTrack');
	</script>
</head>
<body class="s-layout-990">
    <!--360自动收录JS代码-->
<script>
(function(){
   var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2":"https://jspassport.ssl.qhimg.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2";
   document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script><script src="https://jspassport.ssl.qhimg.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2" id="sozz"></script><script charset="utf-8" src="https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js"></script>
 <!-- 当前是章节阅读页 -->
 <!-- 当前是漫画阅读页 -->
<div id="bdstat" style="display: none"></div>

<div class="nav-top">
    <div class="ly-wrap">
        <ul class="login-info ly-fl">
                            <li class="userinfo">
                    <a class="avatar" href="https://www.hbooker.com/bookshelf/my_book_shelf/" target="_blank" rel="nofollow">
                        <img class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="" style="display: inline;">
                                            </a>
                    <i><a href="https://www.hbooker.com/bookshelf/my_book_shelf/" target="_blank" rel="nofollow">书客69271084732</a> </i>
                    <a href="https://www.hbooker.com/signup/logout?redirect=https%3A%2F%2Fwww.hbooker.com%2Fbook%2F100035235" class="logout" rel="nofollow">[退出]</a>
                    <span>经验等级：LV.2读书御宅</span>
                    <span class="count">书架： <i><a href="https://www.hbooker.com/bookshelf/my_book_shelf/" target="_blank" rel="nofollow">0</a></i></span>
                    <span class="count msg">消息： <i><a href="https://www.hbooker.com/reader/get_message_list/" target="_blank" rel="nofollow">0</a></i></span>
                </li>
                    </ul>
        <div class="nav-top-right ly-fr">
            <ul class="special ly-fl clearfix">
                <li class="recharge"><a href="https://www.hbooker.com/recharge/index"><i></i>充值中心</a></li>
                <li class="line">|</li>
                <li class="author"><a href="http://author-new.hbooker.com" target="_blank"><i></i>作者后台</a></li>
                <li class="line">|</li>
            </ul>
            <a class="app-download ly-fl" href="http://app.hbooker.com" target="_blank"><img src="http://www.hbooker.com/resources/images/app-download.png" alt=""></a>
            <div class="qr-code ly-fl">
                <a id="J_QrCode" href="javascript:;"><div><p>扫码下载客户端</p></div></a>
            </div>
        </div>
    </div>
</div>

<!--  欢迎每日登录 领取推荐票 -->
<div class="header">
    <div class="ly-wrap header-inner">
        <div class="ly-fl">
            <div class="logo">
                <h1><a href="https://www.hbooker.com/index"><img src="https://www.hbooker.com/resources/images/logo.png" alt="logo"></a></h1>
                <div>让阅读更精彩，让写作更简单 \^o^/</div>
            </div>
        </div>
    </div>

    <div class="menu-wrap menu-fixed" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
                <li><a href="https://www.hbooker.com/">首页</a></li>
                <li><a href="https://www.hbooker.com/rank-index">排行</a></li>
                <li><a href="https://www.hbooker.com/index-zhaiwen" class="selected">宅文</a></li>
                <li><a href="https://www.hbooker.com/index-tongren">同人</a></li>
                <!--<li><a href="https://www.hbooker.com/index/header_cate_list/male" >男生</a></li>-->
                <li><a href="https://www.hbooker.com/index-female">女生</a></li>
                <li><a href="https://www.hbooker.com/index-comic">漫画</a></li>
                <li><a href="https://www.hbooker.com/index-game">游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list">书库</a></li>
                <li><a href="https://www.hbooker.com/bbs">社区</a></li>
            </ul>
            <div class="ly-fr">
                <form action="" name="myform" id="" target="_blank" class="search-form" onsubmit="return false">
                    <input name="keyword" autocomplete="off" type="text" x-webkit-speech="" data-type="1" x-webkit-grammar="builtin:translate" placeholder="搜索更多作品或作者" data-url="https://www.hbooker.com/get-search-book-list/{key}">
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>
    </div><!--container start-->
<div class="book-read"></div>
<div class="container">
    <div class="ly-wrap">

        <div class="breakcrumb">
            <a href="https://www.hbooker.com/index">首页</a>
            &gt;
            <a href="https://www.hbooker.com/index/header_cate_list/zhaiwen">宅文</a> &gt; <a href="https://www.hbooker.com/index/cate_book_list/zhaiwen/30">战争历史</a> &gt;             1860战记        </div>

        <!--书页 start-->
        <div class="book-detail ly-mt45">

            <!-- ly-main -->
            <div class="ly-main">
                <div class="book-hd clearfix">
                    <div class="ly-fl book-img">
                        <div class="book-cover">
                            <img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170716/16-07-17144704-31263-100035235.jpg" alt="1860战记">
                        		
                        </div>
                        <ul class="book-operating">
                            <li><a class="read" href="https://www.hbooker.com/chapter-list/100035235/book_detail">点击阅读</a></li>
                            <li> <a class="J_ShouCang" href="javascript:">收藏</a> </li>
                            <li><a href="javascript:" class="J_TuiJian">投推荐票</a></li>
                            <li><a href="javascript:" id="J_YuePiao">投月票</a></li>
                            <li><a id="J_DingYue" href="javascript:">订阅</a>                            </li>
                        </ul>
                    </div>
                    <div class="ly-fl book-info">
                        <div class="book-title">
                            <h1>1860战记</h1>
                            <p><span>小说作者：</span><a href="https://www.hbooker.com/reader/90233" target="_blank" class="">怨念法师</a></p>
                        </div>
                        <!--act-tab start-->
                        <div class="book-bd act-tab">
                            <div>
                                <span class="time-update ly-fr">更新时间：2017-12-07 12:00:02</span>
                                <ul class="act-tab-titles clearfix">
                                    <li class="selected"><a href="javascript:">作品简介</a></li>
                                    <li><a href="javascript:">作品信息</a></li>
                                    <li><a href="javascript:">作者信息</a></li>
                                </ul>
                            </div>
                            <div class="book-cnt">
                                <!--act-tab-content start-->
                                <div class="act-tab-content">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-count clearfix">
                                                <ul class="ly-fl">
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总点击：1,138.2万                                                    </li>
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总收藏：<b class="J_Stock_Favor_total">18774</b>
                                                    </li>
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总字数：385965                                                    </li>
                                                </ul>
                                                <span class="ly-fl book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            	                                            </div>
                                            <div class="book-desc J_mCustomScrollbar" tabindex="0" style="overflow: hidden; outline: none;">
                                                                                                　　问：如果今天的天朝【集体成建制】瞬间回到1860，会发生什么事情？<br>
　　答：1860年啊,黄人就来了不列颠,先轰塌西敏寺后烧了白金汉…………                                            </div>
                                        </div>
                                        <div class="book-tip">
                                            （本站郑重提醒: 本故事纯属虚构，如有雷同，纯属巧合，切勿模仿。)
                                        </div>
                                        <div class="book-author-label">
                                            <i class="icon-diamond">◆</i> 作者自定义标签：
                                                                                                                                                <span class="book-label">请随意吐槽</span>
                                                                                                    <span class="book-label">脑洞大开</span>
                                                                                                    <span class="book-label">穿越</span>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-property clearfix">
                                                <span><i class="icon-diamond">◆</i> 小说性质：VIP书籍</span>
                                                <span><i class="icon-diamond">◆</i> 总点击: 1,138.2万</span>
                                                <span><i class="icon-diamond">◆</i> 月点击：24.4万</span>
                                                <span><i class="icon-diamond">◆</i> 周点击：1.7万</span>
                                                <span><i class="icon-diamond">◆</i> 小说类别：战争历史</span>
                                                <span><i class="icon-diamond">◆</i> 总推荐：<b class="J_Recommend_Rec_total">78242</b></span>
                                                <span><i class="icon-diamond">◆</i> 月推荐：<b class="J_Recommend_Rec_month">883</b></span>
                                                <span><i class="icon-diamond">◆</i> 周推荐：<b class="J_Recommend_Rec_week">31</b></span>
                                                <span><i class="icon-diamond">◆</i> 总月票：3872</span>
                                                <span><i class="icon-diamond">◆</i> 当月月票：33</span>
                                                <span><i class="icon-diamond">◆</i> 总刀片：2875</span>
                                                <span><i class="icon-diamond">◆</i> 月刀片：10</span>
                                                <span><i class="icon-diamond">◆</i> 完成字数：385965</span>
                                                <span><i class="icon-diamond">◆</i> 写作状态：连载中</span>
                                                <span class="book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            </div>
                                        </div>
                                        <div class="book-tip" [="">
                                            （本站郑重提醒: 本故事纯属虚构，如有雷同，纯属巧合，切勿模仿。)
                                        </div>
                                        <div class="book-author-label">
                                            <i class="icon-diamond">◆</i> 作者自定义标签：
                                                                                                                                                <span class="book-label">请随意吐槽</span>
                                                                                                    <span class="book-label">脑洞大开</span>
                                                                                                    <span class="book-label">穿越</span>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-author-info">
                                                <div><i class="icon-diamond">◆</i> 作者的其它作品：</div>
                                                <ul class="clearfix">
                                                                                                                                                                        <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100038272">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171031/31-10-17101830-96577-100038272.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171031/31-10-17101830-96577-100038272.jpg" alt="我可能活的有点久了" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100038272">我可能活的有点久了</a></p>
                                                                    <div>
                                                                        <p>字数：37380</p>
                                                                        <p>类别：动漫穿越</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100042059">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170815/15-08-17123649-46842.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170815/15-08-17123649-46842.jpg" alt="第七日" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100042059">第七日</a></p>
                                                                    <div>
                                                                        <p>字数：5212</p>
                                                                        <p>类别：游戏世界</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100038520">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170712/12-07-17213416-32481.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170712/12-07-17213416-32481.jpg" alt="写手们的死后世界大冒险" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100038520">写手们的死后世界大冒险</a></p>
                                                                    <div>
                                                                        <p>字数：7205</p>
                                                                        <p>类别：超现实都市</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100030672">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170506/06-05-17235953-17306-100030672.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170506/06-05-17235953-17306-100030672.jpg" alt="邪恶术士渴望搞事" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100030672">邪恶术士渴望搞事</a></p>
                                                                    <div>
                                                                        <p>字数：223850</p>
                                                                        <p>类别：动漫穿越</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100002882">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160309/09-03-16180423-92042-100002882.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160309/09-03-16180423-92042-100002882.jpg" alt="童年粉碎机" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100002882">童年粉碎机</a></p>
                                                                    <div>
                                                                        <p>字数：297818</p>
                                                                        <p>类别：动漫穿越</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100025714">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170120/20-01-17003502-34788-100025714.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170120/20-01-17003502-34788-100025714.jpg" alt="我的老婆不可能是吸血鬼领主" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100025714">我的老婆不可能是吸血鬼领主</a></p>
                                                                    <div>
                                                                        <p>字数：9603</p>
                                                                        <p>类别：异界幻想</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100017534">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170314/14-03-17015511-30770-100017534.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170314/14-03-17015511-30770-100017534.jpg" alt="无限游戏" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100017534">无限游戏</a></p>
                                                                    <div>
                                                                        <p>字数：162578</p>
                                                                        <p>类别：动漫穿越</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100020496">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c161016/16-10-16164313-32720.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c161016/16-10-16164313-32720.jpg" alt="死侍的无限之旅" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100020496">死侍的无限之旅</a></p>
                                                                    <div>
                                                                        <p>字数：4600</p>
                                                                        <p>类别：动漫穿越</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                                    <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100002284">
                                                                    <img class="lazyload" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160121/21-01-16005948-43357-100002284.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160121/21-01-16005948-43357-100002284.jpg" alt="Fate Another" style="display: inline;">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100002284">Fate Another</a></p>
                                                                    <div>
                                                                        <p>字数：42929</p>
                                                                        <p>类别：同人</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                            
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="book-tip">
                                            （本站郑重提醒: 本故事纯属虚构，如有雷同，纯属巧合，切勿模仿。)
                                        </div>
                                        <div class="book-author-label">
                                            <i class="icon-diamond">◆</i> 作者自定义标签：
                                                                                                                                                <span class="book-label">请随意吐槽</span>
                                                                                                    <span class="book-label">脑洞大开</span>
                                                                                                    <span class="book-label">穿越</span>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                            </div>
                        </div>
                        <!--act-tab end-->
                    </div>
                </div>
                <div class="book-ft">
                    <div class="book-chapter">

                                                <div class="mod-box ly-mt60">
                            <div class="mod-tit1">
                                <h3><i></i>1860战记<span>最新章节试阅</span></h3>
                                <a class="ly-fr" href="https://www.hbooker.com/chapter/book_chapter_detail/101426285" target="_blank">阅读本章 &gt;</a>
                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-new">
                                    <div class="tit">完结感言      更新时间：2017-12-07 12:00:02</div>
                                    <div class="desc box-shadow">　　这本历经了六个月却只写了四十万字不到的书，还是就这么虎头蛇尾的烂尾了。
　　对此我虽然有在反省……但是仔细想想的话倒也感觉不是很奇怪。
　　因为这本书就和我的上本火起来的老书一样————全他喵的是..</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mod-box ly-mt30">
                            <div class="mod-tit1">
                                <h3><i></i>章节列表</h3>
                                                                    <a class="ly-fr order-by" href="https://www.hbooker.com/book/100035235?arr_reverse=1">倒序</a>
                                                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-list ly-mt30">
                                                                            <ul class="clearfix less">
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100944946"><i class="line"></i>序幕</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100949601"><i class="line"></i>第一章 两千年未有之大变局</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100952289"><i class="line"></i>第二章 漆黑的地球上亮起了一只鸡</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100971852"><i class="line"></i>第三章 网民们的众生相</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100978011"><i class="line"></i>第四章 城管大战英法联军（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100987121"><i class="line"></i>第五章 城管大战英法联军（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100988194"><i class="line"></i>第六章 城管大战英法联军（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100992265"><i class="line"></i>第七章 炸锅的网民们</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100997566"><i class="line"></i>第八章 骑兵连连长：我感觉我要升官</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100999310"><i class="line"></i>第九章 一言不合就开始搞大新闻的作者</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101002373"><i class="line"></i>第十章 2017年的‘十里洋场’</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101008116"><i class="line"></i>第十一章 投机分子们的狂欢（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101017263"><i class="line"></i>第十二章 投机分子们的狂欢（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101018540"><i class="line"></i>第十三章 不容乐观的海外华人现状</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101021806"><i class="line"></i>第十四章 这是富有天朝特色的经济制裁</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101028168"><i class="line"></i>第十五章 你们想要的干货</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101030444"><i class="line"></i>第十六章 英法舰队的疑惑</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101030821"><i class="line"></i>第十七章 欢天喜地的同人写手</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101033495"><i class="line"></i>第十八章 现在这章应该不会再有什么问题了吧？</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101033964"><i class="line"></i>嗯……自己交易一波</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101037242"><i class="line"></i>第十九章 普利颠·巴格上校的异国见闻录（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101039110"><i class="line"></i>第二十章 普利颠·巴格上校的异国见闻录（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101041722"><i class="line"></i>第二十一章 普利颠·巴格上校的异国见闻录（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101042054"><i class="line"></i>第二十二章 轰轰烈烈的历史名人抢购风潮</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101042615"><i class="line"></i>第二十三章 身体虽然苍老,但头脑还是一样的好！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101043960"><i class="line"></i>第二十四章 战斗吧，城管！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101044672"><i class="line"></i>第二十五章 论搜集科学家的重要性（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101044954"><i class="line"></i>第二十六章 论搜集科学家的重要性（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101045380"><i class="line"></i>第二十七章 还有这种操作？</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101046489"><i class="line"></i>第二十八章 疯狂的电火花</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101048131"><i class="line"></i>第二十九章 别把这年头的欧洲科学家节操想的太高</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101050864"><i class="line"></i>第三十章 外交部：不是我们针对谁，而是指在座的各位都是……</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101052117"><i class="line"></i>第三十一章 貌似这章有点太干了……</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101055470"><i class="line"></i>第三十二章 ‘大开发时代’的来临（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101055669"><i class="line"></i>第三十三章 ‘大开发时代’的来临（中）【第一张加更】</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101056645"><i class="line"></i>第三十四章 ‘大开发时代’的来临（下）【第二张加更】</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101057781"><i class="line"></i>第三十五章 快上车！老司机飙车啦！【第三张加更】</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101061049"><i class="line"></i>第三十六章 ‘人类灯塔’赛里斯</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101061947"><i class="line"></i>第三十七章 老佛爷，（东）洋人要帮咱们修铁路和电站了！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101063964"><i class="line"></i>第三十八章 公知的另一种使用方法</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101065935"><i class="line"></i>第三十九章 明治天皇的惊愕</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101066355"><i class="line"></i>第四十章 热情的游客，与即将到来的巨变</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101068517"><i class="line"></i>第四十一章 大时代的开幕前奏（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101069397"><i class="line"></i>第四十二章 大时代的开幕前奏（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101071110"><i class="line"></i>第四十三章 大时代的开幕前奏（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101071483"><i class="line"></i>第四十四章 王小明的幸运日</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101072065"><i class="line"></i>第四十五章 ‘黄金——人民币体系’的成立</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101074003"><i class="line"></i>第四十六章 美国总统的忧郁</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101074445"><i class="line"></i>第四十七章 喜出望外的南方佬</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101075845"><i class="line"></i>第四十八章 美利坚联盟国的提前诞生</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101076826"><i class="line"></i>第四十九章 洛克菲勒：JOJO，我不卖石油啦！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101077244"><i class="line"></i>第五十章 萨凡纳集市的日常（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101078787"><i class="line"></i>第五十一章 萨凡纳集市的日常（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101079196"><i class="line"></i>第五十二章 萨凡纳集市的日常（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101079316"><i class="line"></i>第五十三章 萨凡纳集市的日常（续）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101081731"><i class="line"></i>第五十四章 光怪陆离的西方魔都</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101082024"><i class="line"></i>第五十五章 崖山之后无中华，明亡之后无华夏，中华正统在日本！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101083821"><i class="line"></i>第五十六章 明治之后无日本，大正之后无大和，东瀛正统在湾湾！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101084543"><i class="line"></i>第五十七章 十九世纪的名人大杂烩</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101085013"><i class="line"></i>第五十八章 热闹喧嚣的南北战争（一）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101087527"><i class="line"></i>第五十九章 热闹喧嚣的南北战争（二）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101087980"><i class="line"></i>第六十章 热闹喧嚣的南北战争（三）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101090009"><i class="line"></i>第六十一章 热闹喧嚣的南北战争（四）【修改版】</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101090659"><i class="line"></i>第六十二章 热闹喧嚣的南北战争（五）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101092239"><i class="line"></i>第六十三章 热闹喧嚣的南北战争（六）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101094115"><i class="line"></i>第六十四章 热闹喧嚣的南北战争（七）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101094521"><i class="line"></i>第六十五章 热闹喧嚣的南北战争（完）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101095262"><i class="line"></i>第六十六章 南北战争的结束，与……</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101095837"><i class="line"></i>第六十七章 你们难道真的以为这本书没有主线吗？</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101098138"><i class="line"></i>第六十八章 月亮的距离（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101098599"><i class="line"></i>第六十九章 月亮的距离（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101100094"><i class="line"></i>第七十章 月亮的距离（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101100801"><i class="line"></i>第七十一章 月亮的距离（续）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101104211"><i class="line"></i>第七十二章 将美国人变成‘少数民族’吧！（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101105885"><i class="line"></i>第七十三章 将美国人变成‘少数民族’吧！（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101106338"><i class="line"></i>第七十四章 将美国人变成‘少数民族’吧！（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101108001"><i class="line"></i>第七十五章 1860年的美国圣诞夜</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101109285"><i class="line"></i>第七十六章 五年后（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101110471"><i class="line"></i>第七十七章 五年后（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101111812"><i class="line"></i>第七十八章 五年后（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101112856"><i class="line"></i>第七十九章 还在茁壮成长的少年科学家们</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101114364"><i class="line"></i>第八十章 压力山大的华科大学生</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101115187"><i class="line"></i>第八十一章 逐渐变化的日常生活</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101115196"><i class="line"></i>第八十二章 论目前国内的现状问题（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101115204"><i class="line"></i>第八十三章 论目前国内的现状问题（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101119947"><i class="line"></i>第八十四章 天下无人不通共</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101123425"><i class="line"></i>第八十五章 胎死腹中的大日本帝国</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101124323"><i class="line"></i>第八十六章 樱满集的幸福生活（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101124326"><i class="line"></i>嗯……又给自己交易一波~</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101125207"><i class="line"></i>第八十七章 樱满集的幸福生活（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101127119"><i class="line"></i>第八十八章 樱满集的幸福生活（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101128049"><i class="line"></i>第八十九章 少年国王的野望</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101129869"><i class="line"></i>第九十章 量朝鲜之物力，结中华之欢心</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101132417"><i class="line"></i>第九十一章 日朝撕逼不可避（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101135162"><i class="line"></i>第九十二章 日朝撕逼不可避（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101135966"><i class="line"></i>第九十三章 节操掉尽的奥运会，以及……</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101139105"><i class="line"></i>第九十四章 对‘疑似虫洞物体’的初步考察结果</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101145331"><i class="line"></i>第九十五章 世界线变动率超过1%</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101145774"><i class="line"></i>第九十六章 略显尴尬的欧洲局势</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101156995"><i class="line"></i>第九十七章 吾心吾行澄如明镜，所作所为皆为正义！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101161824"><i class="line"></i>第九十八章 单身狗的日子似乎出现了转机？</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101162254"><i class="line"></i>第九十九章 富有赛里斯国特色的‘种花田园女权’逗士</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101165119"><i class="line"></i>第一百章 美洲国民的大致日常</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101168757"><i class="line"></i>第一百零一章 啼笑皆非的欧洲大战（一）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101175635"><i class="line"></i>第一百零二章 啼笑皆非的欧洲大战（二）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101175891"><i class="line"></i>第一百零三章 啼笑皆非的欧洲大战（三）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101176626"><i class="line"></i>第一百零四章 啼笑皆非的欧洲大战（四）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101178193"><i class="line"></i>第一百零五章 啼笑皆非的欧洲大战（五）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101180618"><i class="line"></i>第一百零六章 啼笑皆非的欧洲大战（六）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101181586"><i class="line"></i>第一百零七章 啼笑皆非的欧洲大战（七）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101182735"><i class="line"></i>第一百零八章 啼笑皆非的欧洲大战（八）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101183651"><i class="line"></i>第一百零九章 啼笑皆非的欧洲大战（完）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101183772"><i class="line"></i>上架感言</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101184785"><i class="line"></i><i class="icon-vip"></i>第一百一十章 ‘海外务工人员’的现状，以及未来的展望</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101185663"><i class="line"></i><i class="icon-vip"></i>第一百一十一章 乔斯达一家的日常（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101189238"><i class="line"></i><i class="icon-vip"></i>第一百一十二章 乔斯达一家的日常（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101191933"><i class="line"></i><i class="icon-vip"></i>第一百一十三章 这画风有点不对啊</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101193853"><i class="line"></i><i class="icon-vip"></i>第一百一十四章 穿越者的悲歌</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101195691"><i class="line"></i><i class="icon-vip"></i>第一百一十五章 驻《无双》世界的跨次元联络站</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101197120"><i class="line"></i><i class="icon-vip"></i>第一百一十六章 我种花家的基建能力世界第一！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101199362"><i class="line"></i><i class="icon-vip"></i>第一百一十七章 略显寒酸的首届奥运会</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101201364"><i class="line"></i><i class="icon-vip"></i>第一百一十八章 魔改版《真三国无双》</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101203767"><i class="line"></i><i class="icon-vip"></i>第一百一十九章 贪图享乐吕奉先</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101204299"><i class="line"></i><i class="icon-vip"></i>第一百二十章 逃生3：夺宝奇兵</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101205486"><i class="line"></i><i class="icon-vip"></i>第一百二十一章 真人版GTA5</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101208884"><i class="line"></i><i class="icon-vip"></i>第一百二十二章 关于赛里斯国接管外蒙古、外东北地区的具体事项</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101211575"><i class="line"></i><i class="icon-vip"></i>第一百二十三章 俄国沙皇的纠结</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101213881"><i class="line"></i><i class="icon-vip"></i>第一百二十四章 貌似不太妙的日本经济现状</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101217028"><i class="line"></i><i class="icon-vip"></i>第一百二十五章 日本首相的愤慨</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101218395"><i class="line"></i><i class="icon-vip"></i>第一百二十六章 被人遗忘的历史</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101219620"><i class="line"></i>停更一天</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101223104"><i class="line"></i><i class="icon-vip"></i>第一百二十七章 东南亚人民的噩梦（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101225451"><i class="line"></i><i class="icon-vip"></i>第一百二十八章 东南亚人民的噩梦（中）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101227605"><i class="line"></i><i class="icon-vip"></i>第一百二十九章 东南亚人民的噩梦（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101230085"><i class="line"></i><i class="icon-vip"></i>第一百三十章 日本官兵的喜与忧</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101232445"><i class="line"></i><i class="icon-vip"></i>第一百三十一章 本子：世上只有爸爸好</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101234678"><i class="line"></i><i class="icon-vip"></i>第一百三十三章 金钱不通也是个大问题！</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101236111"><i class="line"></i><i class="icon-vip"></i>第一百三十四章 东汉的盐业不好做，以及……</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101236947"><i class="line"></i><i class="icon-vip"></i>第一百三十五章 舌尖上的汉朝</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101239288"><i class="line"></i><i class="icon-vip"></i>第一百三十六章 日渐科幻的国内</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101242802"><i class="line"></i><i class="icon-vip"></i>第一百三十七章 19世纪的‘民主’法兰西</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101244140"><i class="line"></i><i class="icon-vip"></i>第一百三十八章 白色巨熊的咆哮</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101246511"><i class="line"></i><i class="icon-vip"></i>第一百三十九章 星月旗的陨落</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101248387"><i class="line"></i><i class="icon-vip"></i>第一百四十章 暂时终结的战争，与临近的初届奥运会</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101250477"><i class="line"></i><i class="icon-vip"></i>第一百四十一章 UC震惊部重出江湖</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101252579"><i class="line"></i><i class="icon-vip"></i>第一百四十二章 意外频发的初届奥运会</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101254797"><i class="line"></i><i class="icon-vip"></i>第一百四十三章 1866年的G14峰会</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101257337"><i class="line"></i><i class="icon-vip"></i>第一百四十四章 垂死挣扎的宗教势力</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101259867"><i class="line"></i><i class="icon-vip"></i>第一百四十五章 奇葩遍地的各国变法进程</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101262563"><i class="line"></i><i class="icon-vip"></i>第一百四十六章 改革僵持化的日本</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101264749"><i class="line"></i><i class="icon-vip"></i>第一百四十七章 十九世纪的旅游业大潮</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101268458"><i class="line"></i><i class="icon-vip"></i>第一百四十八章 热闹非凡的游戏与电影产业</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101269770"><i class="line"></i><i class="icon-vip"></i>第一百四十九章 盛况空前的动漫大潮</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101273962"><i class="line"></i><i class="icon-vip"></i>第一百五十章 海外投资者的日常</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101278460"><i class="line"></i><i class="icon-vip"></i>第一百五十一章 日本空军的成立</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101280610"><i class="line"></i><i class="icon-vip"></i>第一百五十二章 澳大利亚独立运动</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101284856"><i class="line"></i><i class="icon-vip"></i>第一百五十三章 1867年的印尼华人现状（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101287043"><i class="line"></i><i class="icon-vip"></i>第一百五十四章 1867年的印尼华人现状（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101289453"><i class="line"></i><i class="icon-vip"></i>第一百五十五章 略显尴尬的英朝日冲突事件</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101315991"><i class="line"></i><i class="icon-vip"></i>第一百五十六章 变法从来不会一帆风顺（上）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101316001"><i class="line"></i>嗯……再给自己交易一波</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101316243"><i class="line"></i><i class="icon-vip"></i>第一百五十七章 变法从来不会一帆风顺（下）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101323020"><i class="line"></i><i class="icon-vip"></i>第一百五十八章 多灾多难的二月</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101327599"><i class="line"></i><i class="icon-vip"></i>第一百五十九章 朝鲜王国的惊变</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101340033"><i class="line"></i><i class="icon-vip"></i>第一百六十章 朝鲜王国的惊变（续）</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101348794"><i class="line"></i><i class="icon-vip"></i>第一百六十一章 东京大学的开幕</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101365125"><i class="line"></i><i class="icon-vip"></i>第一百六十二章 考古也要按照基本法</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101370534"><i class="line"></i><i class="icon-vip"></i>第一百六十三章 相对平静的美洲原住民</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101380363"><i class="line"></i><i class="icon-vip"></i>第一百六十四章 东南亚群岛上的荒野求生</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101384235"><i class="line"></i><i class="icon-vip"></i>第一百六十五章 悠然自得的公务猿生活</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101388159"><i class="line"></i><i class="icon-vip"></i>第一百六十六章 十年后（上）</a></li>
                                                                                    </ul>
                                                                                    <div class="read-all"><a id="J_ReadAll" href="javascript:;">+ 查看全部章节</a></div>
                                                                                                                            <ul class="clearfix">
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101392869"><i class="line"></i><i class="icon-vip"></i>第一百六十七章 十年后（下）</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101398092"><i class="line"></i><i class="icon-vip"></i>第一百六十八章 这些是黑科技吗？</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101426211"><i class="line"></i><i class="icon-vip"></i>第一百六十九章 日渐拉大的阶级差距</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101426271"><i class="line"></i>终章</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101426285"><i class="line"></i>完结感言</a></li>
                                                                                            </ul>
                                                                                                            </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt60">
                            <div name="book_detail_item" id="book_detail_item" class="mod-tit1">
                                <h3><i></i>书评区</h3>
                            </div>
                            <div class="mod-subtit1">
                                <div>书评总数量：
									<span>
										<s id="J_CommentNum">
											813										</s> 条
									</span>
								</div>
                                <div class="manager">本书管理员：
                                                                            <div class="img">暂无管理员</div>
                                    <!--                                    <div class="img"><img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg"/><p class="name"><a href="#">最爱切尔西</a><b>本书作者</b></p></div>-->
<!--                                    <span class="line"></span>-->
<!--                                    <div class="img"><img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg"/><p class="name"><a href="#">罐头</a></p></div>-->
                                </div>
                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-comment J_BookChapterComment" id="book_review_box">
                                    <textarea class="J_CommentInput comment-input" maxlength="1000" placeholder="快来吐槽这本书吧，注意文明用语哦\^o^/"></textarea>
                                    <div class="clearfix ly-mt10 repo">
                                        <div class="ly-fl">
                                            <div class="comment-face J_Face">
                                                <div class="face-btn"><i></i>颜文字</div>
                                                <div class="J_FaceDialog face-dialog" style="display:block;visibility:hidden"><div class="hd"><a class="prev" href="javascript:;"><b></b></a><ul style="width: 588px;"><li><a href="javascript:;" class="selected">常用</a></li><li><a href="javascript:;">高兴</a></li><li><a href="javascript:;">萌萌哒</a></li><li><a href="javascript:;">动物</a></li><li><a href="javascript:;">震惊</a></li><li><a href="javascript:;">生气难过</a></li><li><a href="javascript:;">晕倒</a></li><li><a href="javascript:;">伤心</a></li><li><a href="javascript:;">骄傲</a></li><li><a href="javascript:;">得意</a></li><li><a href="javascript:;">其他综合</a></li></ul><a class="next" href="javascript:;"><b></b></a></div><div class="bd"><div class="cnt J_mCustomScrollbar" tabindex="1" style="overflow: hidden; outline: none;"><a href="javascript:;" title="啦啦 ♪(^∇^*)" class="l1">♪(^∇^*)</a><a href="javascript:;" title="拍桌 o(*≧▽≦)ツ┏━┓" class="l1">o(*≧▽≦)ツ┏━┓</a><a href="javascript:;" title="惊喜 ╰(*°▽°*)╯" class="l1">╰(*°▽°*)╯</a><a href="javascript:;" title="嘟嘴 （○｀ 3′○）" class="l1">（○｀ 3′○）</a><a href="javascript:;" title="乖 o(*^＠^*)o" class="l1">o(*^＠^*)o</a><a href="javascript:;" title="喂 (#`O′)" class="l1">(#`O′)</a><a href="javascript:;" title="愣住 (°ー°〃)" class="l1">(°ー°〃)</a><a href="javascript:;" title="放屁 ○|￣|_ =3" class="l1">○|￣|_ =3</a><a href="javascript:;" title="哼哼 o(￣ヘ￣o＃)" class="l1">o(￣ヘ￣o＃)</a><a href="javascript:;" title="可恶 （＝。＝）" class="l1">（＝。＝）</a><a href="javascript:;" title="切 ~~( ﹁ ﹁ ) ~~~" class="l2">~~( ﹁ ﹁ ) ~~~</a><a href="javascript:;" title="去 (ーー゛)" class="l1">(ーー゛)</a><a href="javascript:;" title="生气 (ー`´ー)" class="l1">(ー`´ー)</a><a href="javascript:;" title="喂 (#`O′)" class="l1">(#`O′)</a><a href="javascript:;" title="怨念 o(一︿一+)o" class="l1">o(一︿一+)o</a><a href="javascript:;" title="崩溃 o(≧口≦)o" class="l1">o(≧口≦)o</a><a href="javascript:;" title="不是我 ㄟ( ▔, ▔ )ㄏ" class="l1">ㄟ( ▔, ▔ )ㄏ</a><a href="javascript:;" title="败了 (o_ _)ﾉ" class="l1">(o_ _)ﾉ</a><a href="javascript:;" title="呃呃呃 (⊙﹏⊙)" class="l1">(⊙﹏⊙)</a><a href="javascript:;" title="切 (ˉ▽￣～) 切~~" class="l2">(ˉ▽￣～) 切~~</a><a href="javascript:;" title="无言 （＊￣（エ）￣）" class="l2">（＊￣（エ）￣）</a><a href="javascript:;" title="摊手 ┑(￣Д ￣)┍" class="l1">┑(￣Д ￣)┍</a><a href="javascript:;" title="不懂 (＠_＠;)" class="l1">(＠_＠;)</a><a href="javascript:;" title="呆 ━┳━　━┳━" class="l1">━┳━　━┳━</a><a href="javascript:;" title="扶额 (☆´益`)c" class="l1">(☆´益`)c</a><a href="javascript:;" title="囧 （´Д`）" class="l1">（´Д`）</a><a href="javascript:;" title="投降 ┗( T﹏T )┛" class="l1">┗( T﹏T )┛</a><a href="javascript:;" title="我错了 (。﹏。*)" class="l1">(。﹏。*)</a><a href="javascript:;" title="喵星人 o( =•ω•= )m" class="l1">o( =•ω•= )m</a><a href="javascript:;" title="喵呜 ≡ω≡" class="l1">≡ω≡</a><a href="javascript:;" title="熊 (*￣(エ)￣)" class="l1">(*￣(エ)￣)</a><a href="javascript:;" title="害羞 (✿◡‿◡)" class="l1">(✿◡‿◡)</a><a href="javascript:;" title="脸红 (*/ω＼*)" class="l1">(*/ω＼*)</a><a href="javascript:;" title="呜呜呜 ┭┮﹏┭┮" class="l1">┭┮﹏┭┮</a><a href="javascript:;" title="拜 ヾ(￣▽￣)Bye~Bye~" class="l2">ヾ(￣▽￣)Bye~Bye~</a><a href="javascript:;" title="斜眼 ( ﹁ ﹁ ) ~→" class="l1">( ﹁ ﹁ ) ~→</a><a href="javascript:;" title="美味 Ψ(￣∀￣)Ψ" class="l1">Ψ(￣∀￣)Ψ</a><a href="javascript:;" title="闪 ✧(≖ ◡ ≖✿)" class="l1">✧(≖ ◡ ≖✿)</a><a href="javascript:;" title="淡定 ━━(￣ー￣*|||━━" class="l2">━━(￣ー￣*|||━━</a><a href="javascript:;" title="恐怖 ┌(。Д。)┐" class="l1">┌(。Д。)┐</a><a href="javascript:;" title="太可怕了 ヽ(*。>Д<)o゜" class="l2">ヽ(*。&gt;Д&lt;)o゜</a><a href="javascript:;" title="orz ○|￣|_" class="l1">○|￣|_</a><a href="javascript:;" title="good o(￣▽￣)ｄ" class="l1">o(￣▽￣)ｄ</a><a href="javascript:;" title="伤心 (；′⌒`)" class="l1">(；′⌒`)</a><a href="javascript:;" title="糟糕 X﹏X" class="l1">X﹏X</a><a href="javascript:;" title="圣诞 *<|:-)" class="l1">*&lt;|:-)</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="2"><a href="javascript:;" title="棒 (๑•̀ㅂ•́)و✧" class="l1">(๑•̀ㅂ•́)و✧</a><a href="javascript:;" title="爆笑 ヾ(≧▽≦*)o" class="l1">ヾ(≧▽≦*)o</a><a href="javascript:;" title="爆笑 o(*≧▽≦)ツ" class="l1">o(*≧▽≦)ツ</a><a href="javascript:;" title="bingo (o゜▽゜)o☆[BINGO!]" class="l1">(o゜▽゜)o☆[BINGO!]</a><a href="javascript:;" title="得瑟 ～(￣▽￣～)(～￣▽￣)～" class="l1">～(￣▽￣～)(～￣▽￣)～</a><a href="javascript:;" title="得意 <(￣︶￣)>" class="l1">&lt;(￣︶￣)&gt;</a><a href="javascript:;" title="嗯哪 嗯~ o(*￣▽￣*)o" class="l1">嗯~ o(*￣▽￣*)o</a><a href="javascript:;" title="飞 ︿(￣︶￣)︿" class="l1">︿(￣︶￣)︿</a><a href="javascript:;" title="高兴 φ(゜▽゜*)♪" class="l1">φ(゜▽゜*)♪</a><a href="javascript:;" title="嘎嘎 ．<{=．．．．（嘎~嘎~嘎~）" class="l1">．&lt;{=．．．．（嘎~嘎~嘎~）</a><a href="javascript:;" title="干杯 (￣▽￣)～■干杯□～(￣▽￣)" class="l1">(￣▽￣)～■干杯□～(￣▽￣)</a><a href="javascript:;" title="跟你说 ╰(￣▽￣)╭" class="l1">╰(￣▽￣)╭</a><a href="javascript:;" title="go <(￣︶￣)↗[GO!]" class="l1">&lt;(￣︶￣)↗[GO!]</a><a href="javascript:;" title="good o(￣▽￣)ｄ" class="l1">o(￣▽￣)ｄ</a><a href="javascript:;" title="哈哈哈哈 *´∀`)´∀`)*´∀`)*´∀`)" class="l1">*´∀`)´∀`)*´∀`)*´∀`)</a><a href="javascript:;" title="嗨 (｡･∀･)ﾉﾞ" class="l1">(｡･∀･)ﾉﾞ</a><a href="javascript:;" title="嗨 ヾ(≧∇≦*)ゝ" class="l1">ヾ(≧∇≦*)ゝ</a><a href="javascript:;" title="好滴 (u‿ฺu✿ฺ)" class="l1">(u‿ฺu✿ฺ)</a><a href="javascript:;" title="好滴 （゜▽＾*））" class="l1">（゜▽＾*））</a><a href="javascript:;" title="好开心 (*^▽^*)" class="l1">(*^▽^*)</a><a href="javascript:;" title="好耶 ヽ(✿ﾟ▽ﾟ)ノ" class="l1">ヽ(✿ﾟ▽ﾟ)ノ</a><a href="javascript:;" title="happy (´▽`ʃ♡ƪ)" class="l1">(´▽`ʃ♡ƪ)</a><a href="javascript:;" title="hi Hi~ o(*￣▽￣*)ブ" class="l1">Hi~ o(*￣▽￣*)ブ</a><a href="javascript:;" title="hiahia ○( ＾皿＾)っHiahiahia…" class="l1">○( ＾皿＾)っHiahiahia…</a><a href="javascript:;" title="high (( へ(へ´∀`)へ" class="l1">(( へ(へ´∀`)へ</a><a href="javascript:;" title="吼吼 ^O^" class="l1">^O^</a><a href="javascript:;" title="欢迎 ( ＾∀＾）／欢迎＼( ＾∀＾）" class="l1">( ＾∀＾）／欢迎＼( ＾∀＾）</a><a href="javascript:;" title="获胜 ヾ(￣ー￣)X(^▽^)ゞ" class="l1">ヾ(￣ー￣)X(^▽^)ゞ</a><a href="javascript:;" title="惊喜 ╰(*°▽°*)╯" class="l1">╰(*°▽°*)╯</a><a href="javascript:;" title="惊喜 ⊙▽⊙" class="l1">⊙▽⊙</a><a href="javascript:;" title="击掌 ( ￣ー￣)人(^▽^ )" class="l1">( ￣ー￣)人(^▽^ )</a><a href="javascript:;" title="快乐 (*^▽^*)" class="l1">(*^▽^*)</a><a href="javascript:;" title="卡拉ok ...φ(0￣*)啦啦啦_φ(*￣0￣)′" class="l1">...φ(0￣*)啦啦啦_φ(*￣0￣)′</a><a href="javascript:;" title="k歌 ...φ(0￣*)啦啦啦_φ(*￣0￣)" class="l1">...φ(0￣*)啦啦啦_φ(*￣0￣)</a><a href="javascript:;" title="啦啦 ♪(^∇^*)" class="l1">♪(^∇^*)</a><a href="javascript:;" title="啦啦啦 ...φ(0￣*)啦啦啦_φ(*￣0￣)>" class="l1">...φ(0￣*)啦啦啦_φ(*￣0￣)&gt;</a><a href="javascript:;" title="乐 (๑´ㅂ`๑)" class="l1">(๑´ㅂ`๑)</a><a href="javascript:;" title="乐 φ(≧ω≦*)♪" class="l1">φ(≧ω≦*)♪</a><a href="javascript:;" title="乐呵 (≧∀≦)ゞ" class="l1">(≧∀≦)ゞ</a><a href="javascript:;" title="满足 (๑¯∀¯๑)" class="l1">(๑¯∀¯๑)</a><a href="javascript:;" title="满足 o(*￣︶￣*)o" class="l1">o(*￣︶￣*)o</a><a href="javascript:;" title="咩哈哈 <(*￣▽￣*)/" class="l1">&lt;(*￣▽￣*)/</a><a href="javascript:;" title="ohyeah ε(*´･∀･｀)зﾞ" class="l1">ε(*´･∀･｀)зﾞ</a><a href="javascript:;" title="哦哦 （≧0≦）//（-_-。）・・・" class="l1">（≧0≦）//（-_-。）・・・</a><a href="javascript:;" title="噢耶 (　ﾟ∀ﾟ) ﾉ♡" class="l1">(　ﾟ∀ﾟ) ﾉ♡</a><a href="javascript:;" title="噢耶 (^&amp;^)/" class="l1">(^&amp;^)/</a><a href="javascript:;" title="拍桌 o(*≧▽≦)ツ┏━┓" class="l1">o(*≧▽≦)ツ┏━┓</a><a href="javascript:;" title="拍手 ””(￣ー￣) (￣ー￣)//””" class="l1">””(￣ー￣) (￣ー￣)//””</a><a href="javascript:;" title="飘 (～￣▽￣)～" class="l1">(～￣▽￣)～</a><a href="javascript:;" title="飘飘然 ︿(￣︶￣)︿" class="l1">︿(￣︶￣)︿</a><a href="javascript:;" title="噗 (/≧▽≦)/" class="l1">(/≧▽≦)/</a><a href="javascript:;" title="期待 (☆▽☆)" class="l1">(☆▽☆)</a><a href="javascript:;" title="散花 *★,°*:.☆(￣▽￣)/$:*.°★* 。" class="l1">*★,°*:.☆(￣▽￣)/$:*.°★* 。</a><a href="javascript:;" title="闪 ✧(≖ ◡ ≖✿)" class="l1">✧(≖ ◡ ≖✿)</a><a href="javascript:;" title="太棒了 ㄟ(≧◇≦)ㄏ" class="l1">ㄟ(≧◇≦)ㄏ</a><a href="javascript:;" title="逃 ヽ(ﾟ∀ﾟ*)ﾉ━━━ｩ♪" class="l1">ヽ(ﾟ∀ﾟ*)ﾉ━━━ｩ♪</a><a href="javascript:;" title="陶醉 ( *︾▽︾)" class="l1">( *︾▽︾)</a><a href="javascript:;" title="thx ☆⌒(*＾-゜)v THX!!" class="l1">☆⌒(*＾-゜)v THX!!</a><a href="javascript:;" title="天啊 ♪(´∇`*)" class="l1">♪(´∇`*)</a><a href="javascript:;" title="万岁 ！*★,°*:.☆(￣▽￣)/$:*.°★* 。" class="l1">！*★,°*:.☆(￣▽￣)/$:*.°★* 。</a><a href="javascript:;" title="我来了 ~(～￣▽￣)～" class="l1">~(～￣▽￣)～</a><a href="javascript:;" title="我回来啦 ||ヽ(*￣▽￣*)ノミ|Ю" class="l1">||ヽ(*￣▽￣*)ノミ|Ю</a><a href="javascript:;" title="兴奋 (p≧w≦q)" class="l1">(p≧w≦q)</a><a href="javascript:;" title="幸福 o(*￣▽￣*)o" class="l1">o(*￣▽￣*)o</a><a href="javascript:;" title="耶 (＾－＾)V" class="l1">(＾－＾)V</a><a href="javascript:;" title="哟 (＾Ｕ＾)ノ~ＹＯ" class="l1">(＾Ｕ＾)ノ~ＹＯ</a><a href="javascript:;" title="有了 (o゜▽゜)o☆" class="l1">(o゜▽゜)o☆</a><a href="javascript:;" title="赞 (((o(*ﾟ▽ﾟ*)o)))" class="l1">(((o(*ﾟ▽ﾟ*)o)))</a><a href="javascript:;" title="涨 (￣︶￣)↗" class="l1">(￣︶￣)↗</a><a href="javascript:;" title="振奋 (o>ε(o>ｕ(≧∩≦)" class="l1">(o&gt;ε(o&gt;ｕ(≧∩≦)</a><a href="javascript:;" title="真好 o(^▽^)o" class="l1">o(^▽^)o</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="3"><a href="javascript:;" title="嗷 (>▽<)" class="l1">(&gt;▽&lt;)</a><a href="javascript:;" title="嗷 ヾ(≧O≦)〃" class="l1">ヾ(≧O≦)〃</a><a href="javascript:;" title="嗷 ┗|｀O′|┛" class="l1">┗|｀O′|┛</a><a href="javascript:;" title="笨 (～￣(OO)￣)ブ" class="l1">(～￣(OO)￣)ブ</a><a href="javascript:;" title="笨蛋 (っ*´Д`)っ" class="l1">(っ*´Д`)っ</a><a href="javascript:;" title="笨人 ヾ(´∀`o)+" class="l1">ヾ(´∀`o)+</a><a href="javascript:;" title="表 <(￣3￣)> 表！" class="l1">&lt;(￣3￣)&gt; 表！</a><a href="javascript:;" title="等等 ...(*￣０￣)ノ" class="l1">...(*￣０￣)ノ</a><a href="javascript:;" title="不要啊 ＞(￣ε￣ = ￣3￣)<" class="l1">＞(￣ε￣ = ￣3￣)&lt;</a><a href="javascript:;" title="蹭 ( *￣▽￣)((≧︶≦*)" class="l1">( *￣▽￣)((≧︶≦*)</a><a href="javascript:;" title="嘟嘴 o(￣ε￣*)" class="l1">o(￣ε￣*)</a><a href="javascript:;" title="嘟嘴 （○｀ 3′○）" class="l1">（○｀ 3′○）</a><a href="javascript:;" title="乖 o(*^＠^*)o" class="l1">o(*^＠^*)o</a><a href="javascript:;" title="鬼脸 (￣┰￣*)" class="l1">(￣┰￣*)</a><a href="javascript:;" title="滚动 (～o￣▽￣)～o..." class="l1">(～o￣▽￣)～o...</a><a href="javascript:;" title="好可爱 （*＾-＾*）" class="l1">（*＾-＾*）</a><a href="javascript:;" title="好喜欢 (≧∇≦)ﾉ" class="l1">(≧∇≦)ﾉ</a><a href="javascript:;" title="坏人 ～(　TロT)σ" class="l1">～(　TロT)σ</a><a href="javascript:;" title="呼唤 (/0￣)o [呼唤]" class="l1">(/0￣)o [呼唤]</a><a href="javascript:;" title="可爱 n(*≧▽≦*)n" class="l1">n(*≧▽≦*)n</a><a href="javascript:;" title="来啦 (～o￣▽￣)～o ~。。。" class="l1">(～o￣▽￣)～o ~。。。</a><a href="javascript:;" title="卖萌 =￣ω￣=" class="l1">=￣ω￣=</a><a href="javascript:;" title="满意 （´v｀）" class="l1">（´v｀）</a><a href="javascript:;" title="捏脸 <( ‵□′)" class="l1">&lt;( ‵□′)</a><a href="javascript:;" title="媚眼 ο(=•ω＜=)ρ⌒☆" class="l1">ο(=•ω＜=)ρ⌒☆</a><a href="javascript:;" title="你好 ヾ(´･ω･｀)ﾉ" class="l1">ヾ(´･ω･｀)ﾉ</a><a href="javascript:;" title="你回来啦 ヾ(^▽^*)))" class="l1">ヾ(^▽^*)))</a><a href="javascript:;" title="飘 (～o￣3￣)～" class="l1">(～o￣3￣)～</a><a href="javascript:;" title="哦 ｍ(o・ω・o)ｍ" class="l1">ｍ(o・ω・o)ｍ</a><a href="javascript:;" title="跑 ε = = (づ′▽`)づ" class="l1">ε = = (づ′▽`)づ</a><a href="javascript:;" title="弱 (。・・)ノ" class="l1">(。・・)ノ</a><a href="javascript:;" title="讨厌 (ノω<。)ノ))☆.。" class="l1">(ノω&lt;。)ノ))☆.。</a><a href="javascript:;" title="thx ☆⌒(*＾-゜)v THX!!" class="l1">☆⌒(*＾-゜)v THX!!</a><a href="javascript:;" title="偷窥 ┬┴┤_•)" class="l1">┬┴┤_•)</a><a href="javascript:;" title="偷看 (/ω＼*)……… (/ω•＼*)" class="l1">(/ω＼*)……… (/ω•＼*)</a><a href="javascript:;" title="推到 (ﾉ*･ω･)ﾉ" class="l1">(ﾉ*･ω･)ﾉ</a><a href="javascript:;" title="吐舌头 (￣┰￣*)" class="l1">(￣┰￣*)</a><a href="javascript:;" title="喂 (#`O′)" class="l1">(#`O′)</a><a href="javascript:;" title="无辜 （o´・ェ・｀o）" class="l1">（o´・ェ・｀o）</a><a href="javascript:;" title="谢 ☆⌒(*＾-゜)v" class="l1">☆⌒(*＾-゜)v</a><a href="javascript:;" title="欣慰 ( ╯▽╰)" class="l1">( ╯▽╰)</a><a href="javascript:;" title="真哒 o(〃'▽'〃)o" class="l1">o(〃'▽'〃)o</a><a href="javascript:;" title="猪 ^(*￣(oo)￣)^" class="l1">^(*￣(oo)￣)^</a><a href="javascript:;" title="做梦 ZZzz…(。-ω-)..ooO" class="l1">ZZzz…(。-ω-)..ooO</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="4"><a href="javascript:;" title="烤鱼 <。)#)))≦" class="l1">&lt;。)#)))≦</a><a href="javascript:;" title="毛毛虫 (..)nnn" class="l1">(..)nnn</a><a href="javascript:;" title="麻雀 (0^◇^0)/" class="l1">(0^◇^0)/</a><a href="javascript:;" title="鱼骨头 >> >=>" class="l1">&gt;&gt; &gt;=&gt;</a><a href="javascript:;" title="猫 (=^ ^=)" class="l1">(=^ ^=)</a><a href="javascript:;" title="螃蟹 ≡[。。]≡" class="l1">≡[。。]≡</a><a href="javascript:;" title="乌贼 <□:≡" class="l1">&lt;□:≡</a><a href="javascript:;" title="老虎 <‵▽′>" class="l1">&lt;‵▽′&gt;</a><a href="javascript:;" title="章鱼 (:◎)≡" class="l1">(:◎)≡</a><a href="javascript:;" title="狮子 ζ。≡" class="l1">ζ。≡</a><a href="javascript:;" title="蜗牛 @/" "="" class="l1">@/"</a><a href="javascript:;" title="乌鸦 Σ^)/" class="l1">Σ^)/</a><a href="javascript:;" title="玫瑰花 --<-<-<@" class="l1">--&lt;-&lt;-&lt;@</a><a href="javascript:;" title="小虫子 ~" "="" class="l1">~"</a><a href="javascript:;" title="烤丸子 ○●○—" class="l1">○●○—</a><a href="javascript:;" title="骨头 ε==3" class="l1">ε==3</a><a href="javascript:;" title="咖啡杯 ■D" "="" class="l1">■D"</a><a href="javascript:;" title="蝌蚪 (。。)～" class="l1">(。。)～</a><a href="javascript:;" title="兔子 /(*ω*)\" class="l1">/(*ω*)\</a><a href="javascript:;" title="水母 (:≡" class="l1">(:≡</a><a href="javascript:;" title="狗狗 U•ェ•*U" class="l1">U•ェ•*U</a><a href="javascript:;" title="河马 （￣。。￣）" class="l1">（￣。。￣）</a><a href="javascript:;" title="老虎 m( =∩王∩= )m" class="l1">m( =∩王∩= )m</a><a href="javascript:;" title="猫 o(=•ェ•=)m" class="l1">o(=•ェ•=)m</a><a href="javascript:;" title="喵 ~o( =∩ω∩= )m" class="l1">~o( =∩ω∩= )m</a><a href="javascript:;" title="喵呜 ≡ω≡" class="l1">≡ω≡</a><a href="javascript:;" title="喵星人 o( =•ω•= )m" class="l1">o( =•ω•= )m</a><a href="javascript:;" title="鸟 --(˙<>˙)/--" class="l1">--(˙&lt;&gt;˙)/--</a><a href="javascript:;" title="牛 ( ఠൠఠ )ﾉ" class="l1">( ఠൠఠ )ﾉ</a><a href="javascript:;" title="熊 (+(工)+╬)" class="l1">(+(工)+╬)</a><a href="javascript:;" title="熊 (*￣(エ)￣)" class="l1">(*￣(エ)￣)</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="5"><a href="javascript:;" title="啊啊 w(ﾟДﾟ)w" class="l1">w(ﾟДﾟ)w</a><a href="javascript:;" title="啊啊啊 Ｏ(≧口≦)Ｏ" class="l1">Ｏ(≧口≦)Ｏ</a><a href="javascript:;" title="才知道 （*゜ー゜*）" class="l1">（*゜ー゜*）</a><a href="javascript:;" title="呆滞 (￣△￣；)" class="l1">(￣△￣；)</a><a href="javascript:;" title="打击 (。_。)" class="l1">(。_。)</a><a href="javascript:;" title="惊 (⊙ˍ⊙)" class="l1">(⊙ˍ⊙)</a><a href="javascript:;" title="惊 Σ(っ °Д °;)っ" class="l1">Σ(っ °Д °;)っ</a><a href="javascript:;" title="惊 Σ(｀д′*ノ)ノ" class="l1">Σ(｀д′*ノ)ノ</a><a href="javascript:;" title="惊 Σ( ° △ °|||)︴" class="l1">Σ( ° △ °|||)︴</a><a href="javascript:;" title="惊喜 ╰(*°▽°*)╯" class="l1">╰(*°▽°*)╯</a><a href="javascript:;" title="惊喜 ⊙▽⊙" class="l1">⊙▽⊙</a><a href="javascript:;" title="举手 _( ﾟДﾟ)ﾉ" class="l1">_( ﾟДﾟ)ﾉ</a><a href="javascript:;" title="愣住 (°ー°〃)" class="l1">(°ー°〃)</a><a href="javascript:;" title="那个 ￣△￣" class="l1">￣△￣</a><a href="javascript:;" title="神啊 ~(￣0￣)/" class="l1">~(￣0￣)/</a><a href="javascript:;" title="是吗 (￣m￣）" class="l1">(￣m￣）</a><a href="javascript:;" title="是吗 ⊙▽⊙" class="l1">⊙▽⊙</a><a href="javascript:;" title="太可怕了 ヽ(*。>Д<)o゜" class="l1">ヽ(*。&gt;Д&lt;)o゜</a><a href="javascript:;" title="wow wow~ ⊙o⊙" class="l1">wow~ ⊙o⊙</a><a href="javascript:;" title="吓 (*Φ皿Φ*)" class="l1">(*Φ皿Φ*)</a><a href="javascript:;" title="咦 (・∀・*)" class="l1">(・∀・*)</a><a href="javascript:;" title="震惊 (○´･д･)ﾉ" class="l1">(○´･д･)ﾉ</a><a href="javascript:;" title="抖 o((⊙﹏⊙))o." class="l1">o((⊙﹏⊙))o.</a><a href="javascript:;" title="鬼 ┏┛墓┗┓..." class="l1">┏┛墓┗┓...</a><a href="javascript:;" title="恐怖 ┌(。Д。)┐" class="l1">┌(。Д。)┐</a><a href="javascript:;" title="没人 ┐(T.T ) ( T.T) ノ" class="l1">┐(T.T ) ( T.T) ノ</a><a href="javascript:;" title="怕怕 ━((*′д｀)爻" class="l1">━((*′д｀)爻</a><a href="javascript:;" title="太可怕了 ヽ(*。>Д<)o゜" class="l1">ヽ(*。&gt;Д&lt;)o゜</a><a href="javascript:;" title="还怕 ヽ(￣︿￣　)" class="l1">ヽ(￣︿￣　)</a><a href="javascript:;" title="有人吗 ||o(*°▽°*)o|Ю" class="l1">||o(*°▽°*)o|Ю</a><a href="javascript:;" title="怕怕 (′д｀*))━!!!!" class="l1">(′д｀*))━!!!!</a><a href="javascript:;" title="小黑屋 —C<(/;◇;)/" class="l1">—C&lt;(/;◇;)/</a><a href="javascript:;" title="鬼 (((m -__-)m" class="l1">(((m -__-)m</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="6"><a href="javascript:;" title="难过 （>○<）" class="l1">（&gt;○&lt;）</a><a href="javascript:;" title="崩溃 o(≧口≦)o" class="l1">o(≧口≦)o</a><a href="javascript:;" title="闭嘴 (⊙x⊙;)" class="l1">(⊙x⊙;)</a><a href="javascript:;" title="不开心 ￣へ￣" class="l1">￣へ￣</a><a href="javascript:;" title="不满 (*￣︿￣)" class="l1">(*￣︿￣)</a><a href="javascript:;" title="不满 （＃￣～￣＃）" class="l1">（＃￣～￣＃）</a><a href="javascript:;" title="不爽 (* ￣︿￣)" class="l1">(* ￣︿￣)</a><a href="javascript:;" title="不要啊 ヽ（≧□≦）ノ" class="l1">ヽ（≧□≦）ノ</a><a href="javascript:;" title="擦 凸(艹皿艹 )" class="l1">凸(艹皿艹 )</a><a href="javascript:;" title="叉腰 <)。(>" class="l1">&lt;)。(&gt;</a><a href="javascript:;" title="冲出 ___*( ￣皿￣)/#____" class="l1">___*( ￣皿￣)/#____</a><a href="javascript:;" title="抽你 抽!╮(￣▽￣///)" class="l1">抽!╮(￣▽￣///)</a><a href="javascript:;" title="踹 <( ￣^￣)(θ(θ☆( >_<" class="l1">&lt;( ￣^￣)(θ(θ☆( &gt;_&lt;</a><a href="javascript:;" title="抽脸 →)╥﹏╥)" class="l1">→)╥﹏╥)</a><a href="javascript:;" title="反对 (ﾟДﾟ*)ﾉ" class="l1">(ﾟДﾟ*)ﾉ</a><a href="javascript:;" title="放屁 ○|￣|_ =3" class="l1">○|￣|_ =3</a><a href="javascript:;" title="不爽 ╰(‵□′)╯" class="l1">╰(‵□′)╯</a><a href="javascript:;" title="哼哼 (；′⌒`)" class="l1">(；′⌒`)</a><a href="javascript:;" title="哼哼 o(￣ヘ￣o＃)" class="l1">o(￣ヘ￣o＃)</a><a href="javascript:;" title="不开心 ゜ロ゜" class="l1">゜ロ゜</a><a href="javascript:;" title="可恶 (〃＞目＜)" class="l1">(〃＞目＜)</a><a href="javascript:;" title="别扭 <(￣ ﹌ ￣)@m" class="l1">&lt;(￣ ﹌ ￣)@m</a><a href="javascript:;" title="可恶 （＝。＝）" class="l1">（＝。＝）</a><a href="javascript:;" title="哪里跑 (///￣皿￣)○～" class="l1">(///￣皿￣)○～</a><a href="javascript:;" title="捏耳朵 ─Ｃε(┬﹏┬)3" class="l1">─Ｃε(┬﹏┬)3</a><a href="javascript:;" title="哼 ε=( o｀ω′)ノ" class="l1">ε=( o｀ω′)ノ</a><a href="javascript:;" title="切 ~~( ﹁ ﹁ ) ~~~" class="l1">~~( ﹁ ﹁ ) ~~~</a><a href="javascript:;" title="去 φ(-ω-*)" class="l1">φ(-ω-*)</a><a href="javascript:;" title="去 (ーー゛)" class="l1">(ーー゛)</a><a href="javascript:;" title="。。。 (╬￣皿￣)" class="l1">(╬￣皿￣)</a><a href="javascript:;" title="去死 (-__-)=@))> o<)" class="l1">(-__-)=@))&gt; o&lt;)</a><a href="javascript:;" title="弱 (。・・)ノ" class="l1">(。・・)ノ</a><a href="javascript:;" title="生气 （｀へ´）" class="l1">（｀へ´）</a><a href="javascript:;" title="生气 (ー`´ー)" class="l1">(ー`´ー)</a><a href="javascript:;" title="生气 <(－︿－)>" class="l1">&lt;(－︿－)&gt;</a><a href="javascript:;" title="什么东西 ( ｀д′)" class="l1">( ｀д′)</a><a href="javascript:;" title="藐视 z(-_-z))" class="l1">z(-_-z))</a><a href="javascript:;" title="是不是你 (σ｀д′)σ" class="l1">(σ｀д′)σ</a><a href="javascript:;" title="逃跑 ～（□`）～" class="l1">～（□`）～</a><a href="javascript:;" title="讨厌 ＼(゜ロ＼)(／ロ゜)／" class="l1">＼(゜ロ＼)(／ロ゜)／</a><a href="javascript:;" title="踢 ヽ(ヽ `д′)" class="l1">ヽ(ヽ `д′)</a><a href="javascript:;" title="吐 ( >ρ < ”)" class="l1">( &gt;ρ &lt; ”)</a><a href="javascript:;" title="喂 (#`O′)" class="l1">(#`O′)</a><a href="javascript:;" title="我去 o(￣ヘ￣o＃)" class="l1">o(￣ヘ￣o＃)</a><a href="javascript:;" title="怨念 o(一︿一+)o" class="l1">o(一︿一+)o</a><a href="javascript:;" title="难看 (╯‵□′)╯" class="l1">(╯‵□′)╯</a><a href="javascript:;" title="发呆 ˋ( ° ▽、° )" class="l1">ˋ( ° ▽、° )</a><a href="javascript:;" title="抓 W(￣_￣)W" class="l1">W(￣_￣)W</a><a href="javascript:;" title="呆住 ((s-_-)s" class="l1">((s-_-)s</a><a href="javascript:;" title="悲 （；´д｀）ゞ" class="l1">（；´д｀）ゞ</a><a href="javascript:;" title="悲剧 (＞﹏＜)" class="l1">(＞﹏＜)</a><a href="javascript:;" title="别走 _____λ......___丬 别走啊～～" class="l1">_____λ......___丬 别走啊～～</a><a href="javascript:;" title="瘪嘴 (*￣︿￣)" class="l1">(*￣︿￣)</a><a href="javascript:;" title="不吃 ( *^-^)ρ(*╯^╰)" class="l1">( *^-^)ρ(*╯^╰)</a><a href="javascript:;" title="擦眼泪 (ノへ￣、)" class="l1">(ノへ￣、)</a><a href="javascript:;" title="抽泣 (ノへ￣、)" class="l1">(ノへ￣、)</a><a href="javascript:;" title="跌 (┬＿┬)↘" class="l1">(┬＿┬)↘</a><a href="javascript:;" title="低落 (#｀-_ゝ-)" class="l1">(#｀-_ゝ-)</a><a href="javascript:;" title="低头 (。﹏。)" class="l1">(。﹏。)</a><a href="javascript:;" title="呼 （。－_－。）" class="l1">（。－_－。）</a><a href="javascript:;" title="困恼 ( -'`-; )" class="l1">( -'`-; )</a><a href="javascript:;" title="累 (ρ_・).。" class="l1">(ρ_・).。</a><a href="javascript:;" title="伤心 (；′⌒`)" class="l1">(；′⌒`)</a><a href="javascript:;" title="失落 (。_。)" class="l1">(。_。)</a><a href="javascript:;" title="衰 (′д｀ )…彡…彡" class="l1">(′д｀ )…彡…彡</a><a href="javascript:;" title="sigh ( ′ 3`) sigh~" class="l1">( ′ 3`) sigh~</a><a href="javascript:;" title="委屈 ╥﹏╥..." class="l1">╥﹏╥...</a><a href="javascript:;" title="呜呜呜 ┭┮﹏┭┮" class="l1">┭┮﹏┭┮</a><a href="javascript:;" title="糟糕 X﹏X" class="l1">X﹏X</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="7"><a href="javascript:;" title="不懂 (＠_＠;)" class="l1">(＠_＠;)</a><a href="javascript:;" title="不知道 ◐▽◑" class="l1">◐▽◑</a><a href="javascript:;" title="愁 ┌|*´∀｀|┘" class="l1">┌|*´∀｀|┘</a><a href="javascript:;" title="大概 (・-・*)" class="l1">(・-・*)</a><a href="javascript:;" title="呆 ━┳━　━┳━" class="l1">━┳━　━┳━</a><a href="javascript:;" title="倒 Σ(っ °Д °;)っ" class="l1">Σ(っ °Д °;)っ</a><a href="javascript:;" title="分裂 分＞(￣▽￣ = ￣︿￣)<裂" class="l1">分＞(￣▽￣ = ￣︿￣)&lt;裂</a><a href="javascript:;" title="扶额 (☆´益`)c" class="l1">(☆´益`)c</a><a href="javascript:;" title="纠结 o(′益`)o" class="l1">o(′益`)o</a><a href="javascript:;" title="扶墙 ...( ＿ ＿)ノ｜壁" class="l1">...( ＿ ＿)ノ｜壁</a><a href="javascript:;" title="困恼 ( -'`-; )" class="l1">( -'`-; )</a><a href="javascript:;" title="愣住 (°ー°〃)" class="l1">(°ー°〃)</a><a href="javascript:;" title="挖鼻屎 (*￣rǒ￣)" class="l1">(*￣rǒ￣)</a><a href="javascript:;" title="乱码 ~%?…,# *'☆&amp;℃$︿★?" class="l1">~%?…,# *'☆&amp;℃$︿★?</a><a href="javascript:;" title="眼睛 (-@y@)" class="l1">(-@y@)</a><a href="javascript:;" title="晕 (((φ(◎ロ◎;)φ)))" class="l1">(((φ(◎ロ◎;)φ)))</a><a href="javascript:;" title="这样么 (=′ー`)" class="l1">(=′ー`)</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="8"><a href="javascript:;" title="鼻涕 (￣ ‘i ￣;)" class="l1">(￣ ‘i ￣;)</a><a href="javascript:;" title="擦眼泪 (ノへ￣、)" class="l1">(ノへ￣、)</a><a href="javascript:;" title="放我出去 ||Φ|(|T|Д|T|)|Φ||" class="l1">||Φ|(|T|Д|T|)|Φ||</a><a href="javascript:;" title="哭死 (;´༎ຶД༎ຶ`)" class="l1">(;´༎ຶД༎ຶ`)</a><a href="javascript:;" title="苦命 ε(┬┬﹏┬┬)3" class="l1">ε(┬┬﹏┬┬)3</a><a href="javascript:;" title="内牛满面 〒▽〒" class="l1">〒▽〒</a><a href="javascript:;" title="tat (ノへ￣、)" class="l1">(ノへ￣、)</a><a href="javascript:;" title="tat o(TヘTo)" class="l1">o(TヘTo)</a><a href="javascript:;" title="委屈 ╥﹏╥..." class="l1">╥﹏╥...</a><a href="javascript:;" title="呜呜呜 ┭┮﹏┭┮" class="l1">┭┮﹏┭┮</a><a href="javascript:;" title="低头 (。﹏。)" class="l1">(。﹏。)</a><a href="javascript:;" title="呼 （。－_－。）" class="l1">（。－_－。）</a><a href="javascript:;" title="困恼 ( -'`-; )" class="l1">( -'`-; )</a><a href="javascript:;" title="累 (ρ_・).。" class="l1">(ρ_・).。</a><a href="javascript:;" title="伤心 (；′⌒`)" class="l1">(；′⌒`)</a><a href="javascript:;" title="失落 (。_。)" class="l1">(。_。)</a><a href="javascript:;" title="委屈 ╥﹏╥..." class="l1">╥﹏╥...</a><a href="javascript:;" title="呜呜呜 ┭┮﹏┭┮" class="l1">┭┮﹏┭┮</a><a href="javascript:;" title="悲剧 (＞﹏＜)" class="l1">(＞﹏＜)</a><a href="javascript:;" title="抽泣 (ノへ￣、)" class="l1">(ノへ￣、)</a><a href="javascript:;" title="跌 (┬＿┬)↘" class="l1">(┬＿┬)↘</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="9"><a href="javascript:;" title="不屑 (￣_,￣ )" class="l1">(￣_,￣ )</a><a href="javascript:;" title="臭美 (o≖◡≖)" class="l1">(o≖◡≖)</a><a href="javascript:;" title="蠢哭 (๐॔˃̶ᗜ˂̶๐॓)" class="l1">(๐॔˃̶ᗜ˂̶๐॓)</a><a href="javascript:;" title="嘚瑟 ʅ（´◔౪◔）ʃ" class="l1">ʅ（´◔౪◔）ʃ</a><a href="javascript:;" title="骄傲 (‾◡◝)" class="l1">(‾◡◝)</a><a href="javascript:;" title="矜持 ( ͡° ͜ʖ ͡°)" class="l1">( ͡° ͜ʖ ͡°)</a><a href="javascript:;" title="冷笑 （ ￣ー￣）" class="l1">（ ￣ー￣）</a><a href="javascript:;" title="冷艳 ┌( ´_ゝ` )┐" class="l1">┌( ´_ゝ` )┐</a><a href="javascript:;" title="蔑视 (￣_,￣ )" class="l1">(￣_,￣ )</a><a href="javascript:;" title="轻蔑 (´ｰ∀ｰ`)" class="l1">(´ｰ∀ｰ`)</a><a href="javascript:;" title="切 (ˉ▽￣～) 切~~" class="l1">(ˉ▽￣～) 切~~</a><a href="javascript:;" title="无视 (☆-ｖ-)" class="l1">(☆-ｖ-)</a><a href="javascript:;" title="无言 (－∀＝)" class="l1">(－∀＝)</a><a href="javascript:;" title="斜眼 ( ﹁ ﹁ ) ~→" class="l1">( ﹁ ﹁ ) ~→</a><a href="javascript:;" title="指 <(￣ ﹌ ￣)@m" class="l1">&lt;(￣ ﹌ ￣)@m</a><a href="javascript:;" title="自恋 (◡ᴗ◡✿)" class="l1">(◡ᴗ◡✿)</a><a href="javascript:;" title="自拍 *(੭*ˊᵕˋ)੭*ଘ" class="l1">*(੭*ˊᵕˋ)੭*ଘ</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="10"><a href="javascript:;" title="叉腰 <)。(>" class="l1">&lt;)。(&gt;</a><a href="javascript:;" title="淡定 ━━(￣ー￣*|||━━" class="l1">━━(￣ー￣*|||━━</a><a href="javascript:;" title="当然 <(ˉ^ˉ)>" class="l1">&lt;(ˉ^ˉ)&gt;</a><a href="javascript:;" title="得瑟 (～￣▽￣)～" class="l1">(～￣▽￣)～</a><a href="javascript:;" title="得意 <(￣ˇ￣)/" class="l1">&lt;(￣ˇ￣)/</a><a href="javascript:;" title="点头 ＿（￣ー￣（＿" class="l1">＿（￣ー￣（＿</a><a href="javascript:;" title="嗯哼 ノ~~マ☆’.・.・:★" class="l1">ノ~~マ☆’.・.・:★</a><a href="javascript:;" title="告状 ( σ'ω')σ" class="l1">( σ'ω')σ</a><a href="javascript:;" title="哼哼 (＠￣ー￣＠)" class="l1">(＠￣ー￣＠)</a><a href="javascript:;" title="肌肉 ┗|*｀0′*|┛" class="l1">┗|*｀0′*|┛</a><a href="javascript:;" title="举手 o(*^▽^*)┛" class="l1">o(*^▽^*)┛</a><a href="javascript:;" title="明白 (oﾟvﾟ)ノ" class="l1">(oﾟvﾟ)ノ</a><a href="javascript:;" title="闪 ✧(≖ ◡ ≖✿)" class="l1">✧(≖ ◡ ≖✿)</a><a href="javascript:;" title="我闪 |(•_•) |" class="l1">|(•_•) |</a><a href="javascript:;" title="是啊 (ﾟｰﾟ)" class="l1">(ﾟｰﾟ)</a><a href="javascript:;" title="是啊是啊 ヾ(＠⌒ー⌒＠)ノ" class="l1">ヾ(＠⌒ー⌒＠)ノ</a><a href="javascript:;" title="死吧 ´･∀･)乂(･∀･｀" class="l1">´･∀･)乂(･∀･｀</a><a href="javascript:;" title="陶醉 ( *︾▽︾)" class="l1">( *︾▽︾)</a><a href="javascript:;" title="同意 (。・∀・)ノ" class="l1">(。・∀・)ノ</a><a href="javascript:;" title="无敌 ＢＡ...┗( -o-)┛" class="l1">ＢＡ...┗( -o-)┛</a><a href="javascript:;" title="嘴角 (*ﾟｰﾟ)" class="l1">(*ﾟｰﾟ)</a></div><div class="cnt J_mCustomScrollbar" style="display: none; overflow: hidden; outline: none;" tabindex="11"><a href="javascript:;" title="啵啵 (* ￣3)(ε￣ *)" class="l1">(* ￣3)(ε￣ *)</a><a href="javascript:;" title="飞吻 (*￣3￣)╭" class="l1">(*￣3￣)╭</a><a href="javascript:;" title="挥手帕 (ToT)/~~~" class="l1">(ToT)/~~~</a><a href="javascript:;" title="kiss !(*￣(￣　*)" class="l1">!(*￣(￣　*)</a><a href="javascript:;" title="mua (*╯3╰)" class="l1">(*╯3╰)</a><a href="javascript:;" title="mua （づ￣3￣）づ╭❤～" class="l1">（づ￣3￣）づ╭❤～</a><a href="javascript:;" title="亲亲 o(*￣3￣)o" class="l1">o(*￣3￣)o</a><a href="javascript:;" title="亲亲你 (っ´Ι`)っ" class="l1">(っ´Ι`)っ</a><a href="javascript:;" title="吻别 (*￣;(￣ *)" class="l1">(*￣;(￣ *)</a><a href="javascript:;" title="不行了 (-.-)..zzZZ" class="l1">(-.-)..zzZZ</a><a href="javascript:;" title="打哈欠 (~O~)" class="l1">(~O~)</a><a href="javascript:;" title="困了 (￣o￣)" class="l1">(￣o￣)</a><a href="javascript:;" title="困死了 (p.-)" class="l1">(p.-)</a><a href="javascript:;" title="困死了 (o-ωｑ)).oO" class="l1">(o-ωｑ)).oO</a><a href="javascript:;" title="眠 (つω｀)～" class="l1">(つω｀)～</a><a href="javascript:;" title="闹钟 ☆{{{Д}}} ☆" class="l1">☆{{{Д}}} ☆</a><a href="javascript:;" title="起床 (＿＿*)Ｚｚｚ" class="l1">(＿＿*)Ｚｚｚ</a><a href="javascript:;" title="晚安 みZZzzzz…" class="l1">みZZzzzz…</a><a href="javascript:;" title="晚上好 ￣O￣)ノ　" class="l1">￣O￣)ノ　</a><a href="javascript:;" title="再见 (。・_・)/~~~" class="l1">(。・_・)/~~~</a><a href="javascript:;" title="再见 ┏(＾0＾)┛" class="l1">┏(＾0＾)┛</a><a href="javascript:;" title="走啦 ( ﾟдﾟ)つBye" class="l1">( ﾟдﾟ)つBye</a><a href="javascript:;" title="挥手帕 (ToT)/~~~" class="l1">(ToT)/~~~</a><a href="javascript:;" title="拜 ヾ(￣▽￣)Bye~Bye~" class="l1">ヾ(￣▽￣)Bye~Bye~</a><a href="javascript:;" title="吃点 ψ(｀∇´)ψ" class="l1">ψ(｀∇´)ψ</a><a href="javascript:;" title="吃了 (*￣ω￣)" class="l1">(*￣ω￣)</a><a href="javascript:;" title="好香 (╯▽╰ )好香~~" class="l1">(╯▽╰ )好香~~</a><a href="javascript:;" title="嚼 (￣～￣) 嚼！" class="l1">(￣～￣) 嚼！</a><a href="javascript:;" title="美味 Ψ(￣∀￣)Ψ" class="l1">Ψ(￣∀￣)Ψ</a><a href="javascript:;" title="吞 0＾）吞！" class="l1">0＾）吞！</a><a href="javascript:;" title="喂饭 ( *^-^)ρ(^0^* )" class="l1">( *^-^)ρ(^0^* )</a><a href="javascript:;" title="噎死 ( *⊙~⊙)" class="l1">( *⊙~⊙)</a><a href="javascript:;" title="噎住 [噎住] ( *⊙~⊙)" class="l1">[噎住] ( *⊙~⊙)</a><a href="javascript:;" title="跌倒 ((o_ _)'彡☆" class="l1">((o_ _)'彡☆</a><a href="javascript:;" title="汗死 |(*′口`)" class="l1">|(*′口`)</a><a href="javascript:;" title="汗死 Σ( ° △ °|||)︴" class="l1">Σ( ° △ °|||)︴</a><a href="javascript:;" title="汗死 (lll￢ω￢)" class="l1">(lll￢ω￢)</a><a href="javascript:;" title="画圈 _〆(´Д｀ )" class="l1">_〆(´Д｀ )</a><a href="javascript:;" title="orz ○|￣|_" class="l1">○|￣|_</a><a href="javascript:;" title="挖鼻屎 (*￣rǒ￣)" class="l1">(*￣rǒ￣)</a><a href="javascript:;" title="顶 d=====(￣▽￣*)b" class="l1">d=====(￣▽￣*)b</a><a href="javascript:;" title="对 ＜（＾－＾）＞" class="l1">＜（＾－＾）＞</a><a href="javascript:;" title="干杯 []~(￣▽￣)~*" class="l1">[]~(￣▽￣)~*</a><a href="javascript:;" title="good o(￣▽￣)ｄ" class="l1">o(￣▽￣)ｄ</a><a href="javascript:;" title="好主意 (o゜▽゜)o☆" class="l1">(o゜▽゜)o☆</a><a href="javascript:;" title="加油 (ง •_•)ง" class="l1">(ง •_•)ง</a><a href="javascript:;" title="就是 ヾ(●゜ⅴ゜)ﾉ" class="l1">ヾ(●゜ⅴ゜)ﾉ</a><a href="javascript:;" title="厉害 （。＾▽＾）" class="l1">（。＾▽＾）</a><a href="javascript:;" title="太棒了 ㄟ(≧◇≦)ㄏ" class="l1">ㄟ(≧◇≦)ㄏ</a><a href="javascript:;" title="不屑 (￣_,￣ )" class="l1">(￣_,￣ )</a><a href="javascript:;" title="放屁 ○|￣|_ =3" class="l1">○|￣|_ =3</a><a href="javascript:;" title="鬼脸 (￫ܫ￩)" class="l1">(￫ܫ￩)</a><a href="javascript:;" title="花痴 (❤´艸｀❤)" class="l1">(❤´艸｀❤)</a><a href="javascript:;" title="撅嘴 （〃｀ 3′〃）" class="l1">（〃｀ 3′〃）</a><a href="javascript:;" title="赖 ᕕ( ᐛ )ᕗ" class="l1">ᕕ( ᐛ )ᕗ</a><a href="javascript:;" title="闪 =└(┐卍^o^)卍" class="l1">=└(┐卍^o^)卍</a><a href="javascript:;" title="使坏 ԅ(¯﹃¯ԅ)" class="l1">ԅ(¯﹃¯ԅ)</a><a href="javascript:;" title="挖鼻屎 (*￣rǒ￣)" class="l1">(*￣rǒ￣)</a><a href="javascript:;" title="吓 (☄⊙ω⊙)☄" class="l1">(☄⊙ω⊙)☄</a><a href="javascript:;" title="邪恶 ( ‵▽′)ψ" class="l1">( ‵▽′)ψ</a><a href="javascript:;" title="躺枪 _(:3」∠)_" class="l1">_(:3」∠)_</a></div></div><div id="ascrail2001" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: 52px; left: 417px; height: 141px; opacity: 0; display: block;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 38px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2001-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: 186px; left: 16px; position: absolute; cursor: default; display: none; width: 401px; opacity: 0;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 408px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2002" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2002-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2003" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2003-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2004" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2004-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2005" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2005-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2006" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2006-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2007" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2007-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2008" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2008-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2009" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2009-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2010" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2010-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2011" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: 100; cursor: default; position: absolute; top: -1997px; left: 44.5px; height: 141px; display: none;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2011-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: 100; top: -1863px; left: -356.5px; position: absolute; cursor: default; display: none;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div></div>
                                            </div>
                                        </div>
                                        <div class="ly-fr"><span class="J_CommentWordsCount">0</span>/<span class="J_CommentWordsCountLimit">1000</span><a href="javascript:;" class="J_ReplayBtn replay-btn ly-ml10">发表</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt30">
                            <div class="comment-list">
                                <ul class="J_CommentList">        <li class="clearfix J_Review" data-review-id="1619554">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/90233/avatar/thumb_b9c9e085f160d663b202c5cb3485c4fb.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_8_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/90233" target="_blank">怨念法师</a> <span class="fans-level-e"><i></i>萌新</span><b>本书作者</b></p>
                    <p class="level"><i class="icon-level-h">• 高V</i>LV.10三界圣贤</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="90233"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">【书友群】：1860战略指挥部
【群号】：548634952
——————————————
嘛……总而言之，有什么有意思的建议或疑问，欢迎各位读者进群讨论，作者基本上是全天在线的…………</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-07-17 01:35:13</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
					                    <a href="javascript:;" class="J_Zan zan  num"><s></s><i>175</i></a>
                    					
					                    <a href="javascript:;" class="J_Hei hei  num"><s></s><i>22</i></a>
                    					
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>13</i></a>
                                    </div>
            </div>
            <div id="review_id1619554">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1647482" data-reader-id="1649210" data-reader-name="书客58165921067">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                    </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1649210" target="_blank">书客58165921067</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-12-10 16:02:56</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">🐸</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1647482" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1440834" data-reader-id="1728050" data-reader-name="西卡罗00001">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-06/1728050/avatar/thumb_1b9e7db7d0894761486e4b272c51423e.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1728050" target="_blank">西卡罗00001</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-08-28 22:55:17</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">额，误击，没事反正没人知道</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1440834" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1440830" data-reader-id="1728050" data-reader-name="西卡罗00001">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-06/1728050/avatar/thumb_1b9e7db7d0894761486e4b272c51423e.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1728050" target="_blank">西卡罗00001</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-08-28 22:53:45</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">咦咦咦，发现一个奇怪的指挥部，对着开一炮在说</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1440830" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1396470" data-reader-id="907200" data-reader-name="MOKIN">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-08-13 23:44:29</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">作者有没有要写番外的想法，内容就是1860的满清怎么被万国来艹</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>2</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1396470">
                                                                                                                                <p data-comment-reply-id="393412" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/405314" target="_blank">戒红所</a>: 写了得出事吧……                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="393451" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 毕竟书客，起点在这方面的尺度倒是很大，毕竟满清的菊花万人捅                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1355024" data-reader-id="2189545" data-reader-name="That?">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/2189545/avatar/thumb_e86662195d2d7acdf6dbeafc3be8aa7b.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-09/2189545/avatar/thumb_e86662195d2d7acdf6dbeafc3be8aa7b.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/2189545" target="_blank">That?</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-31 23:56:09</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">感谢指挥部，空降成功over</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1355024" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1348598" data-reader-id="1307546" data-reader-name="虚~子">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/1307546/avatar/thumb_af4f9349ba7747da7a8b9e8834497e81.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-07/1307546/avatar/thumb_af4f9349ba7747da7a8b9e8834497e81.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1307546" target="_blank">虚~子</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-29 21:45:52</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">说吧老老王跟你什么关系。风格有点像。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>10</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1348598">
                                                                                                                                <p data-comment-reply-id="377673" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 换作老 老王来写就不是这样了，他会去写穿越到现代的满清被各种调     教以及跟现代中国各种互动和比烂，毕竟现代中 国只剩下一个上海了                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="378634" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/1307546" target="_blank">虚~子</a>: =_=，长姿势了。                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="378939" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 搞错了，还有个大庆市和鄂尔多斯盘地，后者几乎涵盖了整个黄河几字形地区                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="378951" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/1307546" target="_blank">虚~子</a>: 哈                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="379013" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 长庆油田呈点状分布，涵盖面积37万平方公里，包括整个宁夏，河套，陕北，陇东都留在现世                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="379029" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 也就是说西北那边就是历史上的陕甘边区强化版，不足就是民族结构复杂，至少有几百万的蒙古人和回民                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="379031" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 那块区域工农业布置齐全，而且距离陕甘回乱还有两年时间                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="379127" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/1307546" target="_blank">虚~子</a>: 多谢                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="434694" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/2263692" target="_blank">龙龙化雨</a>: 萌新请教，老老王写的是什么小说？                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="438352" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/1307546" target="_blank">虚~子</a>: 大穿越时代，这本我觉得最好看，尤其是魔改二战这段，穿越时空的蝴蝶。                                                    													                                                </p>
                                                                                        <div>                                                                                                    <span>还有<span>7</span>条回复，</span>
                                                    <a class="J_ReplyHideShow" href="javascript:;">点击查看</a>
                                                                                                                                                </div>
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1341968" data-reader-id="994288" data-reader-name="Anna.">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2016-10/994288/avatar/thumb_fab3cda69eeae4904a825dfa66df2d3a.jpg" src="https://avatar.kuangxiangit.com/novel/img-2016-10/994288/avatar/thumb_fab3cda69eeae4904a825dfa66df2d3a.jpg" style="display: inline;">
                                                                    </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/994288" target="_blank">Anna.</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-27 16:59:50</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">放我进去啊。。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1341968" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1335166" data-reader-id="493357" data-reader-name="基里曼">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/493357/avatar/thumb_fbf06c6f3c70a517f466413a42bce75d.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-09/493357/avatar/thumb_fbf06c6f3c70a517f466413a42bce75d.jpg" style="display: inline;">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/493357" target="_blank">基里曼</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 11:22:10</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">害怕河蟹，赶紧加群</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1335166" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1313856" data-reader-id="1649210" data-reader-name="书客58165921067">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png" style="display: inline;">
                                                                    </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1649210" target="_blank">书客58165921067</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-18 02:58:48</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">吼啊🐸
终于有群了</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1313856" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1313857" data-reader-id="1649210" data-reader-name="书客58165921067">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png" style="display: inline;">
                                                                    </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1649210" target="_blank">书客58165921067</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-18 02:58:48</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">吼啊🐸
终于有群了</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1313857" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                    <div class="reviewAllComment">
                    <a href="javascript:;" class="J_ReviewAllComment" data-count="10">点击展开全部回复</a>
                    </div>
                                                <div class="all-comment-page" style="display: none">
                    <div class="pageIn">
                        <ul>
                            <li style="display: none;"><a href="javascript:;" rel="first">首页</a></li>
                            <li style="display: none;"><a href="javascript:;" rel="prev">上一页</a></li>
                            <li class="selected"><a href="javascript:;">1</a></li>
                            <li><a href="javascript:change_comment_page(2,1619554)" data-ci-pagination-page="2">2</a></li>
                                                                                    <li><a href="javascript:change_comment_page(2,1619554)" data-ci-pagination-page="2">下一页</a></li>
                                                        <li><a href="javascript:change_comment_page(2,1619554)" data-ci-pagination-page="2">尾页</a></li>
                        </ul>
                    </div>
                </div>
                                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1573851">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/90233/avatar/thumb_b9c9e085f160d663b202c5cb3485c4fb.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_8_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/90233" target="_blank">怨念法师</a> <span class="fans-level-e"><i></i>萌新</span><b>本书作者</b></p>
                    <p class="level"><i class="icon-level-h">• 高V</i>LV.10三界圣贤</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="90233"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">【龙套楼】由于本书的内容正如各位所见，是一部娱乐向的群像剧之故，所以目前正缺少各种各样的龙套中……如果各位读者想到了什么有趣的人物的话，欢迎在该楼下报名，咱会酌情挑选其中的人物加入本书之中的…………</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-06-27 16:57:51</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
					                    <a href="javascript:;" class="J_Zan zan  num"><s></s><i>227</i></a>
                    					
					                    <a href="javascript:;" class="J_Hei hei  num"><s></s><i>10</i></a>
                    					
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>83</i></a>
                                    </div>
            </div>
            <div id="review_id1573851">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1625412" data-reader-id="2202271" data-reader-name="小白兔白又白">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/2202271/avatar/thumb_bfb77846df101d6dc6af47462b8cb4f6.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_24_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/2202271" target="_blank">小白兔白又白</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-11-30 20:23:05</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">王文龙，职业冒险家，土豪主播，最喜欢往原始地区钻，在国外到处浪，目前在非洲，买了架直升机，有自制装备(在国外造不带回去没事吧？)</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1625412" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1612519" data-reader-id="7257" data-reader-name="萬王寶座戰列艦">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/7257/avatar/thumb_187d607654cbe372a4437b32df577d81.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/7257" target="_blank">萬王寶座戰列艦</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-11-24 19:29:57</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">强烈要求让我出厂！我要多米小姐姐！我要气死那群只能在地上游的舰娘！</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1612519" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1518786" data-reader-id="1291950" data-reader-name="误食一刀">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-03/1291950/avatar/thumb_6bcbb884f0e15647e306d17a5d7b0704.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_1_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1291950" target="_blank">误食一刀</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-10-02 18:56:05</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">不如来个楚姓三无男子如何？</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1518786" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1499907" data-reader-id="1515953" data-reader-name="艾欧尼亚之光">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/1515953/avatar/thumb_e8edf5a09bef64750ed19c3990977a65.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-09/1515953/avatar/thumb_e8edf5a09bef64750ed19c3990977a65.jpg" style="display: inline;">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1515953" target="_blank">艾欧尼亚之光</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-09-23 08:04:48</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">单人成军士官长，近身战斗王宗超。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>1</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1499907">
                                                                                                                                <p data-comment-reply-id="415329" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/1340825" target="_blank">仓鼠饲养员</a>: 武者路吧的吧友？                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1495278" data-reader-id="326138" data-reader-name="火箭1945">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2016-05/326138/avatar/thumb_f5f52d4f6bc45d67032478b49375b9b6.jpg" src="https://avatar.kuangxiangit.com/novel/img-2016-05/326138/avatar/thumb_f5f52d4f6bc45d67032478b49375b9b6.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/326138" target="_blank">火箭1945</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-09-21 08:12:21</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">安缓泽，左派穿越者，认为生产关系需要改革，又为祖国的强大而感到自豪，由此陷入了精神分裂</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1495278" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1466352" data-reader-id="80229" data-reader-name="顺丰姬">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img/80229/avatar/thumb_c936814ec10b8fd76e3d2af728419979.jpg" src="https://avatar.kuangxiangit.com/novel/img/80229/avatar/thumb_c936814ec10b8fd76e3d2af728419979.jpg" style="display: inline;">
                                    <div class="medal medal_24_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/80229" target="_blank">顺丰姬</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-09-08 12:43:33</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">采用了角色会提醒我们吗？</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1466352" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1464871" data-reader-id="88478" data-reader-name="没有心的怪物">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img/88478/avatar/thumb_0ee403da85c88259ee348d41e2e3519f.jpg" src="https://avatar.kuangxiangit.com/novel/img/88478/avatar/thumb_0ee403da85c88259ee348d41e2e3519f.jpg" style="display: inline;">
                                    <div class="medal medal_23_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/88478" target="_blank">没有心的怪物</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-09-07 17:43:53</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">来一个天天登陆英国的哥斯拉怎么样</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1464871" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1462181" data-reader-id="1345127" data-reader-name="书客36135512737">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/1345127/avatar/thumb_0ea471c70aac4325e0d308ce6822e2f2.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-01/1345127/avatar/thumb_0ea471c70aac4325e0d308ce6822e2f2.jpg" style="display: inline;">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1345127" target="_blank">书客36135512737</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-09-06 12:10:24</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">唐封，中度抑郁症患者</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1462181" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1461024" data-reader-id="76054" data-reader-name="利姆露•坦派斯特">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img/76054/avatar/thumb_0bc4f18091810a8d46c4452b48599bf8.jpg" src="https://avatar.kuangxiangit.com/novel/img/76054/avatar/thumb_0bc4f18091810a8d46c4452b48599bf8.jpg" style="display: inline;">
                                    <div class="medal medal_1_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/76054" target="_blank">利姆露•坦派斯特</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-09-05 21:30:20</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">章孟彦
大三学生，专业是科学教育（师范专业），从小就想当一名老师。物理，化学，生物，地理，历史，天文，编程都懂一些，但是不深入（用来向中学生科普可以，但是研究就不行了。）不过教师技能学的很好，在本专业名列前茅。
喜欢打乒乓球，踢足球。喜欢看书，课外时间将近代科学史看过一遍。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1461024" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1459967" data-reader-id="20071" data-reader-name="梦幻礼月">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img/20071/avatar/thumb_0f004d957518bcf40b6b6172cb222e14.jpg" src="https://avatar.kuangxiangit.com/novel/img/20071/avatar/thumb_0f004d957518bcf40b6b6172cb222e14.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/20071" target="_blank">梦幻礼月</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-09-05 11:28:43</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">黄明，穿越者，高考前夕穿越，处于人生中知识储备最丰富的时刻，什么都懂一些，但又不全懂。喜欢打乒乓球，身体素质不差。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1459967" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                    <div class="reviewAllComment">
                    <a href="javascript:;" class="J_ReviewAllComment" data-count="10">点击展开全部回复</a>
                    </div>
                                                <div class="all-comment-page" style="display: none">
                    <div class="pageIn">
                        <ul>
                            <li style="display: none;"><a href="javascript:;" rel="first">首页</a></li>
                            <li style="display: none;"><a href="javascript:;" rel="prev">上一页</a></li>
                            <li class="selected"><a href="javascript:;">1</a></li>
                            <li><a href="javascript:change_comment_page(2,1573851)" data-ci-pagination-page="2">2</a></li>
                                                            <li><a href="javascript:change_comment_page(3,1573851)" data-ci-pagination-page="3">3</a></li>
                                                                                        <li><a href="javascript:change_comment_page(4,1573851)" data-ci-pagination-page="4">4</a></li>
                                                        <li><a href="javascript:change_comment_page(2,1573851)" data-ci-pagination-page="2">下一页</a></li>
                                                        <li><a href="javascript:change_comment_page(9,1573851)" data-ci-pagination-page="9">尾页</a></li>
                        </ul>
                    </div>
                </div>
                                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1622467">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/527637/avatar/thumb_c9e813adb2ed5cba2462083f14b8222c.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_24_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/527637" target="_blank">澡堂老板图拉真</a> <span class="fans-level-e"><i></i>小白</span></p>
                    <p class="level"><i class="icon-level-h">• 高V</i>LV.10三界圣贤</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="527637"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent" style="height: 78px;">1.爱因斯坦死后上了天堂，但他很寂寞，于是上帝派了3个仆人服侍他。 爱因斯坦问第一个：你智商多少？他回答：150。老爱很开心：那我们可以谈谈相对论了。 　　老爱问第二个：你智商多少？他回答：120。老爱：至少我们可以谈谈数学问题。 　　老爱又问第三个：你呢？他回答：70。老爱想了想说：那你对一人一票民主选上帝怎么看？ 　　2.一老农去理发，理发师拒绝收费，说：农民都很苦，我也是农民出身，就不收你钱了。第二天理发店门口多了十个瓜。 　　一教师来理发，理发师也不收钱，说：我从小就尊敬老师，所以不要钱。第二天门口多了十朵康乃馨。 　　一公知也去理发，理发师也不收费，说：你是中国的良心，我怎么好意思向你收费呢？第二天，理发店门口站着十个等着理发的公知。 　　3.某公知去食人族所在的小岛旅游，路过一个人肉专卖店，看到橱窗里有如下标价：普通人的脑每斤19元，五毛的脑每斤20元，公知的脑每斤880元。 　　公知看完大喜，马上对店主说：这说明公知的价值远大于五毛，不是吗？ 　　店主苦笑道：哪里啊，因为公知大多无脑，不知道要抓多少公知，才有那么一斤脑，物以稀为贵啊。 　　4.印度人、犹太人、公知结伴旅行，三人投宿小客栈。客栈只剩一间双人房，必须一人睡柴房。 　　印度人自告奋勇睡柴房，不久他回来了，说柴房里有一只牛，印度人不能睡在圣牛旁。 　　换犹太人睡柴房，但不久他也回来，说柴房里有一头猪，犹太人不能睡在那种肮脏的动物边上。 　　最后只能公知去睡柴房。过了会儿敲门声响，开门一看，门口站着一头牛和一头猪。 　　5.一个经济系研究生和一个公知班学员坐在一起聊天。 　　经济系学生说：“经济学真麻烦，对于同一个问题，每派的经济学家都有不同的答案，伤脑筋啊。” 　　公知班学员自豪的说道：“你还是来学做公知吧。对于公知而言，不管什么问题全都是体制问题。” 　　6.有人问：“老端，听说很多公知总喜欢说谎，你能否告诉我，如何判定他在说谎？” 　　我说：“这个很简单，公知大都比较诚实，很少掩饰自己。你只要注意他的嘴就行了，嘴一动，他就在说谎。” 　　7.话说一个信基督教的公知去森林里玩，突然一只大狗熊出现，公知拼命逃跑，狗熊紧追不舍，一不留神公知脚下打滑摔在地上。 　　公知赶紧向上帝祈祷：主啊，请赶紧把这只凶猛的野兽变成虔诚的信徒吧！ 　　一道灵光闪现，奇迹发生了，狗熊突然跪下，双手放在胸前，低头喃喃自语：感谢主赐给我这道丰盛的晚餐，阿门。 　　8.小时候我跟着老公知学本领。 　　某天，我问老公知：“当了公知真的有那么多的好处吗？可以无量造谣不受罚？可以一边捞体制内的好处，一边受众屌丝膜拜？” 　　老公知叹了一口气，说道：“你太小，是不会懂的了，一入公门深似海，从此节操是路人。到死的时候，才会把节操和你一同安葬，那时候才是完整的身子。” 　　9.两只龟在田头一动不动。 　　公知问老农，两只龟在干什么？ 　　老农：“它们在比耐力，谁先动谁就输。” 　　公知指着龟壳上有甲骨文的龟说：“据我多年研究，这只龟已死五千多年了。” 　　另一只龟伸出头说：“草！死了也不说一声，害老子在这干等！” 　　刚说完话，带甲骨文的龟说话了："你输了吧！哈，公知的话你也信”！ 　　10.一文人在农村诗兴大发：“哇，绿油油的稻田望不到边……”。随后感慨：还是有选票的地方空气好！旁边有位老农说：一看你就是公知。此文人喜不自禁：你是如何看出来的？老农回答：依据有二。一、你赞美的稻田其实是韭菜地，符合公知没常识的原理；二、农村普选贿选成风，又符合公知其实最不懂民主的原理。 　　11.船上坐着一位公知。公知问船夫：“你懂民主吗？”船夫说：“不懂。”“你的生命价值失去1/3。”公知说。“那你懂人权吗？”“更不懂。”“那你的生命失去了1/2。”突然一个巨浪把船打翻了，公知掉到了河里。船夫问：“你会游泳吗？”公知喊到：“不会。”船夫说：“那你的生命价值就失去了全部。” 　　12.收音机传来主持人美眉的甜美声音：“性是个好东西，很多人都喜欢。”一个公知立马两眼放光，竖起耳朵，还道貌岸然地对旁边的人说：“这个社会肿么啦，如此堕落呀。”听着听着，公知一脸的失望。这时主持人美眉又说：“谈完了杏，我们再来说一说桃子……” 　　13.一公知在微博天天骂中国舔美国，可粉丝数越来越少，拿到手的美分也越来越少，心情郁闷之极，找到一高僧诉苦：“大师！我爱美国之心日月可鉴，天天宣传pussy价值和湿疣民煮，难道这都有错吗？公知这行怎么越来越难混了呢？现在公知这两个字都快臭大街了！！！” 　　大师不语，找来一只鸡，在鸡腿上系一根绳子，大师一拉绳子，鸡立马倒地，但倒地后就立即站起，如此这番一共八次。 　　公知大悟：您意思是让我越挫越勇？坚持到底，一定胜利？ 　　大师用浓厚的乡音回答：哎，我看你还是拉鸡八倒吧！</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;" style="display: inline;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-07-18 03:16:47</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
					                    <a href="javascript:;" class="J_Zan zan  num"><s></s><i>173</i></a>
                    					
					                    <a href="javascript:;" class="J_Hei hei  num"><s></s><i>9</i></a>
                    					
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>7</i></a>
                                    </div>
            </div>
            <div id="review_id1622467">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1647120" data-reader-id="2202271" data-reader-name="小白兔白又白">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/2202271/avatar/thumb_bfb77846df101d6dc6af47462b8cb4f6.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_24_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/2202271" target="_blank">小白兔白又白</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-12-10 12:51:26</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">没啥诚意，全是改的</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>2</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1647120">
                                                                                                                                <p data-comment-reply-id="477907" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/2202271" target="_blank">小白兔白又白</a>: 踩的估计和我一个理由                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="478335" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/527637" target="_blank">澡堂老板图拉真</a>: 我也没说我原创的啊(°ー°〃)就是看着好玩顺手一发                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1615472" data-reader-id="410489" data-reader-name="破碎的梦">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-02/410489/avatar/thumb_0935833ee894c2b9fb5d25ae3208c06e.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/410489" target="_blank">破碎的梦</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-11-26 08:34:02</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">7.9.12比较好笑</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1615472" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1356443" data-reader-id="1614907" data-reader-name="吼姆福袋">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-04/1614907/avatar/thumb_818ac264ac36513f37286064ea575729.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1614907" target="_blank">吼姆福袋</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-08-01 14:03:49</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">第四条啥意思</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>2</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1356443">
                                                                                                                                <p data-comment-reply-id="365793" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/527637" target="_blank">澡堂老板图拉真</a>: 意思是猪和牛嫌弃他                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="461207" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/1371411" target="_blank">八云·墨子</a>: 大概是公知不想睡柴房，想和牛猪一起睡客房然后让那俩去柴房，公知自私无比嘛                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1347002" data-reader-id="2028860" data-reader-name="天道君">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/2028860/avatar/thumb_1e21cab22602c9c2fdf3f0a6dd21736b.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-07/2028860/avatar/thumb_1e21cab22602c9c2fdf3f0a6dd21736b.jpg" style="display: inline;">
                                                                    </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/2028860" target="_blank">天道君</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-29 10:37:58</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">顶一下</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1347002" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1330078" data-reader-id="1015113" data-reader-name="跳跃网络策划">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/1015113/avatar/thumb_3bcdc22c52d9326d8702cdb18fb961d6.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-05/1015113/avatar/thumb_3bcdc22c52d9326d8702cdb18fb961d6.jpg" style="display: inline;">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1015113" target="_blank">跳跃网络策划</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-23 19:02:40</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">都是网上早就有的段子改的</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1330078" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1329151" data-reader-id="1065123" data-reader-name="假如~">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/1065123/avatar/thumb_010de95e97f60b6e56c05ef8ba507e19.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-07/1065123/avatar/thumb_010de95e97f60b6e56c05ef8ba507e19.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1065123" target="_blank">假如~</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-23 12:45:40</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">666</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1329151" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1317457" data-reader-id="1649210" data-reader-name="书客58165921067">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png" style="display: inline;">
                                                                    </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1649210" target="_blank">书客58165921067</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-19 10:28:53</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">(ಡωಡ) </div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1317457" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                    <div class="reviewAllComment">
                    <a href="javascript:;" class="J_ReviewAllComment" data-count="10">点击展开全部回复</a>
                    </div>
                                                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1906751">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2197336/avatar/thumb_a614864711ab7b8b38cea4b9628fa071.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_21_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/2197336" target="_blank">书客15220733665</a> <span class="fans-level-e"><i></i>萌新</span></p>
                    <p class="level"><i class="icon-level-h">• 初V</i>LV.6出类拔萃</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="2197336"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">虽然觉得结局很鸡掰，但又在情理之中，任何一个国家在当上老大后都会堕落，霉帝成了老大后就开始玩弄虚拟经济，西晋突然统一后士族失去方向各种穷奢极欲的享受。</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-12-07 09:00:14</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
										<a href="javascript:;" class="J_Zan zan  "><s></s>点赞</a>
										
										<a href="javascript:;" class="J_Hei hei  "><s></s>点黑</a>
										
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>1</i></a>
                                    </div>
            </div>
            <div id="review_id1906751">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1645969" data-reader-id="2328845" data-reader-name="科洛尼亚侧翼">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/2328845/avatar/thumb_7f75c66225a1205108d858215f36ca16.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_24_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/2328845" target="_blank">科洛尼亚侧翼</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-12-09 22:54:42</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">事实证明，只有不断地开拓创新进取，才不会堕入前尘</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>2</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1645969">
                                                                                                                                <p data-comment-reply-id="478166" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/298333" target="_blank">王晓然</a>: 同时还需要一个敌人                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="478218" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/2328845" target="_blank">科洛尼亚侧翼</a>: 是的，对手，竞争是人类进步的源泉之一                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1734258">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_14_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/266492" target="_blank">游荡星海</a> <span class="fans-level-e"><i></i>小白</span></p>
                    <p class="level"><i class="icon-level-h">• 钻V</i>LV.13荣耀元老</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="266492"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent" style="height: 78px;">今天是阿尔芒-让-于佩儿重要的一天，自从她父亲将10岁的她卖给玫瑰公馆已经过了5年多了，今天是她年满16的日子，也是她被推上公馆展示的日子，今后的命运将在今天决定，紧张促使她握紧了手中的洛林十字。
“准备好了么姑娘们？记住你们中文老师教的中文。祝你们在今天遇见来自中国的王子。”
公馆大门打开，三三两两的中国人走了进来。身边的姑娘开始使用自己那填鸭式中文大声介绍自己希望吸引到注意力，阿尔芒-让-于佩儿挺起了自己饱满的胸膛，深深地吸了一口气，准备模仿同伴的做法。
        这时，一个年轻的中国人径直向她位置走来。
“是我，是我，是我”
那中国人走到她面前看向她身边托盘
“别选手镯，别选手镯”
那中国人拿起了托盘里的戒指💍，抬起
阿尔芒-让-于佩儿的手将戒指戴了上去。
“我找到你了，我的黎塞留，我的黎姐。”</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;" style="display: inline;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-09-01 01:43:34</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
					                    <a href="javascript:;" class="J_Zan zan  num"><s></s><i>4</i></a>
                    					
										<a href="javascript:;" class="J_Hei hei  "><s></s>点黑</a>
										
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>1</i></a>
                                    </div>
            </div>
            <div id="review_id1734258">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1647124" data-reader-id="2202271" data-reader-name="小白兔白又白">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/2202271/avatar/thumb_bfb77846df101d6dc6af47462b8cb4f6.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_24_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/2202271" target="_blank">小白兔白又白</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-12-10 12:52:48</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">？</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1647124" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1911536">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/527637/avatar/thumb_c9e813adb2ed5cba2462083f14b8222c.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_24_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/527637" target="_blank">澡堂老板图拉真</a> <span class="fans-level-e"><i></i>小白</span></p>
                    <p class="level"><i class="icon-level-h">• 高V</i>LV.10三界圣贤</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="527637"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">下次还要写这种东西还是架空吧，这样不需要查那么多历史资料也不用得罪其他国家的人民。</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-12-09 18:09:18</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
										<a href="javascript:;" class="J_Zan zan  "><s></s>点赞</a>
										
										<a href="javascript:;" class="J_Hei hei  "><s></s>点黑</a>
										
										<a href="javascript:;" class="J_FormReply reply"><s></s>回复</a>
					                </div>
            </div>
            <div id="review_id1911536">
                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1605495">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/282675/avatar/thumb_be1778c1de930853cb101da00ae54ba4.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_14_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a> <span class="fans-level-e"><i></i>小白</span></p>
                    <p class="level"><i class="icon-level-h">• 钻V</i>LV.12笑傲江湖</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="282675"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">作者把，皇汉，粉红，精日，日杂，棒子，洋奴什么的等等全说了，为什么没有满遗，，，，民族正确吗？？？</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-07-11 22:42:59</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
					                    <a href="javascript:;" class="J_Zan zan  num"><s></s><i>92</i></a>
                    					
					                    <a href="javascript:;" class="J_Hei hei  num"><s></s><i>19</i></a>
                    					
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>32</i></a>
                                    </div>
            </div>
            <div id="review_id1605495">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1338614" data-reader-id="240320" data-reader-name="海耶">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2016-10/240320/avatar/thumb_109ab8703c82502cae246ca7f15d3c6c.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                    </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/240320" target="_blank">海耶</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-26 13:20:44</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">满意和黄汉之间的关系就和自干五和公知是一样的，大清朝都亡了那么久了。八旗铁杆庄稼都断了100年了。那么多人。有些人倒好，连共和国是汉人汉人政权都说出来了。共和国明明是无产阶级政权好么。。。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>1</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1338614">
                                                                                                                                <p data-comment-reply-id="358727" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/409380" target="_blank">月火sama</a>: 笑话，明明是共党政权                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1338479" data-reader-id="1342175" data-reader-name="伊卡洛德">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/1342175/avatar/thumb_6a13681432fef75c929e251a45df1a31.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_24_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/1342175" target="_blank">伊卡洛德</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-26 12:20:29</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">话说皇汉啊。。。我反对“两少一宽”算不算。另:本人也是根正红苗的汉族</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>1</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1338479">
                                                                                                                                <p data-comment-reply-id="358714" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 特权是个人都羡慕，，，我也羡慕。                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1337897" data-reader-id="105433" data-reader-name="Tawil">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/105433/avatar/thumb_3c987872d85a8d207d4504ef324b2a9c.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_23_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/105433" target="_blank">Tawil</a><span class=""><i></i></span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-26 08:05:39</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">钓鱼？
哇真好玩
还好污客评论没举报</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1337897" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1335344" data-reader-id="907200" data-reader-name="MOKIN">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 12:29:44</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">另外我郑重说一下，我不是什么满遗，只是以前在明史群中被一群皇汉给恶心后开始路转黑，对于满遗我一直当他们脑子有病，只是懒得动嘴而已。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>1</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1335344">
                                                                                                                                <p data-comment-reply-id="357394" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 我可没有偏向谁谁谁的意思                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1335245" data-reader-id="907200" data-reader-name="MOKIN">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 11:48:41</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">你开心就好，继续活在你的世界中吧，我吃饭去了</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1335245" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1335159" data-reader-id="907200" data-reader-name="MOKIN">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 11:19:13</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">真好玩，几句话就上钩了，三伏天火气别太大，喝杯凉茶消消气</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>5</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1335159">
                                                                                                                                <p data-comment-reply-id="357303" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 握个爪                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357327" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 层层粘贴也是辛苦了                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357335" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 给华夏酱滚！华夏酱在也不想见你了！！555~。。。好讨厌，华夏酱好可怜，要用五九式撞你胸口，，，555~                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="358459" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/1342175" target="_blank">伊卡洛德</a>: 噫。。。我看到了什么，这时候该yooooo一发吗？                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="477214" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/558429" target="_blank">都比</a>: 最讨厌什么酱什么桑，一听就知道不是正经的心里有国家的人…最好别在加上一句“啊撸”，精日像                                                    													                                                </p>
                                                                                        <div>                                                                                                    <span>还有<span>2</span>条回复，</span>
                                                    <a class="J_ReplyHideShow" href="javascript:;">点击查看</a>
                                                                                                                                                </div>
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1335106" data-reader-id="282675" data-reader-name="洪荒华夏明国人族">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/282675/avatar/thumb_be1778c1de930853cb101da00ae54ba4.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-01/282675/avatar/thumb_be1778c1de930853cb101da00ae54ba4.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 10:58:48</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">问为什么没有满遗，你说找事，我说为什么不把皇汉去了，你说该黑，你又说皇汉，满遗各五十大板，然后又
说不用提满遗，你这还不叫偏心？？如果说我脑回路清奇，你脑回路应该是断了！！！</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>4</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1335106">
                                                                                                                                <p data-comment-reply-id="357320" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 能陪我玩这么久也是辛苦了，我只是觉得你这个人很搞笑就是了                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357325" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 那句说你是搞事的我承认是误会了，但也仅此而已                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357332" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 网上本来就没什么不能黑的，                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357343" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 满遗皇汉双方都有黑点，各打五十大板不予盾，自己思维出了偏差就怨别人不理解，该怎么说你好呢                                                    													                                                </p>
                                                                                        <div>                                                                                                    <span>还有<span>1</span>条回复，</span>
                                                    <a class="J_ReplyHideShow" href="javascript:;">点击查看</a>
                                                                                                                                                </div>
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1335063" data-reader-id="907200" data-reader-name="MOKIN">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 10:42:43</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">你哪只眼睛看到我偏袒满遗，说皇汉不好就等于偏向满遗，嗯，思维很皇汉，你的脑袋我实在难以理解。本人是清黑，这帽子我担当不起</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>2</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1335063">
                                                                                                                                <p data-comment-reply-id="357279" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 我问为什么没有满遗，你说找事，我说为什么不把皇汉去了，你说该黑，你又说皇汉，满遗各五十大板，然后又
说不用提满遗，你这还不叫偏心？？如果说我脑回路清奇，你脑回路应该是断了！！！                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="477221" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/558429" target="_blank">都比</a>: 作者连皇汉都提到了，但是满遗没提到，评论者只是问问。能撕起来也是醉了                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1334905" data-reader-id="282675" data-reader-name="洪荒华夏明国人族">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/282675/avatar/thumb_be1778c1de930853cb101da00ae54ba4.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-01/282675/avatar/thumb_be1778c1de930853cb101da00ae54ba4.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 09:45:03</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">MOKlN这人真可笑！什么都是皇汉的错，贴吧有人可汉服说成猪穿的衣服，汉族虚无论，汉族是汉朝时的奴隶什么的，有人看不过理论几句，然后被说成皇汉，最后互骂起来，这是谁的错？？！！</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>3</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1334905">
                                                                                                                                <p data-comment-reply-id="357276" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 贴吧里话不投机扣帽子不是很正常吗，你不也是像你口中说的人那样，只是你不自知而已                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357294" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 问为什么没有满遗，你说找事，我说为什么不把皇汉去了，你说该黑，你又说皇汉，满遗各五十大板，然后又
说不用提满遗，你这还不叫偏心？？如果说我脑回路清奇，你脑回路应该是断了！！！                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357314" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 真会脑补还是说你脑袋清奇，                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                    <div class="comment-list-in ly-mt10 J_ReplyHide reply-hide">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1334845" data-reader-id="907200" data-reader-name="MOKIN">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" src="https://avatar.kuangxiangit.com/novel/img-2017-11/907200/avatar/thumb_29328cd654d6ac80a0d7948c72a09d2c.jpg" style="display: inline;">
                                    <div class="medal medal_14_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-07-25 09:19:03</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">这么想黑满遗，出门左转起点中文</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>8</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1334845">
                                                                                                                                <p data-comment-reply-id="357185" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 谁黑满遗？？我就好奇有皇汉这词的地方一定有满遗这词，还有满遗少杂什么的跟皇汉互骂，这里把满遗少杂什么的没有写就问问是不是民族正确定，怎么这你了？？！                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357186" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 再者说皇汉为啥不能黑，一群人整天用民族主义绑架民意                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357187" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 那满遗为什么不能黑？？一讲清朝不好，满清屠杀过汉族他们就用民族团结绑架人！！                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357192" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 你这人真可笑，什么事都是皇汉的错！贴吧有的人都把汉服说成猪穿的衣服，汉族人看不过去理论几句，被说成皇汉，结果骂了起来，你说这是谁的错？？？                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357212" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 哟，这么快高 潮了，看来还是太图样了                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357222" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 我是想说起点那边的人跟你很有共同语言，你high个什么劲啊                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357239" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/907200" target="_blank">MOKIN</a>: 这种破烂事有好拿出来现，这种带节奏的现象每天在各贴吧中没有上千也有八百了，一句话，图样，快去作功课吧                                                    													                                                </p>
                                                                                            <p data-comment-reply-id="357289" class="J_ReplyHide reply-hide">
                                                    <a href="https://www.hbooker.com/bookshelf/282675" target="_blank">洪荒华夏明国人族</a>: 问为什么没有满遗，你说找事，我说为什么不把皇汉去了，你说该黑，你又说皇汉，满遗各五十大板，然后又
说不用提满遗，你这还不叫偏心？？如果说我脑回路清奇，你脑回路应该是断了！！！                                                    													                                                </p>
                                                                                        <div>                                                                                                    <span>还有<span>5</span>条回复，</span>
                                                    <a class="J_ReplyHideShow" href="javascript:;">点击查看</a>
                                                                                                                                                </div>
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                    <div class="reviewAllComment">
                    <a href="javascript:;" class="J_ReviewAllComment" data-count="10">点击展开全部回复</a>
                    </div>
                                                <div class="all-comment-page" style="display: none">
                    <div class="pageIn">
                        <ul>
                            <li style="display: none;"><a href="javascript:;" rel="first">首页</a></li>
                            <li style="display: none;"><a href="javascript:;" rel="prev">上一页</a></li>
                            <li class="selected"><a href="javascript:;">1</a></li>
                            <li><a href="javascript:change_comment_page(2,1605495)" data-ci-pagination-page="2">2</a></li>
                                                            <li><a href="javascript:change_comment_page(3,1605495)" data-ci-pagination-page="3">3</a></li>
                                                                                        <li><a href="javascript:change_comment_page(4,1605495)" data-ci-pagination-page="4">4</a></li>
                                                        <li><a href="javascript:change_comment_page(2,1605495)" data-ci-pagination-page="2">下一页</a></li>
                                                        <li><a href="javascript:change_comment_page(4,1605495)" data-ci-pagination-page="4">尾页</a></li>
                        </ul>
                    </div>
                </div>
                                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1911017">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-06/1728050/avatar/thumb_1b9e7db7d0894761486e4b272c51423e.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_21_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/1728050" target="_blank">西卡罗00001</a> <span class="fans-level-e"><i></i>小白</span></p>
                    <p class="level"><i class="icon-level-h">• 高V</i>LV.9世外高人</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="1728050"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">你他娘的居然入宫</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-12-09 12:14:41</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
										<a href="javascript:;" class="J_Zan zan  "><s></s>点赞</a>
										
										<a href="javascript:;" class="J_Hei hei  "><s></s>点黑</a>
										
										<a href="javascript:;" class="J_FormReply reply"><s></s>回复</a>
					                </div>
            </div>
            <div id="review_id1911017">
                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1908293">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/945805/avatar/thumb_77aa55c7dcf56b553baa7a728f37956d.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_14_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/945805" target="_blank">竹节虫</a> <span class="fans-level-e"><i></i>萌新</span></p>
                    <p class="level"><i class="icon-level-h">• 高V</i>LV.10三界圣贤</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="945805"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">卧了个槽？这就完结了？？？へ(゜∇、°)へ</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-12-07 23:49:12</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
					                    <a href="javascript:;" class="J_Zan zan  num"><s></s><i>5</i></a>
                    					
										<a href="javascript:;" class="J_Hei hei  "><s></s>点黑</a>
										
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>1</i></a>
                                    </div>
            </div>
            <div id="review_id1908293">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1643204" data-reader-id="177998" data-reader-name="梦君麒">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/177998/avatar/thumb_0b0894bc4e55d0c1cce7e5658a3cfa97.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_21_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/177998" target="_blank">梦君麒</a><span class="fans-level-e"><i></i>小白</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-12-08 15:53:53</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">我还以为太空时代要来了呢，神TM直接就烂了……</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply"><s></s>回复</a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1643204" style="display:none;">
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                                        </div>
        </div>
    </li>
        <li class="clearfix J_Review" data-review-id="1871895">
        <div class="img ly-fl">
            <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/1383711/avatar/thumb_fcd74f5d1248ef35415275b93fdace60.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
            <div class="medal medal_14_80"></div>            <i class="icon-sex icon-male"></i>
        </div>
        <div class="ly-fl bd">
            <div class="clearfix">
                <div class="ly-fl">
                    <p class="name"><a href="https://www.hbooker.com/bookshelf/1383711" target="_blank">雷电法王杨叫兽</a> <span class="fans-level-e"><i></i>萌新</span></p>
                    <p class="level"><i class="icon-level-h">• 高V</i>LV.10三界圣贤</p>
                </div>
                <div class="ly-fr">
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="1383711"><i>+</i> 关注</a>
                                        
                </div>
            </div>
            <div class="desc-content J_DescContent">卡文是太监的开始，我猛地发现作者已经太监了好几本了……</div>
            <div class="show-all-bar J_ShowAllBar">
                <a class="J_ShowAllBtn show-all-btn" href="javascript:;">[显示全文]</a>
            </div>
            <div class="clearfix state J_State">
                <div class="ly-fl"><div class="time">2017-11-20 12:21:17</div></div>
                <div class="ly-fr J_CommentOpt">
					<!-- is_forbidbookreview -->
					
										
					                    <a href="javascript:;" class="J_Zan zan  num"><s></s><i>12</i></a>
                    					
										<a href="javascript:;" class="J_Hei hei  "><s></s>点黑</a>
										
					                    <a href="javascript:;" class="J_FormReply reply num"><s></s><i>1</i></a>
                                    </div>
            </div>
            <div id="review_id1871895">
                                                <div class="comment-list-in ly-mt10 ">
                        <ul>
                            <!-- <li class="clearfix J_Review" data-review-id="11" data-reader-id="123" data-reader-name="最爱切尔西"> -->
                            <li class="clearfix J_Review_Comment" data-comment-id="1640331" data-reader-id="2202271" data-reader-name="小白兔白又白">
                                <div class="img ly-fl">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/2202271/avatar/thumb_bfb77846df101d6dc6af47462b8cb4f6.jpg" src="https://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class="medal medal_24_40"></div>                                </div>
                                <div class="ly-fl box-bd">
                                    <div class="clearfix">
                                        <div class="ly-fl">
                                            <p class="name"><a href="https://www.hbooker.com/bookshelf/2202271" target="_blank">小白兔白又白</a><span class="fans-level-e"><i></i>萌新</span> </p>
                                        </div>
                                        <div class="ly-fr">
                                            <div class="time">2017-12-07 10:38:18</div>
                                        </div>
                                    </div>
                                    <div class="desc-content">乌鸦嘴。。。。</div>
                                    <div style="margin:0" class="clearfix state J_State">
                                        <div class="ly-fr J_CommentOpt">
																						
                                            																						<a href="javascript:;" class="J_FormAddReviewComment reply num"><s></s><i>1</i></a>
											                                        </div>
                                    </div>
                                    <div class="reply-list ly-mt10 J_ReviewCommentReply " id="commentid_1640331">
                                                                                                                                <p data-comment-reply-id="475400" class="">
                                                    <a href="https://www.hbooker.com/bookshelf/1383711" target="_blank">雷电法王杨叫兽</a>: 不是我乌鸦嘴，你看看这货那本书不是太监了？我后悔订阅这本书了……你看看这本倒好，不太监，直接强行完结了。                                                    													                                                </p>
                                                                                                                                                                                                                                        
                                                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                                                                        </div>
        </div>
    </li>
    
    <div class="pagination">
            <div class="PageIn">
            <ul>
            <li class="selected"><a href="javascript:">1</a></li><li><a href="javascript:change_review_page(2)" data-ci-pagination-page="2">2</a></li><li><a href="javascript:change_review_page(3)" data-ci-pagination-page="3">3</a></li><li><a href="javascript:change_review_page(2)" data-ci-pagination-page="2" rel="next">&gt;&gt;</a></li>            <li class="pageSkip">
                <span class="ly-fl">跳转到:</span>
                <input type="text" value="1" class="ly-fl skipBox" name="directPageNum" id="directPageNum">
                <span class="ly-fl">/<i>82</i>页</span>
                <a onclick="" href="javascript:void(0);" class="ly-fl pageSkipQd">确认</a>
            </li>
            <input type="hidden" value="1" name="curr_page" id="curr_page">
            <input type="hidden" value="change_review_page(1)" name="curr_url" id="curr_url">
            </ul>
        </div>
        </div>
	<div class="dialog-box dialog-forbid" id="J_ForbidBox" style="display: none;">
		<h1 class="title">禁止发言</h1>
		<p class="tips">禁止此用户在当前板块发言，请选择禁言天数：</p>
		<div class="time-box">
			<a class="select-time" id="J_SelectTime" href="javascript:;" data-time="1">禁言 1 天</a>
			<ul class="time-list" id="J_TimeList">
				<li data-value="1">禁言 1 天</li>
				<li data-value="3">禁言 3 天</li>
				<li data-value="7">禁言 7 天</li>
				<li data-value="15">禁言 15 天</li>
			</ul>
		</div>
	</div>
<script type="text/javascript">
    //书评翻页
    function change_review_page(page) {
        var url1 = HB.config.rootPath + 'book/get_review_list_all';
        url1 = url1+'/'+page;
        loadComment(url1, {book_id: HB.book.book_id}, 1);
    }

    //第二层书评翻页
    function change_comment_page(page,review_id) {
        var url2 = HB.config.rootPath + 'book/get_comment_list_all';
        url2 = url2+'/'+page;
        $commentList2=$("#review_id"+review_id);
        $commentList2.load(url2, {review_id: review_id}, function() {
            showAll();
        });
        $('html,body').animate({scrollTop:$commentList2.offset().top-400}, 800);
    }

    //第三层书评翻页
    function change_reply_page(page,comment_id) {
        var url3 = HB.config.rootPath + 'book/get_reply_list_all';
        url3 = url3+'/'+page;
        $replyList=$("#commentid_"+comment_id);
        $replyList.load(url3, {comment_id: comment_id}, function() {
            showAll();
        });
        $('html,body').animate({scrollTop:$replyList.offset().top-400}, 800);
    }

    //加载书评列表
    function loadComment(url, data, jump) {
        $commentList.load(url, data, function() {
            showAll();
        });

        if (jump == 1){
            $('html,body').animate({scrollTop:$commentList.offset().top-400}, 800);
        }
    }

    function showAll() {
        var h = 78;
        $(".J_CommentList").find(".J_DescContent").each(function() {
            var self = $(this);
            if (self.outerHeight() > h) {
                var $btn = self.next(".J_ShowAllBar").find('.J_ShowAllBtn');
                self.css('height', h+'px');
                $btn.show().one('click', function() {
                    self.css('height', 'auto');
                    $btn.hide();
                });
            }
        });
    }

    $('img.lazyload').length && lazyloadHandle();
    function lazyloadHandle() {
        HB.util.require('jquery.lazyload', function(){
            $("img.lazyload").lazyload({
                threshold : 300,
                // effect : "fadeIn",
                // placeholder: "../images/transparent.png",
                failure_limit: 200,
                skip_invisible : false
            });
        });
    }
</script></ul>
                                <!--<input type="hidden" value="" name="curr_url" id="curr_url">-->
                            </div>
                        </div>

                    </div>

                    <div class="mod-box ly-mt30">
                        <div class="mod-tit1 ly-mr30">
                            <h3><i></i> 同类作品</h3>
                            <a class="ly-fr" href="https://www.hbooker.com/index/cate_book_list/zhaiwen/30" target="_blank">查看更多 &gt;</a>
                        </div>
                        <div class="mod-bd">
                            <ul class="book-list book-list2 J_BookList">
                                                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100038556" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170713/13-07-17005838-65865.jpg" alt="少女与舰队！福州马尾编">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/2085150/avatar/thumb_8182d461bbdae94d7e30075efd859517.jpg" alt="">御坂17465</div>
                                                <div class="n">★高亮★书友群群号191946956，学生证号码请找作者君认领~——生于大海，守于大海，未来展望于大海！加入了由省政府和东海舰队主办的福建马尾海洋学院的林鲤，怀揣着这样的梦想，开始了新的征程！海洋上的生活有喜有悲，但是，真的一帆风顺么？★阅读注意★世界观自《青春波纹/高校舰队》及贴吧@副舰长威廉明娜/@NOKANA新人写手，文笔烂到癫狂，军事方面了解不甚清楚，一知半解，还望多多指正海涵！另付。不打算签约——★写着玩。写着玩哟。诸位有意见/建议/吐槽/谩骂/水贴都请发到书评区来~★感激不尽qwq</div>
                                                <div class="num">82<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100038556" title="少女与舰队！福州马尾编" target="_blank">少女与舰队！福州马尾编</a></div>
                                        <div class="info"><span>2.1万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100026835" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170723/23-07-17162617-20606-100026835.jpg" alt="少女前线：国家意志">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">CA-134</div>
                                                <div class="n">写在最前面：本书从第二卷开始尽作者所能写得真实，不真实之处均有说明，欢迎挑错。封面是Pixiv画师BLACKSOLDIER的原创作品，pid=61370435，已经获得授权。（内容简介太短所以另一部分丢书评区了）手持诸（高）葛（斯）连（步）弩（枪），脚踏凌波微步，身穿CMC动力盔甲，莎拉是一名光荣的星际2机枪兵！觉得游戏不科学？那么请点进来，这里有轻武器对射，有末敏弹支援；有BVR空战，有LGB轰炸。在少女前线的世界中穿梭，乘着审判的翅膀。收到位置，正在接近；Kinalaatum；光荣的战斗就在前方！以克哈的雄心为名！————————在不发生体育课，编程，手被门夹了，被辅导员叫去，赶论文，重病在床之类的事情的时候保证1天1更，有剧情无毒无害可放心食用。将与黑暗对抗到底，我们是卡拉之光，F2，F等7秒，A！</div>
                                                <div class="num">2745<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100026835" title="少女前线：国家意志" target="_blank">少女前线：国家意志</a></div>
                                        <div class="info"><span>82.0万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100047048" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/images/default.jpg" alt="某咸鱼的新历程">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">尤里马林皇帝</div>
                                                <div class="n">就是某咸鱼带着舰娘门在异时空1924年搞事情的故事，当然重点提示就是去搞事情！！搞一个作死的大新闻。</div>
                                                <div class="num">62<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100047048" title="某咸鱼的新历程" target="_blank">某咸鱼的新历程</a></div>
                                        <div class="info"><span>1.7万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100050627" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/images/default.jpg" alt="帝姬之心">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">书客39250369354</div>
                                                <div class="n">柔福帝姬赵嬛嬛，拥有倾国之色。靖康之变后，被掳到金国首府会宁。她为何能躲过金国皇帝的色爪，又为何能周旋于众多金国贵族之间游刃有余？只因她的身体里，是另一个男人的灵魂！一心只想争霸天下。赵构被她撵得狼奔豕突，金兀术不过是她手里的一个备胎，而这个满怀着对赵宋帝国仇恨的幽灵，也终于堂而皇之地回到了临安，以帝姬的身份影响着南宋朝廷的内政和外战。乱国红颜，即将登场。你们期待么？（读者交流群215992862）</div>
                                                <div class="num">19<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100050627" title="帝姬之心" target="_blank">帝姬之心</a></div>
                                        <div class="info"><span>0.4万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100037436" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170701/01-07-17232057-48306.jpg" alt="法兰西最后的胸甲骑兵">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/1381270/avatar/thumb_bcb575a3520c0f9bbf4ced824c4dbef2.jpg" alt="">舰爆狂魔俾斯麦</div>
                                                <div class="n">因为苟作者水平缘故本书已暂时无限期停更(´இ皿இ｀)</div>
                                                <div class="num">391<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100037436" title="法兰西最后的胸甲骑兵" target="_blank">法兰西最后的胸甲骑兵</a></div>
                                        <div class="info"><span>12.6万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100050780" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171123/23-11-17120059-32196.jpg" alt="致四千年后">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/350207/avatar/thumb_9b398d78d40a5a7bd19416378da72411.jpg" alt="">祈耳喵</div>
                                                <div class="n">&nbsp;带着文明系统穿越到公元前十世纪，但幸运或不幸的是，他哪怕是死了也会再度重生到下一个时代，直至四千年后。&nbsp;他从公元前活到中世纪，从文艺复兴活到工业革命，从近未来活到星际时代。他当过国王也当过先知，做过骑士也做过贵族，他是全能的艺术家、天才的发明家……&nbsp;&nbsp;这是一部长达四千年的人类史诗——&nbsp;&nbsp;“致四千年后的我们：”&nbsp;&nbsp;“世界和平了吗？饥荒灭绝了吗？人们能碰到星星了吗？人类的寿命几何？地球的疆界多远？人类……还记得我们吗？”&nbsp;&nbsp;——发掘自地球时代·公元前十世纪，《所罗门·祈祷书》。</div>
                                                <div class="num">16882<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100050780" title="致四千年后" target="_blank">致四千年后</a></div>
                                        <div class="info"><span>172.2万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100053599" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171210/10-12-17002940-9468-100053599.jpg" alt="什么？隔壁超市皮肤半价？">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-09/2175659/avatar/thumb_2e9e61e072b0e6bd2f24ca0100b0310c.jpg" alt="">冷浮屠</div>
                                                <div class="n">这是一个大家都爱玩的游戏。等等？你玩到一半就不玩了？抱歉，为了游戏进程，你可能暂时要被绑架了。没事，我们给你钱，你接着玩游戏。这是一个没有复活机制的游戏。什么？你死了？抱歉，不能复活，你重新买个全息游戏眼镜吧。这是一个没有衣服穿的游戏。MLGB，什么破游戏，老子不穿衣服也就算了，我老婆的时装咋这么贵！都买不起了！什么？隔壁超市皮肤半价？我不当旁白了，谁敢跟我抢皮肤，我跪下来叫爷爷。本书是百合文，游戏背景是封神榜，不过因为作者对封神榜的印象还停留在小学电视剧的阶段，如果有什么不对的地方，多提意见。纣王是女的。谢谢，书友群：665236497</div>
                                                <div class="num">25<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100053599" title="什么？隔壁超市皮肤半价？" target="_blank">什么？隔壁超市皮肤半价？</a></div>
                                        <div class="info"><span>0.5万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100053862" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/images/default.jpg" alt="你是我的安魂曲">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">被自己气到断更</div>
                                                <div class="n">“愿照在你身上的阳光能化解你心中仇恨的坚冰”“愿我滂沱冰雨中的拥抱能温暖你那颗已经冰冷已久的心”“愿万能的上帝能唤醒你被仇恨蒙蔽双眼而步入黑暗的灵魂”“愿你回到当初，我们初识的模样”</div>
                                                <div class="num">1<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100053862" title="你是我的安魂曲" target="_blank">你是我的安魂曲</a></div>
                                        <div class="info"><span>0.1万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100027438" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170508/08-05-17074544-95267-100027438.jpg" alt="战舰伪娘黑潮号">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/280376/avatar/thumb_af503928553e11db221d03c113be8f64.jpg" alt="">阳炎级驱逐舰黑潮</div>
                                                <div class="n">他在战争中意外成为黑潮号上的临时成员，却迅速的成为了战争的牺牲品。至死都以女性身份示人的他，不知为何继承了黑潮号的战舰之魂，在未来转生为战舰少女（伪娘）。没有任何引人注目特点的他，将如何以舰娘的身份面对这新的战争呢？阳炎级驱逐舰三番舰，黑潮号，参上！（黑潮：喂！作者，为什么我是主角啊！我不会装逼打脸的！作者：因为你是伪娘啊！_(:з」∠)_黑潮：我也不想当伪娘啊！(눈_눈)）新书友群：621819942黑潮的裙底有什么？</div>
                                                <div class="num">1082<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100027438" title="战舰伪娘黑潮号" target="_blank">战舰伪娘黑潮号</a></div>
                                        <div class="info"><span>36.9万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100049242" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171129/29-11-17131931-58393-100049242.jpg" alt="被选中的蔚蓝海洋">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-10/1622083/avatar/thumb_442b5f21b9c249ee4f363c3a796375a3.jpg" alt="">Single帆</div>
                                                <div class="n">这是一场没有未来的战争，这也是一次希望渺茫的拯救。呼啸的炮弹、疾驰的战舰、飞舞的战机、悄无声息的鱼雷。由舰娘们掌控着的钢铁巨兽之间最原始的厮杀，最无情的碰撞。最黑暗的时代，最蔚蓝的大海，而我，一个普通的人类？在这里扮演着什么角色？又携带着怎样的使命降临的呢……？楚陌：话说，为啥我这里的船都是驱逐舰呢？等等，vv！别打脸！————本人萌新一名，玩了舰r后喜欢上了这些可爱的舰娘们，当然也沉迷于那些历史上的辉煌海战，但是历史实在太少，我就想通过我的文笔描绘出一个死宅心中最爽，最刺激的海战~当然萌萌哒的舰娘也是少不了滴~</div>
                                                <div class="num">161<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100049242" title="被选中的蔚蓝海洋" target="_blank">被选中的蔚蓝海洋</a></div>
                                        <div class="info"><span>2.2万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100050694" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17015723-84079.jpg" alt="桅杆上虚假的水平线">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">本心静缘</div>
                                                <div class="n">一觉醒来，陌生的天花板，陌生的床，仿佛是上个世纪的五星级酒店。但是，为什么这座酒店会在海上，而我却也变成了一个小女孩？然后我恐怕还会遇到比这种事情更恐怖的问题吧……作者对军事知识也并不娴熟，目前还是处在不断充电的阶段，如有错误请务必指正。多谢</div>
                                                <div class="num">60<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100050694" title="桅杆上虚假的水平线" target="_blank">桅杆上虚假的水平线</a></div>
                                        <div class="info"><span>0.9万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100027932" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17001839-78843-100027932.jpg" alt="灰烬中的重生">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/169214/avatar/thumb_c977a9db73074df6c74f5767891acbc8.jpg" alt="">PyHoxton</div>
                                                <div class="n">“快点，快点启动啊，天杀的！”。。。。。。“我不是怀疑俄军的地面进攻即将到来，而是十分确定。”。。。。。。“我的天......那是不是艾菲尔铁塔？”。。。。。。“救救我......救......救”。。。。。。“太可悲了，你......真是太可悲了，马卡洛夫。”“谁不是呢？”。。。。。。“尘归尘，土归土......”“创世纪，第十九节......对吧”“......没错......”。。。。。。当危机再一次降临我们已经向你警示而你且在绥靖之后瑟瑟发抖现在，我们的战争就是你的战争但是我们将永不忘记自由的代价。</div>
                                                <div class="num">85<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100027932" title="灰烬中的重生" target="_blank">灰烬中的重生</a></div>
                                        <div class="info"><span>1.8万</span>︱<span>战争历史</span></div>
                                    </li>
                                                                                                </ul>
                        </div>
                    </div>

                </div>
            </div>
            <!-- ly-main -->


            <!-- ly-side -->
            <div class="ly-side">

                <!-- 给作者打赏 start-->
                <div class="mod-box">
                    <div class="mod-tit1">
                        <h3><i></i>给作者打赏</h3>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-reward box-shadow">
                            <div class="smile"></div>
                            <button type="button" class="J_DaShang" data-type="shang">打赏~么么哒~~</button>
                            <button type="button" class="btn-primary J_DaShang" data-type="prop">不更新？寄刀片！</button>
                        </div>
                    </div>
                </div>
                <!--给作者打赏 end-->

                <!--粉丝支持 start-->
                <div class="mod-box ly-mt30">
                    <div class="mod-tit1">
                        <h3><i></i>粉丝支持</h3>
                    </div>
                    <div class="mod-bd ly-mt45">
                        <div class="book-fans-support box-shadow">    <div class="bd J_FansTip">
        <ul>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【黑暗祈祷】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/195572" target="_blank">黑暗祈祷</a></span> <i class="icon-level-h">• 高V</i></div>
                            <p>2017-12-10 15:48:45</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img_item/img-2017-09/195572/avatar/thumb_4f2ed3584f7b088102f2cc79c6857c0f.jpg" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-09/195572/avatar/thumb_4f2ed3584f7b088102f2cc79c6857c0f.jpg" alt="" style="display: inline;">
                            <div class="medal medal_21_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【黑暗祈祷】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/195572" target="_blank">黑暗祈祷</a></span> <i class="icon-level-h">• 高V</i></div>
                            <p>2017-12-10 15:48:45</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img_item/img-2017-09/195572/avatar/thumb_4f2ed3584f7b088102f2cc79c6857c0f.jpg" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-09/195572/avatar/thumb_4f2ed3584f7b088102f2cc79c6857c0f.jpg" alt="" style="display: inline;">
                            <div class="medal medal_21_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【作者爸爸】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/1876120" target="_blank">作者爸爸</a></span> <i class="icon-level-h">• 初V</i></div>
                            <p>2017-12-10 11:03:04</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img-2017-06/1876120/avatar/thumb_39d714371c53305e9ab2a46fc7181968.jpg" data-original="https://avatar.kuangxiangit.com/novel/img-2017-06/1876120/avatar/thumb_39d714371c53305e9ab2a46fc7181968.jpg" alt="" style="display: inline;">
                                                        <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【二十四朝】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/1234498" target="_blank">二十四朝</a></span> <i class="icon-level-h">• 高V</i></div>
                            <p>2017-12-08 11:05:31</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img-2017-07/1234498/avatar/thumb_c662a188bac4fa8b0aee576bd9ec2633.jpg" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/1234498/avatar/thumb_c662a188bac4fa8b0aee576bd9ec2633.jpg" alt="" style="display: inline;">
                            <div class="medal medal_14_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【墨韵留香】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/255058" target="_blank">墨韵留香</a></span> <i class="icon-level-h">• 初V</i></div>
                            <p>2017-12-08 07:42:02</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img-2016-12/255058/avatar/thumb_ef00609ad3a073eed622ffb9e57498d3.jpg" data-original="https://avatar.kuangxiangit.com/novel/img-2016-12/255058/avatar/thumb_ef00609ad3a073eed622ffb9e57498d3.jpg" alt="" style="display: inline;">
                            <div class="medal medal_21_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【督府战兵】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/1625127" target="_blank">督府战兵</a></span> <i class="icon-level-h">• 高V</i></div>
                            <p>2017-12-08 03:11:39</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="" style="display: inline;">
                            <div class="medal medal_21_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【汉时雨】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/247387" target="_blank">汉时雨</a></span> <i class="icon-level-h">• 高V</i></div>
                            <p>2017-12-07 22:52:31</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img-2016-08/247387/avatar/thumb_e1b048b019c20c665d8448a852cf13e4.jpg" data-original="https://avatar.kuangxiangit.com/novel/img-2016-08/247387/avatar/thumb_e1b048b019c20c665d8448a852cf13e4.jpg" alt="" style="display: inline;">
                            <div class="medal medal_21_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【书客58235691323】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/2346913" target="_blank">书客58235691323</a></span> <i class="icon-level-h">• 初V</i></div>
                            <p>2017-12-07 19:48:37</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="" style="display: inline;">
                            <div class="medal medal_21_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【陈•克】2月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/66723" target="_blank">陈•克</a></span> <i class="icon-level-h">• 钻V</i></div>
                            <p>2017-12-07 14:44:42</p>
                            <p>
                                投了2月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img-2017-08/66723/avatar/thumb_ba4559b756d67eb231324d1c06d95c34.jpg" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/66723/avatar/thumb_ba4559b756d67eb231324d1c06d95c34.jpg" alt="" style="display: inline;">
                            <div class="medal medal_13_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【天岚】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/885203" target="_blank">天岚</a></span> <i class="icon-level-h">• 高V</i></div>
                            <p>2017-12-07 09:05:35</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="" style="display: inline;">
                            <div class="medal medal_21_67"></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                    </ul>
    </div>

<script type="text/javascript">
    //粉丝弹框
    $(".J_FansTip li").hoverClass();
</script>
<script type="text/javascript">
    $('img.lazyload').length && lazyloadHandle();
    function lazyloadHandle() {
        HB.util.require('jquery.lazyload', function(){
            $("img.lazyload").lazyload({
                threshold : 300,
                // effect : "fadeIn",
                // placeholder: "../images/transparent.png",
                failure_limit: 200,
                skip_invisible : false
            });
        });
    }
</script></div>
                    </div>
                </div>
                <!--粉丝支持 end-->

                <!--本书名人榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i>本书名人榜</h3>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-leaderboard box-shadow"><ul>
    <!-- 票王 -->
            <li>
            <div class="hd">票王 <i>NO.1</i></div>
            <div class="bd clearfix">
                <div class="img ly-fl">
                    <img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/1455238/avatar/thumb_b32e964ef0f00d5f47fd50b4b99218c9.jpg" alt="" src="https://avatar.kuangxiangit.com/novel/img-2017-08/1455238/avatar/thumb_b32e964ef0f00d5f47fd50b4b99218c9.jpg" style="display: inline;">
                    <div class="medal medal_14_80"></div>                    <i class="icon-sex icon-male"></i>
                </div>
                <div class="cnt ly-fl">
                    <p class="name"><span><a href="https://www.hbooker.com/bookshelf/1455238" target="_blank">辣鸡咸鱼干</a></span> <i class="icon-level-4">• 钻V</i></p>
                    <p class="level">经验等级：LV.11盖世英豪</p>
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="1455238"><i>+</i> 关注</a>
                                                        </div>

            </div>
        </li>
    
    <!-- 第一粉丝 -->
            <li>
            <div class="hd">第一粉丝 <i>NO.1</i></div>
            <div class="bd clearfix">
                <div class="img ly-fl">
                    <img class="lazyload" src="https://avatar.kuangxiangit.com/novel/img-2017-08/1529976/avatar/thumb_78633c4cabf36e397a981cb308875e38.jpg" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/1529976/avatar/thumb_78633c4cabf36e397a981cb308875e38.jpg" alt="" style="display: inline;">
                    <div class="medal medal_14_80"></div>                    <i class="icon-sex icon-male"></i>
                </div>
                <div class="cnt ly-fl">
                    <p class="name"><span><a href="https://www.hbooker.com/bookshelf/1529976" target="_blank">东方城管</a></span> <i class="icon-level-4">• 钻V</i></p>
                    <p class="level">经验等级：LV.12笑傲江湖</p>
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="1529976"><i>+</i> 关注</a>
                                                        </div>

            </div>
        </li>
    
</ul>
<script type="text/javascript">
    $('img.lazyload').length && lazyloadHandle();
    function lazyloadHandle() {
        HB.util.require('jquery.lazyload', function(){
            $("img.lazyload").lazyload({
                threshold : 300,
                // effect : "fadeIn",
                // placeholder: "../images/transparent.png",
                failure_limit: 200,
                skip_invisible : false
            });
        });
    }
</script></div>
                    </div>
                </div>
                <!--本书名人榜 end-->


                <div class="fans-tit ly-mt45">
                    <h4>粉丝荣誉榜单</h4>
                </div>

                <!--铁杆粉丝榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i>铁杆粉丝榜</h3>
                    </div>
                    <div class="mod-bd ly-mt30" style="background:#fafafa">
                        <div class="book-fansboard"><script type="text/javascript">
    $('img.lazyload').length && lazyloadHandle();
    function lazyloadHandle() {
        HB.util.require('jquery.lazyload', function(){
            $("img.lazyload").lazyload({
                threshold : 300,
                // effect : "fadeIn",
                // placeholder: "../images/transparent.png",
                failure_limit: 200,
                skip_invisible : false
            });
        });
    }
</script>

<ul>
                        <li class="top1">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/294802" target="_blank"><span class="icon-num icon-num1">26948</span><i class="icon-top icon-top1">1</i><span class="fans-level-e">【贤者】</span>好人菌</a>
            </li>
                    <li class="top2">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1662073" target="_blank"><span class="icon-num icon-num2">12414</span><i class="icon-top icon-top2">2</i><span class="fans-level-e">【赢家】</span>泽野螳螂</a>
            </li>
                    <li class="top3">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/55156" target="_blank"><span class="icon-num icon-num3">10515</span><i class="icon-top icon-top3">3</i><span class="fans-level-e">【赢家】</span>不安定な神様</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1529976" target="_blank"><span class="icon-num icon-num">10114</span><i class="icon-top icon-top4">4</i><span class="fans-level-e">【赢家】</span>东方城管</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/2270146" target="_blank"><span class="icon-num icon-num">8910</span><i class="icon-top icon-top5">5</i><span class="fans-level-e">【现充】</span>江浙闽</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/50009" target="_blank"><span class="icon-num icon-num">7953</span><i class="icon-top icon-top6">6</i><span class="fans-level-e">【现充】</span>仓鼠吱吱吱</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/171017" target="_blank"><span class="icon-num icon-num">7524</span><i class="icon-top icon-top7">7</i><span class="fans-level-e">【现充】</span>那夜，皂滑弄人</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/98763" target="_blank"><span class="icon-num icon-num">7352</span><i class="icon-top icon-top8">8</i><span class="fans-level-e">【现充】</span>姬尔同学提不起劲</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/42300" target="_blank"><span class="icon-num icon-num">6851</span><i class="icon-top icon-top9">9</i><span class="fans-level-e">【现充】</span>合金裝备布狼牙</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/621335" target="_blank"><span class="icon-num icon-num">6688</span><i class="icon-top icon-top10">10</i><span class="fans-level-e">【现充】</span>UMP45</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1486482" target="_blank"><span class="icon-num icon-num">6236</span><i class="icon-top icon-top11">11</i><span class="fans-level-e">【现充】</span>这是约定</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1574768" target="_blank"><span class="icon-num icon-num">5500</span><i class="icon-top icon-top12">12</i><span class="fans-level-e">【现充】</span>幸亏我早弃疗</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/101855" target="_blank"><span class="icon-num icon-num">5300</span><i class="icon-top icon-top13">13</i><span class="fans-level-e">【现充】</span>粟小真</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/17395" target="_blank"><span class="icon-num icon-num">5004</span><i class="icon-top icon-top14">14</i><span class="fans-level-e">【现充】</span>JKing</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/78044" target="_blank"><span class="icon-num icon-num">5000</span><i class="icon-top icon-top15">15</i><span class="fans-level-e">【现充】</span>归墟之民</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1585336" target="_blank"><span class="icon-num icon-num">5000</span><i class="icon-top icon-top16">16</i><span class="fans-level-e">【现充】</span>若若的喵喵</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1741752" target="_blank"><span class="icon-num icon-num">4723</span><i class="icon-top icon-top17">17</i><span class="fans-level-e">【司机】</span>琥珀迦南</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1447849" target="_blank"><span class="icon-num icon-num">4348</span><i class="icon-top icon-top18">18</i><span class="fans-level-e">【司机】</span>平凡仙子</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/771804" target="_blank"><span class="icon-num icon-num">3924</span><i class="icon-top icon-top19">19</i><span class="fans-level-e">【司机】</span>左翼天使彦</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/116136" target="_blank"><span class="icon-num icon-num">3760</span><i class="icon-top icon-top20">20</i><span class="fans-level-e">【司机】</span>威尔士的小羊</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/762793" target="_blank"><span class="icon-num icon-num">3613</span><i class="icon-top icon-top21">21</i><span class="fans-level-e">【司机】</span>九天平安兔</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/547189" target="_blank"><span class="icon-num icon-num">3574</span><i class="icon-top icon-top22">22</i><span class="fans-level-e">【司机】</span>优的记事本</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1087677" target="_blank"><span class="icon-num icon-num">3528</span><i class="icon-top icon-top23">23</i><span class="fans-level-e">【司机】</span>evaxy</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1294629" target="_blank"><span class="icon-num icon-num">3515</span><i class="icon-top icon-top24">24</i><span class="fans-level-e">【司机】</span>隔壁老咸鱼</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/217642" target="_blank"><span class="icon-num icon-num">3453</span><i class="icon-top icon-top25">25</i><span class="fans-level-e">【司机】</span>HYT</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/1361822" target="_blank"><span class="icon-num icon-num">3412</span><i class="icon-top icon-top26">26</i><span class="fans-level-e">【司机】</span>后街卖酱油的龙</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/98679" target="_blank"><span class="icon-num icon-num">3152</span><i class="icon-top icon-top27">27</i><span class="fans-level-e">【司机】</span>三木00</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/144523" target="_blank"><span class="icon-num icon-num">3125</span><i class="icon-top icon-top28">28</i><span class="fans-level-e">【司机】</span>远坂时臣子</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/146184" target="_blank"><span class="icon-num icon-num">3064</span><i class="icon-top icon-top29">29</i><span class="fans-level-e">【司机】</span>重装防御军团少校</a>
            </li>
                    <li class="top">
                <!--<a href="" target="_blank"><span class="icon-num icon-num"></span><i class="icon-top icon-top"></i></a>-->
                <a href="https://www.hbooker.com/bookshelf/141825" target="_blank"><span class="icon-num icon-num">3022</span><i class="icon-top icon-top30">30</i><span class="fans-level-e">【司机】</span>Hjhsj66</a>
            </li>
            </ul>
</div>
                    </div>
                </div>
                <!--铁杆粉丝榜 end-->
                <!--点击榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="recomm-list J_RecommList">
                        <div class="tit1">
                            <p class="ly-fl"><i></i>点击榜</p>
                            <div class="ly-fr rank-list J_RankList"> <a href="javascript:;" class="drop-down">周榜</a><b></b>
                                <ul style="display: none;">
                                    <li><a href="javascript:;" class="selected">周榜</a></li>
                                    <li><a href="javascript:;">月榜</a></li>
                                    <li><a href="javascript:;">总榜</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="tab">
                            <div class="t">本周点击排行</div>
                            <ul>

                                                                                                            <li class="top1">
                                            <a href="https://www.hbooker.com/book/100011781" target="_blank">
                                                <span class="num">74.5万</span><i class="icon-top icon-top1">1</i>【异界幻想】我的大宝剑                                            </a>
                                        </li>
                                                                            <li class="top2">
                                            <a href="https://www.hbooker.com/book/100049792" target="_blank">
                                                <span class="num">66.9万</span><i class="icon-top icon-top2">2</i>【动漫穿越】我，型月，漫画家！                                            </a>
                                        </li>
                                                                            <li class="top3">
                                            <a href="https://www.hbooker.com/book/100050877" target="_blank">
                                                <span class="num">52.1万</span><i class="icon-top icon-top3">3</i>【动漫穿越】贪吃蛇的目标是吞噬星空                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100034670" target="_blank">
                                                <span class="num">49.8万</span><i class="icon-top ">4</i>【超现实都市】遍地英灵的二十一世纪                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100052219" target="_blank">
                                                <span class="num">38.3万</span><i class="icon-top ">5</i>【游戏世界】出逃魔王与线上老婆                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049348" target="_blank">
                                                <span class="num">33.3万</span><i class="icon-top ">6</i>【青春日常】凭什么你也重生啊                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049782" target="_blank">
                                                <span class="num">30.7万</span><i class="icon-top ">7</i>【动漫穿越】魔法少女伊利丹                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100047615" target="_blank">
                                                <span class="num">30.1万</span><i class="icon-top ">8</i>【青春日常】我，日常番里的普通高中生                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100042074" target="_blank">
                                                <span class="num">28.6万</span><i class="icon-top ">9</i>【游戏世界】悲惨世界                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100035360" target="_blank">
                                                <span class="num">28.3万</span><i class="icon-top ">10</i>【动漫穿越】身为全职阶英灵的我其实是历史修正者                                            </a>
                                        </li>
                                                                    
                            </ul>
                        </div>
                        <div style="display:none" class="tab">
                            <div class="t">本月点击排行</div>
                            <ul>
                                                                                                            <li class="top1">
                                            <a href="https://www.hbooker.com/book/100049792" target="_blank">
                                                <span class="num">548.2万</span><i class="icon-top icon-top1">1</i>【动漫穿越】我，型月，漫画家！                                            </a>
                                        </li>
                                                                            <li class="top2">
                                            <a href="https://www.hbooker.com/book/100011781" target="_blank">
                                                <span class="num">392.5万</span><i class="icon-top icon-top2">2</i>【异界幻想】我的大宝剑                                            </a>
                                        </li>
                                                                            <li class="top3">
                                            <a href="https://www.hbooker.com/book/100034670" target="_blank">
                                                <span class="num">307.2万</span><i class="icon-top icon-top3">3</i>【超现实都市】遍地英灵的二十一世纪                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049782" target="_blank">
                                                <span class="num">250.9万</span><i class="icon-top ">4</i>【动漫穿越】魔法少女伊利丹                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100029943" target="_blank">
                                                <span class="num">233.1万</span><i class="icon-top ">5</i>【神秘未知】我，旧日支配者                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100042074" target="_blank">
                                                <span class="num">221.6万</span><i class="icon-top ">6</i>【游戏世界】悲惨世界                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049642" target="_blank">
                                                <span class="num">219.4万</span><i class="icon-top ">7</i>【动漫穿越】次元漫展                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100048623" target="_blank">
                                                <span class="num">209.5万</span><i class="icon-top ">8</i>【动漫穿越】这个世界好危险                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100046232" target="_blank">
                                                <span class="num">202.5万</span><i class="icon-top ">9</i>【动漫穿越】救世主的一百万种求生法则                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100047615" target="_blank">
                                                <span class="num">196.8万</span><i class="icon-top ">10</i>【青春日常】我，日常番里的普通高中生                                            </a>
                                        </li>
                                                                                                </ul>
                        </div>
                        <div style="display:none" class="tab">
                            <div class="t">点击总排行</div>
                            <ul>
                                                                                                            <li class="top1">
                                            <a href="https://www.hbooker.com/book/100011781" target="_blank">
                                                <span class="num">13,962.9万</span><i class="icon-top icon-top1">1</i>【异界幻想】我的大宝剑                                            </a>
                                        </li>
                                                                            <li class="top2">
                                            <a href="https://www.hbooker.com/book/100025268" target="_blank">
                                                <span class="num">6,961.0万</span><i class="icon-top icon-top2">2</i>【青春日常】我为女儿〇一秒                                            </a>
                                        </li>
                                                                            <li class="top3">
                                            <a href="https://www.hbooker.com/book/100029943" target="_blank">
                                                <span class="num">6,423.2万</span><i class="icon-top icon-top3">3</i>【神秘未知】我，旧日支配者                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100018731" target="_blank">
                                                <span class="num">5,488.3万</span><i class="icon-top ">4</i>【超现实都市】我在东瀛画工口本子                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100020459" target="_blank">
                                                <span class="num">4,527.0万</span><i class="icon-top ">5</i>【动漫穿越】你很怠惰呢，德古拉                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100034670" target="_blank">
                                                <span class="num">4,488.1万</span><i class="icon-top ">6</i>【超现实都市】遍地英灵的二十一世纪                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100012892" target="_blank">
                                                <span class="num">4,306.6万</span><i class="icon-top ">7</i>【同人】幻想乡玩家                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100024631" target="_blank">
                                                <span class="num">4,032.7万</span><i class="icon-top ">8</i>【异界幻想】新手村村长                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100022520" target="_blank">
                                                <span class="num">3,972.9万</span><i class="icon-top ">9</i>【动漫穿越】我觉得学医救不了世人                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100020398" target="_blank">
                                                <span class="num">3,721.0万</span><i class="icon-top ">10</i>【动漫穿越】穿越方式黑化的动漫女主                                            </a>
                                        </li>
                                                                                                </ul>
                        </div>
                        <div class="rank-more"><a href="https://www.hbooker.com/index/rank_book_list/click">查看更多 &gt;</a></div>
                    </div>
                </div>
                <!--点击榜 end-->
            </div>
            <!-- ly-side -->

        </div>
        <!--书页 end-->


        <div class="go-top" id="J_GoTop" style="display: block;">
            <a href="javascript:">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->

<!-- 用户操作 -->
<div id="J_TuiJianBox" class="J_GiveGift" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>您的余额:<br>
                <b class="J_HLB">0</b></p>
</div>
<div class="line">
    <p>您的推荐票余量:<br>
        <b class="J_Recommend">1</b></p>
</div>
<div class="line">
    <p>写得太好了，给作者投推荐票:<br>
        <a href="javascript:;" class="no-minus J_noMinus">-</a>
        <input type="text" value="1" class="text-amount J_NumResult" maxlength="10">
        <a href="javascript:;" class="no-plus J_noPlus">+</a> </p>
</div>
<div class="form-btn center ly-mt30">
    <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投推荐票</a></p>
    <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
</div>
</div>
</div>
<div id="J_YuePiaoBox" class="J_GiveGift" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>您的余额:<br>
                <b class="J_HLB">0</b></p>
        </div>
        <div class="line">
            <p>您的月票余量:<br>
                <b class="J_Stock">0</b></p>
        </div>
        <div class="line">
            <p>写得太好了，给作者投月票:<br>
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10">
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
            </p>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投月票</a></p>
            <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>
<div id="J_DingYueBox" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>
                您的余额:<br><b class="J_HLB">0</b>
            </p>
        </div>
        <div class="line">
            <ul class="input-radio J_InputRadio">
                                <li>
                    <a href="javascript:;" class="selected"> <i class="icon-select"></i>全本订阅                        <input type="radio" class="J_NumResult" value="1" style="display:none" checked="checked">
                    </a>
                    <div>需购章节：59 章，<br>
                    	
                   		 应付总额：885 欢乐币<br>
                                                                        <span>您将购买：第一百一十章 ‘海外务工人员’的现状，以及未来的展望</span><br>
                            <span>至：第一百六十九章 日渐拉大的阶级差距</span>
                                        </div></li>
            </ul>
            <!--新增  复选框 start-->
                        <!--新增  复选框 end-->
            <div class="dy-deac ly-mt10">
                1、全本订阅是订阅目前已更新的全部章节，如期间有免费章节和<br>
                已购买章节，下载时将一并下载。<br>
                2、免费章节及已购买章节不会重复扣费，请放心购买。
            </div>
        </div>
        <div class="form-btn center ly-mt30">
                            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">确认订阅</a></p>
                        <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>


<!-- 登录框 -->
<div id="J_LoginBox" class="layout-login" style="display:none">
    <div class="login-box">
        <form action="https://www.hbooker.com/signup/doLoginBox" class="form-box" id="J_LoginForm" name="J_LoginForm" method="post" onsubmit="doLoginBox();return false;">
            <h3>登录</h3>
            <div class="form-group">
                <input type="text" placeholder="手机号/邮箱" class="username" name="username">
                <!--<label id="username-error" class="error" for="username">请填写用户名</label>-->
            </div>
            <div class="form-group">
                <input type="password" placeholder="密码" class="password" name="password">
            </div>
            <div class="form-group code-group">
									<div id="embed-geetest-captcha"></div>
					<p id="geetest-wait">正在加载验证码......</p>
					<p id="geetest-notice">请先拖动验证码到相应位置</p>
					<script>
						HB.util.loadGeetest = function () {
							if (window.geetestCaptchaObj) {
								return;
							}
							var head = document.getElementsByTagName("head")[0];
							var s = document.createElement("script");
							s.src = "https://www.hbooker.com/resources/js/gt.js";
							head.appendChild(s);

							s.onload = s.onreadystatechange = function() {
								if (!this.readyState || 'loaded' === this.readyState || 'complete' === this.readyState) {
									$("#geetest-notice").hide();
									var handlerEmbed = function (captchaObj) {
										$("#dosubmmit").click(function (e) {
											var validate = captchaObj.getValidate();
											if (!validate) {
												$("#geetest-notice").show();
												setTimeout(function () {
													$("#geetest-notice").hide();
												}, 2000);
												e.preventDefault();
											}
										});
										captchaObj.appendTo("#embed-geetest-captcha");
										captchaObj.onReady(function () {
											$("#geetest-wait").hide();
										});
										window.geetestCaptchaObj = captchaObj;
									};
									$.ajax({
										// 获取id，challenge，success（是否启用failback）
										url: "https://www.hbooker.com/signup/geetest_captcha?t=" + (new Date()).getTime(), // 加随机数防止缓存
										type: "get",
										dataType: "json",
										success: function (data) {
											// 使用initGeetest接口
											// 参数1：配置参数
											// 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
											initGeetest({
												gt: data.gt,
												challenge: data.challenge,
												product: "float", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
												offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
												// 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
											}, handlerEmbed);
										}
									});
								}
							};
						};
					</script>
							 </div>
            <div class="form-btn">
                <button type="submit" name="dosubmmit" id="dosubmmit">登录</button>
            </div>
            <div class="form-ft clearfix"> <span class="tl">
		        <label>
                    <input type="checkbox" checked="checked" name="autoLogin" value="1">
                    自动登录</label>
		        </span> <span> <a href="https://www.hbooker.com/signup/register?redirect=https://www.hbooker.com/book/100035235">注册</a> </span> <span class="tr"> <a class="fpw" href="https://www.hbooker.com/signup/modify_passwd_page?redirect=https://www.hbooker.com/book/100035235">忘记密码 &gt;</a> </span> </div>
        </form>
        <div class="login-ft">
            <div class="otherUser">
                <div class="otherUser_T"><span>使用其他账号登录</span><b></b></div>
                <div class="otherUser_B">
                    <a href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2Fbook%2F100035235" class="qqLogin"></a>
<!--                    <a href="javascript:;" class="qqLogin"></a>-->
					<!-- <a href="https://www.hbooker.com/signup/weixin_login" class="weixinLogin"></a> -->
                    <a href="javascript:;" class="wbLogin"></a>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="https://www.hbooker.com/resources/js/jquery-plugins/jquery.validate/jquery.validate.min.js"></script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/dialog-form.js"></script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/artDialog/6.0.4/dialog-min.js"></script>
<script type="text/javascript">
    function doLoginBox(){
        var self = $(this);
        var username = $("input[name='username']").val();
        var password = $("input[name='password']").val();
        
        var autoLogin=$("input[name='autoLogin']:checked").val();
		
		var post_data = {};
		if(window.geetestCaptchaObj) {
			var validate = window.geetestCaptchaObj.getValidate();
			if (!validate) {
				$("#geetest-notice").show();
				setTimeout(function () {
					$("#geetest-notice").hide();
				}, 2000);
				return;
			}
			post_data = {username: username, password: password, autoLogin:autoLogin};
			var validateDict = window.geetestCaptchaObj.getValidate();
			for(var key in validateDict) {
				post_data[key] = validateDict[key];
			}
		} else {
			var code = $("input[name='code']").val();
			if(code==''){
				HB.util.alert("请输入验证码!");
				return;
			}
			post_data = {username: username, password: password, code: code,autoLogin:autoLogin};
		}

        var dosubmmit = $("#dosubmmit");
        if(dosubmmit.prop('disabled')) return false;

        $.ajax({
            url: HB.config.rootPath + 'signup/doLoginBox',
            data: post_data,
            beforeSubmit: function() {
                dosubmmit.prop("disabled", true);
            },
            complete: function () {
                dosubmmit.prop("disabled", false);
            },
            success: function (res) {
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '登录成功！';
                    HB.util.alert(msg);
                    //$("#J_LoginBox").attr('style','display:none');
                    window.location.reload();
                } else {
                    HB.util.alert(res.tip,1);
                    $("#code").trigger('click');
                }
            }
        });
    }
</script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/face.js"></script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/faceImg.js"></script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/book-detail.js"></script>

<script type="text/javascript">
    //加载右侧页面
    var load_right = function(){
        // 粉丝支持
        var fans = $(".book-fans-support");
        var url = "https://www.hbooker.com/book/get_book_operate_list?book_id=100035235";
        fans.load(url);

        // 本书名人榜
        var fans1 = $(".book-leaderboard");
        var url1 = "https://www.hbooker.com/book/get_book_operate_best_reader?book_id=100035235";
        fans1.load(url1);

        // 铁杆粉丝榜
        var fans2 = $(".book-fansboard");
        var url2 = "https://www.hbooker.com/book/get_book_fans_list?book_id=100035235";
        fans2.load(url2);
    }

    $(document).ready(function(){
        load_right();
    });

    (function(){
        var obj = $(".J_Face").closest(".J_BookChapterComment").find('.J_CommentInput');
        $(".J_Face").qfcfaceimg({area: obj});
    })();
    //书评前开始检测是否登陆
    $('.J_CommentInput').focus(function () {
        if (HB.userinfo.reader_id==0) {
            $('.J_CommentInput').blur();
            HB.util.loginDialog();
            return false;
        }
    })
</script><div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="https://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
<!--             <li>
                <dl>
                    <dt>安全认证</dt>
                    <dd><a logo_size="83x30" logo_type="realname" href="http://www.anquan.org" ><script src="http://static.anquan.org/static/outer/js/aq_auth.js"></script></a></dd>
                </dl>
            </li> -->
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright © 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;">
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script><span id="cnzz_stat_icon_1259915916"><a href="http://www.cnzz.com/stat/website.php?web_id=1259915916" target="_blank" title="站长统计">站长统计</a></span><script src=" https://s4.cnzz.com/z_stat.php?id=1259915916" type="text/javascript"></script><script src="https://c.cnzz.com/core.php?web_id=1259915916&amp;t=z" charset="utf-8" type="text/javascript"></script>
</div>

<div tabindex="-1" aria-labelledby="title:1513068083433" aria-describedby="content:1513068083433" style="display: none; position: absolute; outline: 0px; left: 745px; top: 231px;"><div i="dialog" class="ui-dialog"><div class="ui-dialog-arrow-a"></div><div class="ui-dialog-arrow-b"></div><table class="ui-dialog-grid"><tbody><tr><td i="header" class="ui-dialog-header"><button i="close" class="ui-dialog-close" title="cancel">×</button><div i="title" class="ui-dialog-title" id="title:1513068083433"> </div></td></tr><tr><td i="body" class="ui-dialog-body"><div i="content" class="ui-dialog-content" id="content:1513068083433" style="width: 350px;"><div class="dialogLoginBox" id="J_DialogLoginBox" style="">
    <h3 class="title">欢迎每日登录</h3>
    <div class="cnt">
        <p>书客69271084732  你好~~</p>
        <p>送你 <span>
			1		</span> 张推荐票哦~</p>
        <p class="tips">登陆欢乐书客APP，<br>完成每日签到任务，更有欢乐币相送。</p>
        <p>么么哒~~</p>
    </div>
    <div class="opt">
        <!--        <a class="btn-gettuijian" href="javascript:;" id="J_GetTJTicket">领取推荐票</a>-->
        <p class="auto-close"><i id="J_Timer">3</i>s后关闭</p>
    </div>
</div></div></td></tr><tr><td i="footer" class="ui-dialog-footer" style="display: none;"><div i="statusbar" class="ui-dialog-statusbar" style="display: none;"></div><div i="button" class="ui-dialog-button"></div></td></tr></tbody></table></div></div><div id="ascrail2000" class="nicescroll-rails nicescroll-rails-vr" style="width: 7px; z-index: auto; cursor: default; position: absolute; top: 582px; left: 1237.5px; height: 183px; display: none; opacity: 0;"><div class="nicescroll-cursors" style="position: relative; top: 0px; float: right; width: 5px; height: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;"></div></div><div id="ascrail2000-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 7px; z-index: auto; top: 758px; left: 588.5px; position: absolute; cursor: default; display: none; opacity: 0;"><div class="nicescroll-cursors" style="position: absolute; top: 0px; height: 5px; width: 0px; background-color: rgb(200, 200, 200); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px; left: 0px;"></div></div><div tabindex="0" style="opacity: 0.7; background: rgb(0, 0, 0); position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; overflow: hidden; user-select: none; z-index: 1025;" class="ui-popup-backdrop"></div><div tabindex="-1" aria-labelledby="title:1513068083435" aria-describedby="content:1513068083435" class="ui-popup ui-popup-modal ui-popup-show ui-popup-focus" role="alertdialog" style="position: fixed; outline: 0px; left: 183px; top: 132px; z-index: 1026;"><div i="dialog" class="ui-dialog"><div class="ui-dialog-arrow-a"></div><div class="ui-dialog-arrow-b"></div><table class="ui-dialog-grid"><tbody><tr><td i="header" class="ui-dialog-header"><button i="close" class="ui-dialog-close" title="cancel">×</button><div i="title" class="ui-dialog-title" id="title:1513068083435"> </div></td></tr><tr><td i="body" class="ui-dialog-body"><div i="content" class="ui-dialog-content" id="content:1513068083435"><div id="J_DaShangBox" style="">
    <div class="account-type">
        <ol class="input-radio J_InputRadio clearfix">
            <li><a href="javascript:;" class="selected" data-type="shang">打赏</a></li>
            <li><a href="javascript:;" data-type="prop" class="">道具</a></li>
        </ol>
    </div>
    <!-- <div class="account-info account-shang account-shang-planb J_AccountShang">-->
        <div class="account-info account-shang J_AccountShang account-shang-planb" style="display: block;">
        <div class="line">
            <p>您的欢乐币余额:<br>
                <b class="J_HLB">0</b></p>
        </div>
        <div class="line line-pd0">
            <ul class="input-radio J_InputRadio clearfix">
                <li>
                    <a href="javascript:;" class="selected" data-prop-type="37"><span>0</span>
                        <input type="radio" class="J_NumResult" value="100" checked="checked">
                    </a>
                </li>
                <li>
                    <a href="javascript:;" data-prop-type="38"><span>0</span>
                        <input type="radio" class="J_NumResult" value="588">
                    </a>
                </li>
                <li>
                    <a class="bdright" href="javascript:;" data-prop-type="39"><span>0</span>
                        <input type="radio" class="J_NumResult" value="1688">
                    </a>
                </li>
                <li>
                    <a class="bgbottom" href="javascript:;" data-prop-type="40"><span>0</span>
                        <input type="radio" class="J_NumResult" value="5000">
                    </a>
                </li>
                <li>
                    <a class="bgbottom" href="javascript:;" data-prop-type="41"><span>0</span>
                        <input type="radio" class="J_NumResult" value="10000" style="display:none">
                    </a>
                </li>
                <li>
                    <a class="bgbottom bdright" href="javascript:;" data-prop-type="42"><span>0</span>
                        <input type="radio" class="J_NumResult" value="100000" style="display:none">
                    </a>
                </li>
            </ul>
        </div>
        <div class="line-amount J_NumCalculate">
                打赏数量：
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10">
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">立即打赏</a></p>
            <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
    <div class="account-info account-prop J_AccountProp" style="display: none;">
        <div class="line">
            <p>您的欢乐币余额:<br>
                <b class="J_HLB">0</b>
            </p>
        </div>
        <div class="line blade-info">
            <div class="blade ly-fl"></div>
            <h3 class="title">催更刀片</h3>
            <p>想要加快更新速度？试试给作者寄刀片吧！</p>
            <p>单价 <span class="J_BladePrice">100</span> 欢乐币</p>
            <p class="own-blade">拥有 <i class="J_OwnBlade">0</i> 个</p>
            <div class="blade-amount J_BladeAmount">
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10">
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
            </div>
        </div>
        <div class="line">
            <p>需购道具：<i class="J_BladeNum">1</i> x 催更刀片</p>
            <p>应付总额：<b class="J_Consume">100</b> 欢乐币</p>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投出道具</a></p>
            <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>
                        </div></td></tr><tr><td i="footer" class="ui-dialog-footer" style="display: none;"><div i="statusbar" class="ui-dialog-statusbar" style="display: none;"></div><div i="button" class="ui-dialog-button"></div></td></tr></tbody></table></div></div><div tabindex="0" style=""></div></body></html>