@extends('layout.author')

@section('head')
<div class="layui-tab layui-tab-brief">
  <ul class="layui-tab-title" style="border-bottom: 0px">
    <li class="layui-this">作品管理</li>
    <a href="{{url('au_purse')}}"> <li>作者钱包</li></a>
    <li>最新邮件</li>
  </ul>
  <div class="layui-tab-content"></div>
</div>
@endsection


@section('content')

         
<blockquote class="layui-elem-quote layui-text">
 <div class="site-demo-button" style="margin-bottom: 0;">
     <a href="{{url('au_manage')}}"><lable class="layui-btn site-demo-active" data-type="tabAdd" style="background-color: #67b242">作品管理</lable></a>
</div>
</blockquote>
           

<form class="layui-form" action="{{url('au')}}" method="post">
    
     {{csrf_field()}}
  <div class="layui-form-item">
    <label class="layui-form-label">书名</label>
    <div class="layui-input-block">
      <input type="text" name="title" lay-verify="title" autocomplete="off" placeholder="请输入" class="layui-input">
    </div>
  </div>
    <div class="layui-form-item">
    <label class="layui-form-label">进程</label>
    <div class="layui-input-block">
      <input type="radio" name="status" value="1" title="已完结" checked="">
      <input type="radio" name="status" value="2" title="连载中">
    
    </div>
  </div>
    
   
      
<!--  <div class="layui-form-item">
      <label class="layui-form-label">封面</label>
      <div class="layui-upload">
 
          <div class="layui-upload-block" style="float:left">
      <img class="layui-upload-img" src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17102341-79943-100049774.jpg"  style="width:150px;height: 200px;margin-left: 30px" id="demo1">
    <p id="demoText"></p>
   
  </div>
          <div  style="float:left"><button type="button" class="layui-btn" id="test1">上传图片</button>   </div>
</div>  

  </div>-->
    
      <!--<input type="file" name="file（可随便定义）" class="layui-upload-file">-->
    
   
    
    
<!--  <div class="layui-form-item">
    <label class="layui-form-label">封面</label>
    <div class="layui-input-block" >
        <img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17102341-79943-100049774.jpg"  width="150px" height="auto"/>
        <input type="file"  value="上传封面"  lay-filter="demo1" >
    </div>

  </div>-->
  
  <div class="layui-form-item">

    <div class="layui-inline">
      <label class="layui-form-label">类别</label>
      <div class="layui-input-inline" style="margin-left:30px">
        <select name="cate" lay-verify="required" lay-search="">
          <option value="">直接选择或搜索选择</option>
         
          <option value="玄幻">玄幻</option>
          <option value="16">table</option>
          <option value="17">select</option>
          <option value="18">checkbox</option>
          <option value="19">switch</option>
          <option value="20">radio</option>
        </select>
      </div>
    </div>
  </div>
  
  
<!--  <div class="layui-form-item">
    <label class="layui-form-label">复选框</label>
    <div class="layui-input-block">
      <input type="checkbox" name="like[write]" title="写作">
      <input type="checkbox" name="like[read]" title="阅读" checked="">
      <input type="checkbox" name="like[game]" title="游戏">
    </div>
  </div>
  
  <div class="layui-form-item" pane="">
    <label class="layui-form-label">标签</label>
    <div class="layui-input-block">
      <input type="checkbox" name="like1[write]" lay-skin="primary" title="写作" checked="">
      <input type="checkbox" name="like1[read]" lay-skin="primary" title="阅读">
      <input type="checkbox" name="like1[game]" lay-skin="primary" title="游戏" >
        <input type="checkbox" name="like1[game]" lay-skin="primary" title="游戏" > 
        <input type="checkbox" name="like1[game]" lay-skin="primary" title="游戏" > 
        <input type="checkbox" name="like1[game]" lay-skin="primary" title="游戏" > 
        <input type="checkbox" name="like1[game]" lay-skin="primary" title="游戏" > 
        <input type="checkbox" name="like1[game]" lay-skin="primary" title="游戏" >
    </div>
  </div>
  
  <div class="layui-form-item">
    <label class="layui-form-label">开关-默认关</label>
    <div class="layui-input-block">
      <input type="checkbox" name="close" lay-skin="switch" lay-text="ON|OFF">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">开关-默认开</label>
    <div class="layui-input-block">
      <input type="checkbox" checked="" name="open" lay-skin="switch" lay-filter="switchTest" lay-text="ON|OFF">
    </div>
  </div>
-->

  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">简介</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea" name="intro"></textarea>
    </div>
  </div>

  <!--<div class="layui-form-item layui-form-text">
    <label class="layui-form-label">编辑器</label>
    <div class="layui-input-block">
      <textarea class="layui-textarea layui-hide" name="content" lay-verify="content" id="LAY_demo_editor"></textarea>
    </div>
  </div>-->
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit="" lay-filter="demo1">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>
 


<script>
layui.use(['form', 'layedit', 'laydate'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  
  //日期
  laydate.render({
    elem: '#date'
  });
  laydate.render({
    elem: '#date1'
  });
  
  //创建一个编辑器
  var editIndex = layedit.build('LAY_demo_editor');
 

  

  //监听提交
  form.on('submit(demo1)', function(){
    if(value.length < 0){
       return '标题至少得5个字符啊';
     }
    return false;
  });
  
  
});
</script>


<script>
layui.use('upload', function(){
  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '/upload/'
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
   ,done: function(res){ //res 不需要转换JSON，直接用即可
      if(res.code == 0){
      
layer.msg('上传成功！');
      }
    }
  
  });
  
});
</script>



@endsection
