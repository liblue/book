
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>阅读社区</title>
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/style.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/response.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset('home/js/layui/css/layui.css')}}"/>
    <script type="text/javascript" language="javascript" src="{{asset('bootstrap/jquery.js')}}"></script>
    <script type="text/javascript" src="{{asset('home/js/layui/layui.js')}}"></script>
    <!--<script type="text/javascript" src="{{asset('home/js/dialog-min.js')}}"></script>-->



</head>
<body>


<div class="nav-top">
    <div class="ly-wrap">
        <ul class="login-info ly-fl">
                <li><a class="qq" href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow"></a></li>
               @if  (Session::has('user_name'))
               <input type="hidden" value="cunzai"  id="denglu">
                    <li class="userinfo">
                    <a class="avatar" href="{{url('user')}}" target="_selfk" rel="nofollow">
                        <img class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">
                    </a>
                    <i><a href="{{url('user')}}" target="_blank" rel="nofollow"> {{ Session::get('user_nickname') }} </a> </i>
                    <a href="{{url('logout')}}" class="logout" rel="nofollow">[退出]</a>
                    <span>经验等级：LV.1书中过客</span>
                 
                </li>         
                
        @else
         <input type="hidden" value="meiyou"  id="denglu">
                 <li><a href="{{url('login')}}" rel="nofollow">登录</a></li>
                
                
                <li class="line">|</li>
                <li><a href="{{'register'}}" rel="nofollow">注册</a></li>
                
                
           @endif
                    </ul>
           @if  (Session::has('user_name'))
         
        <div class="nav-top-right ly-fr">
            <ul class="special ly-fl clearfix">
                <li class="recharge"><a href="https://www.hbooker.com/recharge/index"><i></i>充值中心</a></li>
                <li class="line">|</li>
                <li class="author"><a href="{{url('au_manage')}}" target="_blank"><i></i>作者后台</a></li>
                <li class="line">|</li>
            </ul>
            <a class="app-download ly-fl" href="http://app.hbooker.com" target="_blank"><img src="" alt=""/></a>
         
        </div>
           @endif
    </div>
</div>

<!--  欢迎每日登录 领取推荐票 -->

<div  style="width:75px;height:70px;background:#f6f3ec;position: fixed;left:19.7%;top:25%">
    <div id="hidden" onclick="cang({{$data->id}})"   style="padding:15px"><i class="layui-icon" style="font-size: 30px; color: gray">&#xe600;</i> <div>收藏</div>  </div>
    <div id="show" onclick="cang({{$data->id}})"style="padding:15px;display:none"><i class="layui-icon" style="font-size: 30px; color: red">&#xe600;</i> <div>已收藏</div>  </div>
    
</div>


<div style="width:75px;height:70px;background: #f6f3ec;position: fixed;left:19.7%;top:33%"><div style="padding:15px"><i class="layui-icon" style="font-size: 30px; color: gray">&#xe60a;</i> 
        <div>目录</div>  </div></div>
<div style="width:75px;height:70px;background: #f6f3ec;position: fixed;left:19.7%;top:41%"><div style="padding:15px"><i class="layui-icon" style="font-size: 30px; color: gray">&#xe735;</i> 
        <div>打赏</div>  </div></div>


<div  style="width:100%;height:auto;padding-top:50px;background:#CFCFCF">
      <div style="margin:auto;width:52%;padding-bottom: 10px">
          <span  style="color:#969696"><a href="{{url('/')}}">首页</a>->宅文->{{$data->title}}</span>
    </div>
     
    <div style="margin:auto;width:45%;background:#f6f3ec;padding:30px 70px">
        <div  style="padding-bottom:10px; border-bottom: 1px dotted #969696;">
            <h1  style="font-size:30px;margin-bottom: 10px">第{{$chapter}}章&nbsp;&nbsp;{{$chaptername}}</h1>
         
       
         </div>
          <hr>
       <p style="font-size:16px;padding-bottom: 300px">
           {{$txt}}
           
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什
           么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什
           么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
            什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什
           么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
            什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什
           么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
            什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什
           么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么 什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什
           么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
           什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么什么
          
 
       </p>  
       
        <hr>
    </div>
    
    
    
    
    
    <div style="padding-bottom: 100px">  <div class="book-read-page">
                            <a id="J_BtnPagePrev" class="btn-page" data-href="https://www.hbooker.com/chapter/book_chapter_detail/101523144/music" href="javascript:">上一章</a>                        <a class="btn-list" href="https://www.hbooker.com/chapter-list/100050129">目录</a>
                            <a id="J_BtnPageNext" class="btn-page" data-href="https://www.hbooker.com/chapter/book_chapter_detail/101523154/music" href="javascript:">下一章</a>                    </div></div>
</div>
    
    

      
     <script>
        
         function cang(id){
   if($("#denglu").val()==='meiyou'){
       
       var openUrl = "{{url('login')}}";//弹出窗口的url

 window.location.href=openUrl; 
  
    }

             if($("#hidden").is(":visible")){
                 $("#hidden").hide();
                 $("#show").show();
                $.post("{{url('user/favorate')}}",{'_token':'{{csrf_token()}}','id':id},function(data){
                 if(data){ 
                     
                   alert(data);
                   
                 }
    });
             }
             else{
                  $("#hidden").show();
                  $("#show").hide();
                  $.post("{{url('user/favorate')}}",{'_token':'{{csrf_token()}}','id':id},function(data){
                 if(data){
                     alert(data);
                 }
    });
             }
             
         }
         
         
function nav(obj){
    
   $(obj).siblings().children(":first").removeClass('selected');
   $(obj).children(":first").addClass('selected');
}
</script>
 
      
</body>
</html>