
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="332107236654575254534635167011671463757037317650747716" />
    <title>登录 - 欢乐书客</title>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <link rel="shortcut icon" type="image/x-icon" href=""/>
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">

    <link rel="stylesheet" type="text/css" href="{{asset('home/css/style.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/response.css')}}"/>
    <script type="text/javascript" language="javascript" src="{{asset('bootstrap/jquery.js')}}"></script>


</head>
<body>
<script type="text/javascript">
    function initResponse(){var d,b,a=window.innerWidth||document.documentElement.clientWidth,g=navigator.userAgent.toLowerCase(),h=/(msie) ([\w.]+)/,f=h.exec(g),c;if(f!==null&&f[1]==="msie"){c=f[2];if(c==="8.0"||c==="7.0"||c==="6.0"){a=a+21}}document.body.style.width="";var e=(document.body.className&&document.body.className.indexOf("sw-list-")!=-1);if(a>=1280||e){d=1}else{d=0}switch(d){case 1:b="s-layout-1190";break;case 0:b="s-layout-990";break;default:b="s-layout-990";break}document.body.className=b}initResponse();
</script>





<!--container start-->
<div class="container">
    <div class="ly-wrap">
        <div class="login-box">
            <form action="{{url('login')}}" class="form-box" method="post" name="J_LoginForm" id="J_LoginForm" >
                    {{csrf_field()}}
                <h3>登录</h3>
                <div class="form-group">
                    <input type="text" placeholder="手机号/用户名" class="username" name="tel" id ="username">
                </div>
                <div class="form-group">
                    <input type="password" placeholder="密码" class="password" name="password">
                </div>
                <div class="form-group code-group">
											<div id="embed-geetest-captcha"></div>
<!--						<p id="geetest-wait">正在加载验证码......</p>
						<p id="geetest-notice">请先拖动验证码到相应位置</p>-->
					
							
					                </div>
                <div class="form-btn">
                    <button id="geetest-submit" type="submit">登录</button>
                </div>
                <div class="form-ft clearfix">
                        <span class="tl">
                            <label><input checked="checked" value="1" type="checkbox">自动登录</label>
                        </span>
                        <span>
                            <a target="_self" href="{{url('register')}}">注册</a>
                        </span>
                        <span class="tr">
                            <a class="fpw" href="https://www.hbooker.com/signup/modify_passwd_page?redirect=https://www.hbooker.com/">忘记密码 ></a>
                        </span>
                </div>
            </form>
            <div class="login-ft">
                <div class="otherUser">
                    <div class="otherUser_T"><span></span><b></b></div>
                    <div class="otherUser_B">
                        <a href="https://www.hbooker.com/signup/qqlogin?redirect=https://www.hbooker.com/" class="qqLogin"></a>
						 <!--<a href="https://www.hbooker.com/signup/weixin_login" class="weixinLogin"></a>--> 
<!--                        <a href="javascript:;" class="qqLogin"></a>-->
                        <!-- <a href="javascript:;" class="wbLogin"></a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--container end-->

<script type="text/javascript" src='https://www.hbooker.com/resources/js/jquery-plugins/jquery.validate/jquery.validate.min.js'></script>
<script type="text/javascript" src='https://www.hbooker.com/resources/js/form.js'></script>
<script type="text/javascript">
    var errorStr = "";
    if(errorStr!="")
        HB.util.alert(errorStr);
</script>


<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
</body>
</html>