@extends('layout.ziyuan')
@section('content')   
<div class="container">
    <div class="ly-wrap">

      <div class="breakcrumb">
            <a href="{{url('/')}}">首页</a> &gt;
            <a href="{{url('forum')}}">论坛</a> &gt;
            发帖
        </div>

        <div class="bbs-publish">
			
			
			                <a href="{{url('item')}}?date={{$data->date}}&target=louzhu" class="btn-blue">只看楼主</a>
			            <a href="javascript:;" class="btn btn-blue" onclick="scrollEnd()">回复</a>
            <a href="{{'forum/create'}}" class="btn btn-blue">发帖</a>
            <a href="{{'forum'}}" class="back">返回论坛</a>
        </div>
<script>
    
    function reply(){
        $('#conment').show();
    }
      function quxiao(){
        $('#conment').hide();
    }
</script>



        <div class="bbs-detail ly-mt20" data-bbstype="1" id="bbs-detail">
            <div class="hd clearfix">
                <div class="bbs-detail-left">查看：<i>60</i> <span class="line">|</span> 回复：<i>15</i></div>
                <div class="J_BBSTitle bbs-detail-right">{{$data->title}}</div>
                             
                            </div>
            <div class="bd">
                <ul>
<!--                    楼主-->
                                        <li class="clearfix" id="bbs-host" data-bbs-id="475867" data-reader-id="464416">
                        <div class="bbs-detail-left post-starter">
                            <div class="img">
                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-03/464416/avatar/thumb_32b0f92caf7120ee899a195b88fcb0c8.jpg" src="http://www.hbooker.com/resources/images/avatar-default-f.png" />
                                <div class='medal medal_2_99'></div>                                <i class="icon-sex icon-female"></i>
                            </div>
                            <div class="userinfo">
																	<p class="name"><a href="http://www.hbooker.com/bookshelf/464416" target="_blank">{{$data->poster}}</a> <i class='icon-level-h'>• 初V</i></p>
									<p class="level">经验等级：LV.9世外高人</p>
								                            </div>
                            <div class="foll-box">
                                                                                                            <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="464416"><i>&plus;</i> 关注</a>
                                                                                                </div>
                            <div class="floor-num">
                               楼主
                            </div>
                        </div>
                        <div class="bbs-detail-right">
                            <div class="opt clearfix">
                                <div class="post-time ly-fl">
                                    发表时间：<span>{{date('Y-m-d h:i:s',$data->date)}}</span>
                                                                            <a href="http://www.hbooker.com/bbs/475867?see_lz=1">只看楼主</a>
                                                                    </div>
                            </div>
                            <div class="desc-box">
                                <div class="desc">{{$data->content}}<br></div>
                            </div>
                            <div class="bbs-comment J_bbsOpt">
                                <a href="javascript:void(0);" class="zan J_Zan ">
										<span>
											<b>赞</b>
											<br>
											<i>0</i>
										</span>
                                </a>
                                <a href="javascript:void(0);" class="hei J_Hei ">
										<span>
											<b>黑</b>
											<br>
											<i>0</i>
										</span>
                                </a>
                            </div>
                            <h6 class="latest-edit">该话题由 列宁 于2018-03-08 16:59:57最后编辑</h6>
																					<a href="javascript:;" class="bbs-reply" onclick="jump_comment_form()">回复</a>
                        </div>
                    </li>
                    <!--                    普通用户-->
         
                            @foreach($data1 as $k=>$v)
                                            <li class="clearfix J_BbsComment" data-bbs-id="475867" data-comment-id="4113374" data-reader-id="1795068">
                            <div class="bbs-detail-left">
                                <div class="img">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-02/1795068/avatar/thumb_19b6fa62a812703bd898c6638c98c1a5.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                        <i class="icon-sex icon-male"></i>
                                </div>
                                <div class="userinfo">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/1795068" target="_blank">{{$v->poster}}</a> <i class='icon-level-h'>• 高V</i></p>
                                    <p class="level">经验等级：LV.8无双隐士</p>
<!--                                    <p class="name"><a href="#">CC</a> <i class="icon-level-e">• 初V</i></p>-->
<!--                                    <p class="level">经验等级：LV.3读书御宅</p>-->
                                </div>
                                <div class="foll-box">
                                                                                                                        <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="1795068"><i>&plus;</i> 关注</a>
                                                                            <!--                                    <a href="javascript:;" class="foll J_Follow"><i>+</i> 关注</a>-->
                                </div>
                                <div class="floor-num">
                                    {{$k+1}}F
                                </div>
                            </div>
                            <div class="bbs-detail-right">
                                <div class="opt clearfix">
                                    <div class="post-time ly-fl">
            发表时间：<span>{{date('Y-m-d h:i:s',$v->date)}}</span>
                                    </div>
                                    <div class="ly-fr J_bbsCommentOpt comment-opt">
                                        <a href="javascript:;" class="J_Zan zan ">赞(<i>0</i>)</a>
                                        <a href="javascript:;" class="J_Hei hei ">黑(<i>0</i>)</a>
                                    </div>
                                </div>
                                <div class="J_DescBox desc-box">
                                    <div class="J_Desc desc">{{$v->content}}</div>
                                    <div class="comment-list" id="commentid_4113374">

                                <ul class="J_CommentList">
                                    
                                @if(isset($v->pinglun))
                                    @foreach($v->pinglun as $k=>$value)
                                    <li class="clearfix J_ReviewComment " data-comment-id="4113386" data-reply-id="744593" data-reader-id="182447" data-reader-name="̑̑盖亚">
                                                            <div class="img ly-fl">
                                                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-03/182447/avatar/thumb_26466c59b0e9f3eb44a71863f0ad3322.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                <div class='medal medal_26_40'></div>                                                            </div>
                                                            <div class="ly-fl box-bd">
                                                                <div class="clearfix">
                                                                    <div class="ly-fl">
                                                                        <p class="name"><a href="http://www.hbooker.com/bookshelf/182447" target="_blank">{{$value->answer}}</a> <i class='icon-level-h'>• 高V</i></p>
                                                                    </div>
                                                                    <div class="ly-fr">
                                                                        <div class="time">2018-03-08 16:51:37</div>
                                                                    </div>
                                                                </div>
                                                                <div class="desc-content">
                                                                    <b>  @ </b><b>{{$value->poster}}：</b>
                                                                                                                                        {{$value->content}}                                                             </div>
                                                                <div style="margin:0;" class="clearfix state J_State">
                                                                    <div class="ly-fr J_bbsCommentOpt">
																		                                                                                                                                                <a href="javascript:;" class="J_FormAddReviewComment reply">回复 </a>
                                                                    </div>
                                                                </div>
                                            <hr>
                                                            </div>

                                                        </li>


                                                   @endforeach 
@endif
      <!--上面显示-->   
      
          <form id="bbs_add_form"  action ="{{url('answer')}}"  method="post">
                         {{csrf_field()}}
        <li  style="display: none"  id="conment">
                 <hr>                                     
         <div class="layui-form-item">
  
             <div class="layui-input-block"  style="margin: 0px;">
                 <input type="hidden" id="bbs_id" value="{{$data->date}}"  name="date">
                 <input  type="hidden" name="a_id" value="{{$v->id}}">
                 <input  type="hidden" name="poster" value="{{$v->poster}}">
                 <input type="text" name="content" lay-verify="title" autocomplete="off" placeholder="请输入评论" class="layui-input"  style="height: ">
    </div>
  </div>                                            
                          
            
                 <button  type="submit" class="layui-btn layui-btn-primary">确定</button>
                 <input  type="button"  onclick="quxiao()"  value="取消">
          <hr>
                                                              
                                                           
    </li>
          </form>                             </ul>
                                        <!--<ul class="J_CommentList"></ul>  这是显示全部-->
                                        
                                        
                                                                        </div>
                                </div>
				  <a href="javascript:;" onclick="reply()" class="J_FormReply bbs-reply">回复</a>
                            </div>
                        </li>
                                @endforeach            
                                       
                                            
                                            
                                           
                                            <li class="clearfix J_BbsComment" data-bbs-id="475867" data-comment-id="4113386" data-reader-id="323531">
                            <div class="bbs-detail-left">
                                <div class="img">
                                    <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-02/323531/avatar/thumb_9a5aa3a50bf1a7f8910c069fb6b6ebe8.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                    <div class='medal medal_26_99'></div>                                    <i class="icon-sex icon-male"></i>
                                </div>
                                <div class="userinfo">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/323531" target="_blank">路人一只</a> <i class='icon-level-h'>• 钻V</i></p>
                                    <p class="level">经验等级：LV.12笑傲江湖</p>
<!--                                    <p class="name"><a href="#">CC</a> <i class="icon-level-e">• 初V</i></p>-->
<!--                                    <p class="level">经验等级：LV.3读书御宅</p>-->
                                </div>
                                <div class="foll-box">
                                                                                                                        <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="323531"><i>&plus;</i> 关注</a>
                                                                            <!--                                    <a href="javascript:;" class="foll J_Follow"><i>+</i> 关注</a>-->
                                </div>
                                <div class="floor-num">
                                    7F
                                </div>
                            </div>
                            <div class="bbs-detail-right">
                                <div class="opt clearfix">
                                    <div class="post-time ly-fl">
                                        发表时间：<span>2018-03-08 16:48:46</span>
                                    </div>
                                    <div class="ly-fr J_bbsCommentOpt comment-opt">
                                        <a href="javascript:;" class="J_Zan zan ">赞(<i>0</i>)</a>
                                        <a href="javascript:;" class="J_Hei hei ">黑(<i>0</i>)</a>
                                    </div>
                                </div>
                                <div class="J_DescBox desc-box">
                                    <div class="J_Desc desc">摸摸列酱🍵</div>
                                    <div class="comment-list" id="commentid_4113386">
                                                                        <ul class="J_CommentList">
                                        <li class="clearfix J_Review" data-comment-id="4113386">
                                            <div class="comment-list-in ly-mt10">
                                                <ul>
                                                                                                            <li class="clearfix J_ReviewComment " data-comment-id="4113386" data-reply-id="744598" data-reader-id="323531" data-reader-name="路人一只">
                                                            <div class="img ly-fl">
                                                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-02/323531/avatar/thumb_9a5aa3a50bf1a7f8910c069fb6b6ebe8.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                <div class='medal medal_26_40'></div>                                                            </div>
                                                            <div class="ly-fl box-bd">
                                                                <div class="clearfix">
                                                                    <div class="ly-fl">
                                                                        <p class="name"><a href="http://www.hbooker.com/bookshelf/323531" target="_blank">路人一只</a> <i class='icon-level-h'>• 钻V</i></p>
                                                                    </div>
                                                                    <div class="ly-fr">
                                                                        <div class="time">2018-03-08 16:56:43</div>
                                                                    </div>
                                                                </div>
                                                                <div class="desc-content">
                                                                                                                                        <b>@̑̑盖亚：</b>
                                                                                                                                        决定了，以后你既是萌物又是电池（拿出吸能机器）                                                                </div>
                                                                <div style="margin:0;" class="clearfix state J_State">
                                                                    <div class="ly-fr J_bbsCommentOpt">
																		                                                                                                                                                <a href="javascript:;" class="J_FormAddReviewComment reply">回复 </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                                                                            <li class="clearfix J_ReviewComment " data-comment-id="4113386" data-reply-id="744593" data-reader-id="182447" data-reader-name="̑̑盖亚">
                                                            <div class="img ly-fl">
                                                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-03/182447/avatar/thumb_26466c59b0e9f3eb44a71863f0ad3322.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                <div class='medal medal_26_40'></div>                                                            </div>
                                                            <div class="ly-fl box-bd">
                                                                <div class="clearfix">
                                                                    <div class="ly-fl">
                                                                        <p class="name"><a href="http://www.hbooker.com/bookshelf/182447" target="_blank">̑̑盖亚</a> <i class='icon-level-h'>• 高V</i></p>
                                                                    </div>
                                                                    <div class="ly-fr">
                                                                        <div class="time">2018-03-08 16:51:37</div>
                                                                    </div>
                                                                </div>
                                                                <div class="desc-content">
                                                                                                                                        <b>@路人一只：</b>
                                                                                                                                        mmp，启动地球大炮                                                                </div>
                                                                <div style="margin:0;" class="clearfix state J_State">
                                                                    <div class="ly-fr J_bbsCommentOpt">
																		                                                                                                                                                <a href="javascript:;" class="J_FormAddReviewComment reply">回复 </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                                                                            <li class="clearfix J_ReviewComment " data-comment-id="4113386" data-reply-id="744592" data-reader-id="323531" data-reader-name="路人一只">
                                                            <div class="img ly-fl">
                                                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-02/323531/avatar/thumb_9a5aa3a50bf1a7f8910c069fb6b6ebe8.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                <div class='medal medal_26_40'></div>                                                            </div>
                                                            <div class="ly-fl box-bd">
                                                                <div class="clearfix">
                                                                    <div class="ly-fl">
                                                                        <p class="name"><a href="http://www.hbooker.com/bookshelf/323531" target="_blank">路人一只</a> <i class='icon-level-h'>• 钻V</i></p>
                                                                    </div>
                                                                    <div class="ly-fr">
                                                                        <div class="time">2018-03-08 16:51:14</div>
                                                                    </div>
                                                                </div>
                                                                <div class="desc-content">
                                                                                                                                        <b>@̑̑盖亚：</b>
                                                                                                                                        抱走顺毛_(•̀ω•́ 」∠)_                                                                </div>
                                                                <div style="margin:0;" class="clearfix state J_State">
                                                                    <div class="ly-fr J_bbsCommentOpt">
																		                                                                                                                                                <a href="javascript:;" class="J_FormAddReviewComment reply">回复 </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                                                                            <li class="clearfix J_ReviewComment J_ReplyHide reply-hide" data-comment-id="4113386" data-reply-id="744589" data-reader-id="182447" data-reader-name="̑̑盖亚">
                                                            <div class="img ly-fl">
                                                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-03/182447/avatar/thumb_26466c59b0e9f3eb44a71863f0ad3322.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                <div class='medal medal_26_40'></div>                                                            </div>
                                                            <div class="ly-fl box-bd">
                                                                <div class="clearfix">
                                                                    <div class="ly-fl">
                                                                        <p class="name"><a href="http://www.hbooker.com/bookshelf/182447" target="_blank">̑̑盖亚</a> <i class='icon-level-h'>• 高V</i></p>
                                                                    </div>
                                                                    <div class="ly-fr">
                                                                        <div class="time">2018-03-08 16:49:21</div>
                                                                    </div>
                                                                </div>
                                                                <div class="desc-content">
                                                                                                                                        <b>@路人一只：</b>
                                                                                                                                        递茶                                                                </div>
                                                                <div style="margin:0;" class="clearfix state J_State">
                                                                    <div class="ly-fr J_bbsCommentOpt">
																		                                                                                                                                                <a href="javascript:;" class="J_FormAddReviewComment reply">回复 </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                                                                            <li class="clearfix J_ReviewComment J_ReplyHide reply-hide" data-comment-id="4113386" data-reply-id="744590" data-reader-id="182447" data-reader-name="̑̑盖亚">
                                                            <div class="img ly-fl">
                                                                <img alt="" class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2018-03/182447/avatar/thumb_26466c59b0e9f3eb44a71863f0ad3322.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                                                <div class='medal medal_26_40'></div>                                                            </div>
                                                            <div class="ly-fl box-bd">
                                                                <div class="clearfix">
                                                                    <div class="ly-fl">
                                                                        <p class="name"><a href="http://www.hbooker.com/bookshelf/182447" target="_blank">̑̑盖亚</a> <i class='icon-level-h'>• 高V</i></p>
                                                                    </div>
                                                                    <div class="ly-fr">
                                                                        <div class="time">2018-03-08 16:49:21</div>
                                                                    </div>
                                                                </div>
                                                                <div class="desc-content">
                                                                                                                                        <b>@路人一只：</b>
                                                                                                                                        递茶                                                                </div>
                                                                <div style="margin:0;" class="clearfix state J_State">
                                                                    <div class="ly-fr J_bbsCommentOpt">
																		                                                                                                                                                <a href="javascript:;" class="J_FormAddReviewComment reply">回复 </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                                                                    </ul>
                                                                                                <div class="reviewAllComment">
                                                    <a href="javascript:;" class="J_ReviewAllComment" data-count="10">点击展开全部回复</a>
                                                </div>
                                                                                                                                            </div>
                                        </li>
                                    </ul>
                                                                    </div>
                                </div>
								                                                                <a href="javascript:;" class="J_FormReply bbs-reply">回复</a>
                            </div>
                        </li>
                                           
                                           
                                    </ul>
            </div>
        </div>

        <div class="pagination" style="margin-right:0">
            <div class="PageIn">
                <ul>
                    <li class='selected'><a href='javascript:'>1</a></li><li><a href="javascript:change_comment_page(2)" data-ci-pagination-page="2">2</a></li><li><a href="javascript:change_comment_page(2)" data-ci-pagination-page="2" rel="next">>></a></li>                    <li class="pageSkip">
                        <span class="ly-fl">跳转到:</span>
                        <input type="text" id="directPageNum" name="directPageNum" class="ly-fl skipBox" value="1"/>
                        <span class="ly-fl">/<i>2</i>页</span>
                        <a class="ly-fl pageSkipQd" href="javascript:void(0);">确认</a>
                    </li>
                </ul>
                <input type="hidden" value="1" name="curr_page" id="curr_page">
                <input type="hidden" value="change_comment_page(1)" name="curr_url" id="curr_url">
            </div>
        </div>
        <form action="{{url('forum')}}" method="post">
            {{csrf_field()}}
        <div class="bbs-form ly-mt60">
            <div class="titl">发表回复</div>
            <div>
                <input type="hidden" id="bbs_id" value="{{$data->id}}"  name="p_id">
                <div class="form-group" style="margin-top:5px">
                    <textarea name="content" id="editor" cols="30" rows="10" style="height: 120px;" placeholder="发表帖子，注意文明用语哦\^o^/"></textarea>
                    <div id="editor_content" style="display: none;"></div>
                </div>
                <div class="form-group action" style="text-align: right">
                    <span class="J_TopicWordsCount">0</span>/<span class="J_TopicWordsCountLimit">500</span>
                    <button type=submit id="add_coment_submit" type="button" class="ly-ml10">发表</button>
                </div>
            </div>
        </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
@endsection