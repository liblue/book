
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="2554576230602773526375" />
    <meta name="baidu-site-verification" content="81BLZ1C2Te" />
    <!-- 百度验证  -->
    <meta name="baidu-site-verification" content="23p76Y9LU3" />
    <!--360验证-->
    <meta name="360-site-verification" content="1247af3cd890cf522c64a0188211dfba" />
    <!--神马平台验证-->
    <meta name="shenma-site-verification" content="6ddf919e460df88fe12310e2097a23cc_1497866600" />
    <title>阅读社区_贼新贼全的综漫小说阅读网，火影小说，海贼小说，动漫小说，动漫同人</title>
    <meta name="keywords" content="综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <meta name="description" content="欢乐书客提供最新好看的全本二次元穿越，娘化百合，各种萌化后宫小说在线阅读，综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/style.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset('home/css/response.css')}}"/>
       <link rel="stylesheet" type="text/css" href="{{asset('home/css/home.css')}}"/>
              <link rel="stylesheet" href="{{asset('admin/lib/layui/css/layui.css')}}">

         <script src="{{asset('admin/lib/layui/layui.js')}}" charset="utf-8"></script>
    <script type="text/javascript" language="javascript" src="{{asset('bootstrap/jquery.js')}}"></script>
        <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
        HB.book = {book_id: "", chapter_id: "", up_reader_id: "", is_paid: 0};
        HB.userinfo = {reader_id: 0,tel_num: '',license: '',redis_license: '', reader_name: '""', avatar_thumb_url: '""', vip_lv: ""};
        HB.urlinfo ={redirect:'https://www.hbooker.com/reader/modify_mobile?redirect=https%3A%2F%2Fwww.hbooker.com%2F'};        
    </script>
    <script type="text/javascript" src="{{asset('home/js/initResponse.js')}}"></script>
    <script type="text/javascript" src="{{asset('home/js/base.js')}}"></script>
    <!--<script type="text/javascript" src="{{asset('home/js/dialog-min.js')}}"></script>-->

    
</head>
<body>
    <!--360自动收录JS代码-->

 <!-- 当前是章节阅读页 -->
 <!-- 当前是漫画阅读页 -->
<div id="bdstat" style="display: none"></div>

<div class="nav-top">
    <div class="ly-wrap">
        <ul class="login-info ly-fl">
                           <!--  <li><a class="wb" href="#" rel="nofollow"></a></li> -->
<!--                <li><a class="qq" href="#" rel="nofollow"></a></li>-->
                <li><a class="qq" href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow"></a></li>
				<!--<li><a class="weixin" href="https://www.hbooker.com/signup/weixin_login" rel="nofollow"></a></li> -->
              
                 <li><a href="{{url('/')}}" rel="nofollow">返回首页</a></li>
                    </ul>
         
     
         
    </div>
</div>

<!--  欢迎每日登录 领取推荐票 -->
<div class="dialogLoginBox" id="J_DialogLoginBox" style="display: none;">
    <h3 class="title">欢迎每日登录</h3>
    <div class="cnt">
        <p>  你好~~</p>
        <p>送你 <span>
			0		</span> 张推荐票哦~</p>
        <p class="tips">登陆欢乐书客APP，<br/>完成每日签到任务，更有欢乐币相送。</p>
        <p>么么哒~~</p>
    </div>
    <div class="opt">
        <!--        <a class="btn-gettuijian" href="javascript:;" id="J_GetTJTicket">领取推荐票</a>-->
        <p class="auto-close"><i id="J_Timer">3</i>s后关闭</p>
    </div>
</div>

<div class="header">
    <div class="ly-wrap header-inner">
        <div class="ly-fl">
            <div class="logo">
                <h1><a href="https://www.hbooker.com/index"><img src="https://www.hbooker.com/resources/images/logo.png" alt="logo"></a></h1>
                <div>让阅读更精彩，让写作更简单 \^o^/</div>
            </div>
        </div>
    </div>


    </div><!--container start-->
    
    
        <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
                
                @yield('nav')
            
               
                
            
            </ul>
          
        </div>
        <b></b>
    </div>
  
    
      @yield('content')
    
    
       
    
    





<div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="https://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
<!--             <li>
                <dl>
                    <dt>安全认证</dt>
                    <dd><a logo_size="83x30" logo_type="realname" href="http://www.anquan.org" ><script src="http://static.anquan.org/static/outer/js/aq_auth.js"></script></a></dd>
                </dl>
            </li> -->
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>


</body>
</html>