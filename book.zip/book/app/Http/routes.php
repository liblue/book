<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['middleware' => ['web']], function () {
    
 Route::any('login','Home\LoginController@login');
 Route::get('logout','Home\LoginController@logout');
 Route::get('register', function () { return view('home/register');});
 Route::get('/','Home\IndexController@index' );
 Route::get('list/{catename}','home\IndexController@in_list' );
 Route::get('chapter','home\IndexController@chapter' );
 Route::get('content','home\IndexController@in_content' );
 Route::get('search/{catename?}','home\IndexController@search' );
 Route::any('loginkuang', function () {
    return view('home/loginkuang');   
}); 

 Route::any('user/post','Home\PosterController@userpost');
 Route::any('user/postdelete','Home\PosterController@postdelete');
 Route::any('answer','Home\PosterController@answer');
 Route::any('item','Home\PosterController@item');
// Route::any('louzhu/{date}','Home\PosterController@louzhu');
 Route::resource('forum','Home\PosterController');

 });
 
 
 
 
 
 Route::group(['middleware' => ['web']], function () {
     
 Route::post('author/shangchuan','Home\NovelController@shangchuan');    
 Route::post('author/putcon','Home\NovelController@putcon');  
 Route::get('author/write/{id}','Home\NovelController@write'); 
 Route::get('author/info/{date}','Home\NovelController@info'); 
 Route::any('author/delete','Home\NovelController@delete');
 Route::any('comment','Home\NovelController@comment');   
 Route::any('author/change','Home\NovelController@change'); 
 Route::get('author/setshow/{date}','Home\NovelController@setshow'); 
 Route::post('author/set','Home\NovelController@set'); 
 Route::resource('author','Home\NovelController');
  Route::get('au_purse', function () {
    return view('home/author/purse');   
});
 Route::get('au_info', function () {
    return view('home/author/info');   
}); 

 Route::any('user/showmodify','Home\UserController@showmodify'); 
 Route::get('user/showinfo','Home\UserController@showinfo'); 
 Route::post('user/favorate','Home\UserController@favorate'); 
 Route::resource('user','Home\UserController');
 
 });








Route::group(['middleware' => ['web']], function () {
    
     Route::get('success','Admin\IndexController@success');
    Route::any('admin_login','Admin\LoginController@login');
  Route::get('welcome', function () {
    return view('admin/welcome');   
}); 
    
 });

 
 
 
Route::group(['middleware' => ['web',]], function () {
    Route::get('houtai','Admin\IndexController@index');
    Route::get('admin/admin_list','Admin\IndexController@admin_list');
    Route::get('admin/admin_add','Admin\IndexController@admin_add');
    Route::get('admin/admin_edit','Admin\IndexController@admin_edit');
    Route::get('admin/user_info','Admin\UserController@info');
    Route::post('admin/user/delete','Admin\UserController@delete');
    Route::resource('admin/user','Admin\UserController');
    Route::get('admin/cate','Admin\NovelController@cate');
    Route::any('admin/novel/delete','Admin\NovelController@delete');
    Route::any('admin/novel/search','Admin\NovelController@search');
    Route::resource('admin/novel','Admin\NovelController');
    Route::any('admin/autobook/search','Admin\AutobookController@search');
    Route::resource('admin/autobook','Admin\AutobookController');
    
});
