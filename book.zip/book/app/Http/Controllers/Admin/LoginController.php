<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Support\Facades\Input;
use App\Model\Admin;
class LoginController extends Controller
{
    //
    public function index(){
     
        
        
          return view('admin/admin_login');   
        
        
    }
    
    public function login(){
//    $this->middleware('auth');
        
         if(  $input = Input::all()){
          
          $user = Admin::first();
          if($user->name!= $input['username'] ){
             if($user->name != $input['username']){
                 return back()->with('msg','查无此人'); 
             }
                  if(($user->password)!= $input['password']){
                return back()->with('msg','用户名或者密码错误！');
            }
            session(['user'=>$user]);
             
         }
        
        
       return redirect('houtai');
         
        
    }
     return view('admin/admin_login');   
    
}}
