<?php

namespace App\Http\Controllers\Home;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Model\User;
class LoginController extends Controller
{
    //
    public function login(){
        
       if(  $input = Input::except('_token')){
//          $input['password'] = Hash::make($input['password']);
//          dd($input['password']);
         //判断是否数字开头 
           
           $url=$input['url'];
         if( !preg_match('/^\d+$/i', $input['tel'])){
             
           $user=User::where('nickname', $input['tel'])->first();
         }else{
         $user=User::where('tel', $input['tel'])->first();
         }
//         dd($user->nickname);
         if(!Hash::check($input['password'],$user->password)){

           session(['user'=>$user]);
           session(['user_name'=>$user->name]);
           session(['user_nickname'=>$user->nickname]);
           session(['user_favorates'=>$user->favorates]);
           session()->save();
//         
           
           
         return redirect($url);
       }
         else  {
         return redirect()->back();
         
       }
       
         }else{
             $url=url()->previous();
           
           return view("home/login")->with('url',$url);
           
       }
        }
    public function logout(){

    $url=url()->previous();
       session(['user'=>null]);
       session(['user_name'=>null]);
       session(['user_favorates'=>null]);
       session(['user_nickname'=>null]);
        return redirect($url);
 
        
    }
}
