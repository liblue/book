<?php

namespace App\Http\Controllers\Home;

use App\Model\Comment;
use App\Model\Novel;
use Illuminate\Http\Request;
use App\Model\Cate;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Model\User;

class IndexController extends Controller
{
    //
    
    
    public function index( ){
        $data=Novel::where('cate','玄幻')->limit(12)->get();

             $cate=Cate::all();
             $cate_name='shouye';
//        view()->share('cate', '$cate');
    return view('home.index')->with('cate_name',$cate_name)->with('cate', $cate)->with('data',$data);
    
    
    
    }
      public function in_list(Request $request){
             $data=Novel::where('cate','玄幻')->paginate(40);
             foreach($data as $k=>$v){
             $chapternum[]= count(explode('@', $v->chapter))-1;     
             }
             
             
             $cate=Cate::all();
//        view()->share('cate', '$cate');
           return view('home.list')->with('cate_name','shouye')->with('cate', $cate)->with('data',$data)->with('chapternum',$chapternum);
    }
    
      public function in_content(Request $request){
          $id=$request->get('id');
         $data=Novel::find($id);
      $comment=Comment::where('book_id',$id)->orderBy('date', 'desc')->paginate(10);
      $data->chapter= explode('@', $data->chapter);
      $data->chapter= array_filter( $data->chapter);
     
                   $cate=Cate::all();
             $cate_name='shouye';
//        view()->share('cate', '$cate');
       $name=session('user_name');      
       $user=User::where('name',$name)->first(); 
       $array= explode("@",$user->favorate );     
       if(in_array($id, $array)){
           
           $shoucang='yishoucang';
       } else {
            $shoucang='weicang';
       }
           
             
    return view('home.content')->with('cate_name',$cate_name)->with('cate', $cate)->with('data',$data)->with('comment',$comment)->with('shoucang',$shoucang); 
        
        
    }
      public function search(Request $request){
          
                   $cate=Cate::all();
             $cate_name='shouye';
//        view()->share('cate', '$cate');
    return view('home.search')->with('cate_name',$cate_name)->with('cate', $cate);      
    }
    public function chapter(Request $request){
        
 
        
        $id=$request->get('id');
        $chapter=$request->get('chapter');
        $data=Novel::find($id);
        
        
        $chaptername= explode("@", $data->chapter)[$chapter];
   
         $date=$data->date;
            $path="novel/".$date.'/'.$chapter.'.txt';
         if(file_exists($path)){
      
         $txt= file_get_contents($path);
         }
          else{
        
          $txt="无";
        }
         
//        view()->share('cate', '$cate');
    return view('home.chapter')->with('txt',$txt)->with('chapter',$chapter)->with('data',$data)->with('chaptername',$chaptername);     
    }
    
    
}
