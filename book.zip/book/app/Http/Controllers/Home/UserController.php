<?php

namespace App\Http\Controllers\Home;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use App\Model\User;
use Illuminate\Support\Facades\Hash;
use DateTime;
use Illuminate\Support\Facades\Validator;
use App\Model\Poster;
use Illuminate\Support\Facades\DB;
use App\Model\Novel;

//use Faker\Provider\cs_CZ\DateTimel;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $name=session('user_name');      
         $user=User::where('name',$name)->first();
         $array= explode("@",$user->favorate );
         $data=Novel::find($array);
         
         
        
       
       return view('home/myself/index')->with('data',$data);   
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        
    
         $input = Input::except('_token');
          $date=time();
       
  
          $input['name']='用户'.$date;
//         dd($input);
           $input['password'] = bcrypt($input['password']);
             $input['nickname']=$input['name'];
             $input['date']=time();
         User::create($input);
         $user=User::where('name', $input['name'])->first();
        
         

         
         
         
         
         
           session(['user'=>$user]);
           session(['user_name'=>$user->name]);
           session(['user_nickname'=>$user->name]);
           session(['user_favorate'=>$user->favorate]);
           session()->save();
           
           
           
           
           
           return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showmodify()
    {
        //
  
        $name=session('user_name');

        $user=User::where('name',$name)->first();

        return view('home/myself/modify',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        //
      $input= Input::except('_token');
       unset($input['_method']);
       unset($input['password']);   
       unset($input['or_password']); 
       
              if($input['nickname']==""){
                  //如果传入的
                  $input['nickname']=session('user_nickname');
              }
//      
//      $rules = [
//            'art_title'=>'required',
//
//        ];
//
//        $message = [
//            'art_title.required'=>'文章名称不能为空！',
//
//        ];
//
//     $validator = Validator::make($input,$rules,$message);
     $name=session('user_name');
     $comname=session('user_nickname');
     $user=User::where('name',$name);//好奇怪呀  为什么不加->first
//   dd($user);
     $user->update($input);
     $nickname=$input['nickname'];
     
     
     
     
     $sql1="UPDATE comments SET commenter =  '$nickname' WHERE commenter = '$comname'";
      DB::update(DB::raw( $sql1));
      $sql2="UPDATE posters SET poster =  '$nickname' WHERE commenter = '$comname'";
      DB::update(DB::raw( $sql2));
       $sql3="UPDATE answers SET poster =  '$nickname'  WHERE commenter = '$comname'";
      DB::update(DB::raw( $sql3));
      
      
     
//     $poster=Poster::where('poster',$name);
//     $poster->poster=$input['nickname'];
//           $poster->update($poster);
//     $novel=Novel::where('author',$name);   
     
   
     
              session(['user_nickname'=>$input['nickname']]);
           

return  redirect('user/showinfo');
        
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
    public function  showinfo()
                {
     
         $name=session('user_name');

  $user=User::where('name',$name)->first();

        return view('home/myself/info',compact('user'));
        
    }
    
    public function favorate(){
        
         $input = Input::except('_token');
         $id =  $input['id'];
         $name=session('user_name');      
         $user=User::where('name',$name)->first();
         
         $array= explode("@",$user->favorate );
          
       
       
         if(in_array($id, $array)){
            
            foreach ($array as $key=>$value){
                
                if($id==$value){
                   
                    unset($array[$key]);
                }
            }
            
           
         }else{
   
            $array[]=$id; 
             
         }
      
         $user->favorate= implode('@',$array);
       
         $user->save();
       
         $data=$id;
         return $data;


  
        
    }

  
}
