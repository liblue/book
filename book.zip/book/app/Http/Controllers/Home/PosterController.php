<?php

namespace App\Http\Controllers\Home;

use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\Model\Cate;
use App\Model\Poster;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Model\Answer;
use Illuminate\Support\Facades\DB;

class PosterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function __construct() {
           
    }
    public function index()
    {
        //
             
        
        
        $data=Poster::where('p_id',0)->paginate(40);
     
        return view('home.forum.index')->with('data',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        
       if( session('user')){
       return view('home.forum.fatie');}
       else 
    return  redirect ('login');
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        
          if( session('user')){
        
        $data= Input::except('_token');
    
        $data['poster']=session('user_nickname');
        $data['date']=time();
        
        unset($data['id']);
        Poster::create($data);
        
        if(isset($data['p_id'])){
        $data['date']=Poster::find($data['p_id'])->date;
        }
       return redirect()->action('Home\PosterController@item',['date'=> $data['date']]);
          }else {
              
              return redirect('login');
          }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
      public function item(Request $request)
    {
        //
         
          
          $date=$request->get('date');
        
           $data=Poster::where('date',$date)->first();
           $id=$data->id;
           $poster=$data->poster;
            
            if($request->get('target')){
              $data1=Poster::where('p_id',$id)->where('poster',$poster)->get();
      
         return view('home.forum.item')->with('data',$data)->with('data1',$data1);      
            }
           $data1=Poster::where('p_id',$id)->get();
         $count=count($data1);
        
         for($i=0;$i<$count;$i++){
            $res=Answer::where('a_id',$data1[$i]['id'])->get();
            
             $data1[$i]['pinglun']=$res;
         }
      
          return view('home.forum.item')->with('data',$data)->with('data1',$data1);
    }
    
//    public function louzhu(Request $request,$date){
//         $data=Poster::where('date',$date)->first();
//     
//          $poster=$data->poster;
//           $id=$data->id;
//
//       $data1=Poster::where('p_id',$id)->where('poster',$poster)->get();
//      
//         return view('home.forum.item')->with('data',$data)->with('data1',$data1);
//        
//    }
    
    public function answer(Request $request)
    {
        
         if(session('user')){
        $input= Input::except('_token');
        $input['answer']=session('user_nickname');
        $date=$input['date'];
        $input['date']=time();
        Answer::create($input);
        
        
        return redirect()->action('Home\PosterController@item',['date'=> $date]);
    }else{
        return redirect('login');
        
    }
    
    }
    
     //我的信息里的  我发布的帖子
    public function userpost(Request $request){
         if(session('user')){
             $username=session('user_nickname');
             
             $data=Poster::where('p_id',0)->where('poster',$username)->get();

    
        return view('home.myself.post')->with('data',$data); 
         }else{
             
         return  redirect('login');   
         }
    }
     //我的信息里的帖子删除
    public function postdelete(){
          $input = Input::except('_token');

        $re = Poster::where('id',$input['id'])->delete();//删除选中id
         Poster::where('p_id',$input['id'])->delete();//删除以选中id为p_id的回复贴
       if($re){
        $data = [
                'status' => 0,
                'msg' => '文章删除成功！',
            ];
     
         return $data;
             }
      }
      //我的信息里的帖子查看
     
      
      
}
