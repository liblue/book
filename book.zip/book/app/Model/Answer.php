<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    //
    
      
   protected $table="answers";
    protected $primaryKey='id';
    public $timestamps=false;
     protected $guarded=[];
}
