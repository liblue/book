<?php $__env->startSection('nav'); ?>
   <li><a href="<?php echo e(url('myself')); ?>" >我的信息</a></li>
               
                <li><a href="/" class='selected' >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="<?php echo e(url('author')); ?>" class="selected">我的作品</a></li>
                    <li><a href="<?php echo e(url('au_add')); ?>" >新建作品</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="<?php echo e(url('au_purse')); ?>">我的收入</a></li>
                    <li><a href="https://www.hbooker.com/reader/my_info">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
        
        <div class="ly-fl bookshelf" style="width: 80%">
     
          

                
                <table class="layui-table">
  <colgroup>
    <col width="150">
    <col width="200">
    <col>
  </colgroup>
  <thead>
    <tr>
        <th><input type="checkbox" class="selectAll" id="selectAll" name="choice"></th>
      <th>书名</th>
      <th>创作时间</th>
      <th>签名</th>
       <th>状态</th>
      <th>管理</th>
     
    </tr> 
  </thead>
  <tbody>
    <tr>
        <td  align="left"> <input type="checkbox" class="subSelect" name="choice" ></td>
      <td>贤心</td>
      <td>2016-11-29</td>
     
     <td>于千万人之中遇见你</td>
      <td>连载中</td>
      <td> <a  href="<?php echo e(url('au_info')); ?>"> <button class="layui-btn layui-btn-primary">设置</button></a>
          <button class="layui-btn layui-btn-primary">详情</button> 
          <a href='<?php echo e(url('au_write')); ?>'><button class="layui-btn layui-btn-primary">添加章节</button></td>
    </tr>

   
  </tbody>
</table>
             
           
        </div>

        <!--我的关注,我的粉丝 start-->
        <div class="ly-side" style="display: none">
            <div class="mod-box fans">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的关注</span></h3>
                </div>
            </div>

            <div class="mod-box fans ly-mt45">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的粉丝</span></h3>
                </div>
            </div>
        </div>
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>