    

<?php $__env->startSection('nav'); ?>
                <li><a href="<?php echo e(url('/')); ?>" class='selected'>首页</a></li>
                <li><a href="paihang" >排行</a></li>
                <li><a href="https://www.hbooker.com/index-zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index-tongren" >同人</a></li>
                <!--<li><a href="https://www.hbooker.com/index/header_cate_list/male" >男生</a></li>-->
                <li><a href="https://www.hbooker.com/index-female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index-comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index-game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs" >社区</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>   
 <div class="book-read"></div>
<div class="container">
    <div class="ly-wrap">

        <div class="breakcrumb">
            <a href="https://www.hbooker.com/index">首页</a>
            >
            <a href='https://www.hbooker.com/index/header_cate_list/zhaiwen'>宅文</a> > <a href='https://www.hbooker.com/index/cate_book_list/zhaiwen/6'>未来幻想</a> >             苍蓝的战舰少女之现代战争        </div>

        <!--书页 start-->
        <div class="book-detail ly-mt45">

            <!-- ly-main -->
            <div class="ly-main">
                <div class="book-hd clearfix">
                    <div class="ly-fl book-img">
                        <div class="book-cover">
                            <img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17173015-10830-100029012.jpg" alt="苍蓝的战舰少女之现代战争">
                        		
                        </div>
                        <ul class="book-operating">
                            <li><a class="read" href="https://www.hbooker.com/chapter-list/100029012/book_detail">点击阅读</a></li>
                            <li> <a class='J_ShouCang' href="javascript:">收藏</a> </li>
                            <li><a href="javascript:" class="J_TuiJian">投推荐票</a></li>
                            <li><a href="javascript:" id="J_YuePiao">投月票</a></li>
                            <li><a href='javascript:'>免费书籍</a>                            </li>
                        </ul>
                    </div>
                    <div class="ly-fl book-info">
                        <div class="book-title">
                            <h1>苍蓝的战舰少女之现代战争</h1>
                            <p><span>小说作者：</span><a href="https://www.hbooker.com/reader/129657" target="_blank" class="">zyts新折翼</a></p>
                        </div>
                        <!--act-tab start-->
                        <div class="book-bd act-tab">
                            <div>
                                <span class="time-update ly-fr">更新时间：2017-12-11 18:17:33</span>
                                <ul class="act-tab-titles clearfix">
                                    <li class="selected"><a href="javascript:">作品简介</a></li>
                                    <li><a href="javascript:">作品信息</a></li>
                                    <li><a href="javascript:">作者信息</a></li>
                                </ul>
                            </div>
                            <div class="book-cnt">
                                <!--act-tab-content start-->
                                <div class="act-tab-content">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-count clearfix">
                                                <ul class="ly-fl">
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总点击：42.9万                                                    </li>
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总收藏：<b class="J_Stock_Favor_total">1222</b>
                                                    </li>
                                                    <li>
                                                        <i class="icon-diamond">◆</i> 总字数：296586                                                    </li>
                                                </ul>
                                                <span class="ly-fl book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            	                                            </div>
                                            <div class="book-desc J_mCustomScrollbar">
                                                                                                新的旅程，新的开始。当各个已经消失或退役的战舰以舰灵或深海的方式出现在这个纷乱的，矛盾渐起的现代世界，又会发生什么情况。抽风的欧洲，血色太平洋，东欧巨变，苏联重铸，世界大战……<br />
北宅：姐姐你在哪<br />
cv2:妹妹，我一定会把你救回来。<br />
平海，宁海：我们的海军梦，终于实现了<br />
深海萨拉托加：我讨厌人类                                            </div>
                                        </div>
                                        <div class="book-tip">
                                            （本站郑重提醒: 本故事纯属虚构，如有雷同，纯属巧合，切勿模仿。)
                                        </div>
                                        <div class="book-author-label">
                                            <i class="icon-diamond">◆</i> 作者自定义标签：
                                                                                                                                                <span class="book-label">同人</span>
                                                                                                    <span class="book-label">末世</span>
                                                                                                    <span class="book-label">救亡</span>
                                                                                                    <span class="book-label">舰娘</span>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-property clearfix">
                                                <span><i class="icon-diamond">◆</i> 小说性质：免费书籍</span>
                                                <span><i class="icon-diamond">◆</i> 总点击: 42.9万</span>
                                                <span><i class="icon-diamond">◆</i> 月点击：4.2万</span>
                                                <span><i class="icon-diamond">◆</i> 周点击：0.7万</span>
                                                <span><i class="icon-diamond">◆</i> 小说类别：未来幻想</span>
                                                <span><i class="icon-diamond">◆</i> 总推荐：<b class="J_Recommend_Rec_total">2081</b></span>
                                                <span><i class="icon-diamond">◆</i> 月推荐：<b class="J_Recommend_Rec_month">187</b></span>
                                                <span><i class="icon-diamond">◆</i> 周推荐：<b class="J_Recommend_Rec_week">38</b></span>
                                                <span><i class="icon-diamond">◆</i> 总月票：100</span>
                                                <span><i class="icon-diamond">◆</i> 当月月票：9</span>
                                                <span><i class="icon-diamond">◆</i> 总刀片：63</span>
                                                <span><i class="icon-diamond">◆</i> 月刀片：8</span>
                                                <span><i class="icon-diamond">◆</i> 完成字数：296586</span>
                                                <span><i class="icon-diamond">◆</i> 写作状态：连载中</span>
                                                <span class="book-hbooker"><i class="icon-diamond">◆</i> 本站首发</span>
                                            </div>
                                        </div>
                                        <div class="book-tip"[>
                                            （本站郑重提醒: 本故事纯属虚构，如有雷同，纯属巧合，切勿模仿。)
                                        </div>
                                        <div class="book-author-label">
                                            <i class="icon-diamond">◆</i> 作者自定义标签：
                                                                                                                                                <span class="book-label">同人</span>
                                                                                                    <span class="book-label">末世</span>
                                                                                                    <span class="book-label">救亡</span>
                                                                                                    <span class="book-label">舰娘</span>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                                <!--act-tab-content start-->
                                <div class="act-tab-content" style="display:none">
                                    <div class="book-intro">
                                        <div class="book-intro-cnt">
                                            <div class="book-author-info">
                                                <div><i class="icon-diamond">◆</i> 作者的其它作品：</div>
                                                <ul class="clearfix">
                                                                                                                                                                        <li>
                                                                <a class="img ly-fl" target="_blank" href="https://www.hbooker.com/book/100011604">
                                                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170516/16-05-17135657-9762-100011604.jpg" alt="某不科学的异界舰娘">
                                                                </a>
                                                                <div class="cnt ly-fl">
                                                                    <p><a target="_blank" href="https://www.hbooker.com/book/100011604">某不科学的异界舰娘</a></p>
                                                                    <div>
                                                                        <p>字数：481671</p>
                                                                        <p>类别：青春日常</p>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                                                                            
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="book-tip">
                                            （本站郑重提醒: 本故事纯属虚构，如有雷同，纯属巧合，切勿模仿。)
                                        </div>
                                        <div class="book-author-label">
                                            <i class="icon-diamond">◆</i> 作者自定义标签：
                                                                                                                                                <span class="book-label">同人</span>
                                                                                                    <span class="book-label">末世</span>
                                                                                                    <span class="book-label">救亡</span>
                                                                                                    <span class="book-label">舰娘</span>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                <!--act-tab-content end-->
                            </div>
                        </div>
                        <!--act-tab end-->
                    </div>
                </div>
                <div class="book-ft">
                    <div class="book-chapter">

                                                <div class="mod-box ly-mt60">
                            <div class="mod-tit1">
                                <h3><i></i>苍蓝的战舰少女之现代战争<span>最新章节试阅</span></h3>
                                <a class="ly-fr" href="https://www.hbooker.com/chapter/book_chapter_detail/101438466" target="_blank">阅读本章 ></a>
                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-new">
                                    <div class="tit">第九十八章 :普京和苏联级(一)      更新时间：2017-12-11 18:17:33</div>
                                    <div class="desc box-shadow">　　如今已经是2017年一月份了，欧洲大部分的地方都在下雪。即使靠近海洋的圣彼得堡也不例外。
　　一幢房子中。
　　壁炉中的火焰燃烧着，不断传来咔嚓咔嚓木枝条爆裂的声音。来自圣彼得堡热厂的暖气也在给这..</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mod-box ly-mt30">
                            <div class="mod-tit1">
                                <h3><i></i>章节列表</h3>
                                                                    <a class="ly-fr order-by" href="https://www.hbooker.com/book/100029012?arr_reverse=1">倒序</a>
                                                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-list ly-mt30">
                                                                            <ul class="clearfix less">
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100745552"><i class="line"></i>第一章：新的穿越，新的开始</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100747874"><i class="line"></i>第二章:异变的开始——北宅出没</a></li>
                                                                                                <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/100750995"><i class="line"></i>第三章:北宅回家</a></li>
                                                                                             
                                                                                           
                                                                                    </ul>
                                                                                    <div class="read-all"><a id="J_ReadAll" href="javascript:;">+ 查看全部章节</a></div>
                                                                                                                            <ul class="clearfix">
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101427594"><i class="line"></i>第九十五章 :柏林审判(中)</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101429666"><i class="line"></i>第九十六章 :柏林审判(下)</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101434039"><i class="line"></i>第九十七章 :柏林审判(完)</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101435528"><i class="line"></i>第2章:属于尼米兹的异星战场(一)</a></li>
                                                                                                        <li><a target="_blank" href="https://www.hbooker.com/chapter/book_chapter_detail/101438466"><i class="line"></i>第九十八章 :普京和苏联级(一)</a></li>
                                                                                            </ul>
                                                                                                            </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt60">
                            <div name="book_detail_item" id="book_detail_item" class="mod-tit1">
                                <h3><i></i>书评区</h3>
                            </div>
                            <div class="mod-subtit1">
                                <div>书评总数量：
									<span>
										<s id="J_CommentNum">
											81										</s> 条
									</span>
								</div>
                                <div class="manager">本书管理员：
                                                                            <div class="img">暂无管理员</div>
                                    <!--                                    <div class="img"><img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg"/><p class="name"><a href="#">最爱切尔西</a><b>本书作者</b></p></div>-->
<!--                                    <span class="line"></span>-->
<!--                                    <div class="img"><img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg"/><p class="name"><a href="#">罐头</a></p></div>-->
                                </div>
                            </div>
                            <div class="mod-bd">
                                <div class="book-chapter-comment J_BookChapterComment" id="book_review_box">
                                    <textarea class="J_CommentInput comment-input" maxlength="1000" placeholder="快来吐槽这本书吧，注意文明用语哦\^o^/"></textarea>
                                    <div class="clearfix ly-mt10 repo">
                                        <div class="ly-fl">
                                            <div class="comment-face J_Face">
                                                <div class="face-btn"><i></i>颜文字</div>
                                                <div class="J_FaceDialog face-dialog" style="display:block;visibility:hidden">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ly-fr"><span class="J_CommentWordsCount">0</span>/<span class="J_CommentWordsCountLimit">1000</span><a href="javascript:;" class="J_ReplayBtn replay-btn ly-ml10">发表</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mod-box ly-mt30">
                            <div class="comment-list">
                                <ul class="J_CommentList">

                                </ul>
                                <!--<input type="hidden" value="" name="curr_url" id="curr_url">-->
                            </div>
                        </div>

                    </div>

                    <div class="mod-box ly-mt30">
                        <div class="mod-tit1 ly-mr30">
                            <h3><i></i> 同类作品</h3>
                            <a class="ly-fr" href="https://www.hbooker.com/index/cate_book_list/zhaiwen/6" target="_blank">查看更多 ></a>
                        </div>
                        <div class="mod-bd">
                            <ul class="book-list book-list2 J_BookList">
                                                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100053838" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/images/default.jpg" alt="变身之我的星际怎么了">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">书客79268538925</div>
                                                <div class="n">星际。变身不喜物入，。</div>
                                                <div class="num">6<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100053838" title="变身之我的星际怎么了" target="_blank">变身之我的星际怎么了</a></div>
                                        <div class="info"><span>0.1万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100014433" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160715/15-07-16090353-48315-100014433.jpg" alt="星体意识">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/520471/avatar/thumb_b2edd4da111e14efbc2a4581b64ed11d.jpg" alt="">风翎空羽</div>
                                                <div class="n">“我从恒星的火焰中诞生，与璀璨的繁星对视。”“潮起潮落的量子海洋中，孕育了无限的可能。”让这个漫长的故事从一个小细胞开始？不，让我们从恒星诞生开始，从数十亿年前最初的那一道光芒开始，见证行星的诞生，生命的进化，时代的变迁，文明的兴起和宇宙的浩瀚，追寻迷雾背后的真理，而最终，将超越这无垠的星辰大海。好吧，说白了这就是某星体少女的成长史。漫长岁月的守望者，生命进化的掌舵者，宇宙奇观的探索者，这一切都将从最初的信号子开始。（本书不签约，推荐票和月票丢这，打赏丢到《从零开始的MC生活》那里~欢迎加群131551175）</div>
                                                <div class="num">8112<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100014433" title="星体意识" target="_blank">星体意识</a></div>
                                        <div class="info"><span>204.4万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100002559" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171018/18-10-17230838-78703-100002559.jpg" alt="末世亡灵">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-10/136722/avatar/thumb_994fc966fafe528e96ffbb9c7cf215c3.jpg" alt="">心中的魔2012</div>
                                                <div class="n">“我要成为亡灵之主的女人！”某奴仆严肃脸说着。“我要亡灵之主成为我的女人！”某堂姐痴汉脸说着。“你快够！”（群号：309342410）</div>
                                                <div class="num">1075<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100002559" title="末世亡灵" target="_blank">末世亡灵</a></div>
                                        <div class="info"><span>21.2万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100054226" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/images/default.jpg" alt="我，不可能是反派">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/1707460/avatar/thumb_16d80345c71eda595df1406dd4a1091b.jpg" alt="">君风羽</div>
                                                <div class="n">他本来是全宇宙最纯良的一枚三好学生，理想就是好好读书天天向上，可惜世事难料，好学生莫名卷入了某件事的开端。他，为了不成为反派，只能在正义的边缘试探。他又发现，事情远远没有如此简单，那事件编织起来的巨网里面，他已经是推动狂潮的核心所在。本书是未来世界大幻想，在这里有新式机甲的设定，有新人类的设定，有推行变革的纯人类革命军，有维护宇宙和平大义的大管家，有超能力，有铁与火乱舞的战场，有各种欧派。一切一切，就从他的好基友回来开始。最要命的是，他根本没想到他的好基友已经变态了，咳咳，是变了。“嗨~我是萧羽，是炎星军研院最帅最纯良的好学生，最近因为被某个脑残执法人员盯上，导致内分泌有点失调。”“什么！这是我的锅？绝不可能！我不可能是反派！！”“我仔细思考，冷静分析，妈耶凉了。。”PS：新书开篇，感谢各位捧场，我，在这里与你邂逅。</div>
                                                <div class="num">6<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100054226" title="我，不可能是反派" target="_blank">我，不可能是反派</a></div>
                                        <div class="info"><span>0.1万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100050816" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171211/11-12-17161913-6804-100050816.jpg" alt="推土机的忏悔之旅">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">万俟万四</div>
                                                <div class="n">正常版：一个曾经梦想着成为推土机的男人，在经历战火的洗礼和感情的创伤后最终回到了家乡，决定从此做个普通人。热血版：封平——我有一刀四十米斩断伤痛，我有一刀洞爷湖守护羁绊。文艺版：寒士平妖录。----------------------------------------------------------------求收藏，求推荐，各种求……</div>
                                                <div class="num">331<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100050816" title="推土机的忏悔之旅" target="_blank">推土机的忏悔之旅</a></div>
                                        <div class="info"><span>5.9万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100041546" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171209/09-12-17022429-2673-100041546.jpg" alt="人形战争">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2064187/avatar/thumb_5227b2a1af64384d59284e9f417cdb2a.jpg" alt="">天御川の代行者</div>
                                                <div class="n">人形小姐姐？不，我不感兴趣，相对来说我更喜欢一个人的旅行。什么？要我带兵打仗！兄dei，你看看她们弱不禁......（嘭！）好，好，我马上准备！emmmm，那个...枪可以放下了么？诶？没有，真的没骗你。额，ok，那么让我为这个满是战火的世界奏响别样的镇魂曲吧！</div>
                                                <div class="num">24<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100041546" title="人形战争" target="_blank">人形战争</a></div>
                                        <div class="info"><span>1.0万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100052240" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171210/10-12-17205516-53622-100052240.jpg" alt="五河士织的末日旅程">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2016-11/52747/avatar/thumb_6764cc3c033014658bb5c8f786a35c20.jpg" alt="">随缘的悠游</div>
                                                <div class="n">当人类的幻想二次元与现实开始融合……末日已是悄然的降临……</div>
                                                <div class="num">133<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100052240" title="五河士织的末日旅程" target="_blank">五河士织的末日旅程</a></div>
                                        <div class="info"><span>1.5万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100038162" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170710/10-07-17124910-63952.jpg" alt="当不成提督的我只能去投敌了">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-08/2070520/avatar/thumb_9a28ea42c2243968fd92305691550e24.jpg" alt="">落羽家的哈士奇</div>
                                                <div class="n">洛羽努力了十年，只为成为提督，眼看就要成功了，然而她的出现，成功地让洛羽的梦想，碎成了渣。“提督提督，我们去钓鱼吧！”“小祖宗欸，我们已经吃了一个月的鱼了，能换换口味不？”“可是...镇守府里只剩下鱼了啊”“决定了，我们去投靠深海吧！再这么下去，我们迟早得饿死...”中间栖姬：“欢迎来到深海的大家庭，作为深海，你要学会的第一件事就是穿裙子。”前排提示，本书不会签约，所以不需要月票和打赏...我能有什么办法啊，身为高中生签不了约我也很无奈啊...</div>
                                                <div class="num">1668<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100038162" title="当不成提督的我只能去投敌了" target="_blank">当不成提督的我只能去投敌了</a></div>
                                        <div class="info"><span>48.5万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100053851" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171211/11-12-17115234-21145-100053851.jpg" alt="只要在末世下活下去就好了吗？">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">单纯的烙饼</div>
                                                <div class="n">一个陷入末日的世界，一个残酷冰冷的世界，一个被天灾和怪物肆虐的世界。在这样的末世下，只有活下去才是一切！高尚奉献精神？崇高牺牲理念？实力至上就要拯救世界?蝼蚁就该低头默默付出？抱歉，找别人吧，我只想活下去……</div>
                                                <div class="num">4<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100053851" title="只要在末世下活下去就好了吗？" target="_blank">只要在末世下活下去就好了吗？</a></div>
                                        <div class="info"><span>0.1万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100050796" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171130/30-11-17235347-77211-100050796.jpg" alt="U.L.T.R.A">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-10/2473138/avatar/thumb_7ccc47adb090b1ed618bb1e4d5c0363e.jpg" alt="">当谁在此处时</div>
                                                <div class="n">也许所有人都会回家，也许有些人已经无家可归。在DEUS的影响下，地球将不是以前的地球。天穹计划更是让方舟计划的人彻底脱离与地球的关系。所有的人都已经无家可归了。但他们的行为又何尝不是在寻找新的归宿？——摘自2016年8月21日，后记</div>
                                                <div class="num">30<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100050796" title="U.L.T.R.A" target="_blank">U.L.T.R.A</a></div>
                                        <div class="info"><span>1.0万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100012521" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/images/default.jpg" alt="量子纠缠">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-06/397975/avatar/thumb_85ce206a09b1e8dc2240a605de2be9cd.jpg" alt="">万花筒写轮眼</div>
                                                <div class="n">“我要去学园都市，我这辈子一定要出人头地。”十六岁的瘦削少年一脸坚决。“我不同意，家里怎么办，你走了谁给家里赚钱，房贷还有十五年，早点还完能省多少钱！”父亲抽着烟，勃然大怒。“我才不管，这一次我绝对不要退让，绝对不要！”少年畏惧且执拗。</div>
                                                <div class="num">6<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100012521" title="量子纠缠" target="_blank">量子纠缠</a></div>
                                        <div class="info"><span>0.3万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                        <li>
                                        <a class="img" href="https://www.hbooker.com/book/100048790" target="_blank">
                                            <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171107/07-11-17185306-49365-100048790.jpg" alt="我和世界不得不说的故事">
                                            <div class="mask"></div>
                                            <div class="info">
                                                <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">风雪无痕</div>
                                                <div class="n">一纸合同让沐云成为了光荣的世界级员工，于是沐云走上了一条脚踏星河，拳打宇宙的王道主角！当然以上纯属瞎说，事实证明哪怕背后有个强到爆的BOSS，以及一群奇怪的小伙伴！而咸鱼依旧是咸鱼！！</div>
                                                <div class="num">26<i></i></div>
                                            </div>
                                        </a>
                                        <div class="title"><a href="https://www.hbooker.com/book/100048790" title="我和世界不得不说的故事" target="_blank">我和世界不得不说的故事</a></div>
                                        <div class="info"><span>0.9万</span>︱<span>未来幻想</span></div>
                                    </li>
                                                                                                </ul>
                        </div>
                    </div>

                </div>
            </div>
            <!-- ly-main -->


            <!-- ly-side -->
            <div class="ly-side">

                <!-- 给作者打赏 start-->
                <div class="mod-box">
                    <div class="mod-tit1">
                        <h3><i></i>给作者打赏</h3>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-reward box-shadow">
                            <div class="smile"></div>
                            <button type="button" class="J_DaShang" data-type="shang">打赏~么么哒~~</button>
                            <button type="button" class="btn-primary J_DaShang" data-type="prop">不更新？寄刀片！</button>
                        </div>
                    </div>
                </div>
                <!--给作者打赏 end-->

                <!--粉丝支持 start-->
                <div class="mod-box ly-mt30">
                    <div class="mod-tit1">
                        <h3><i></i>粉丝支持</h3></a>
                    </div>
                    <div class="mod-bd ly-mt45">
                        <div class="book-fans-support box-shadow">
                          <div class="bd J_FansTip">
        <ul>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【夸张】1月票</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/2491357" target="_blank">夸张</a></span> <i class='icon-level-h'>• 高V</i></div>
                            <p>2017-12-11 21:06:19</p>
                            <p>
                                投了1月票                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">
                            <div class='medal medal_24_67'></div>                            <i class="icon-sex icon-male"></i>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="cnt">
                        <a href="javascript:">【导弹驱逐舰金刚号】2刀片</a>
                    </div>
                    <div class="tips clearfix">
                        <div class="ly-fl fans-info">
                            <div class="name"><span><a href="https://www.hbooker.com/bookshelf/38176" target="_blank">导弹驱逐舰金刚号</a></span> <i class='icon-level-h'>• 高V</i></div>
                            <p>2017-12-10 22:31:01</p>
                            <p>
                                投了2刀片                            </p>
                        </div>
                        <div class="img ly-fl">
                            <img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-11/38176/avatar/thumb_1371560a3cde561d95a0cb51a6c6d895.jpg" alt="">
                            <div class='medal medal_22_67'></div>                            <i class="icon-sex icon-female"></i>
                        </div>
                    </div>
                </li>
                    </ul>
    </div>

<script type="text/javascript">
    //粉丝弹框
    $(".J_FansTip li").hoverClass();
</script>
<script type="text/javascript">
    $('img.lazyload').length && lazyloadHandle();
    function lazyloadHandle() {
        HB.util.require('jquery.lazyload', function(){
            $("img.lazyload").lazyload({
                threshold : 300,
                // effect : "fadeIn",
                // placeholder: "../images/transparent.png",
                failure_limit: 200,
                skip_invisible : false
            });
        });
    }
</script>
                        </div>
                    </div>
                </div>
                <!--粉丝支持 end-->

                <!--本书名人榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i>本书名人榜</h3></a>
                    </div>
                    <div class="mod-bd ly-mt30">
                        <div class="book-leaderboard box-shadow">
                            <ul>
                                <li>
   <!--**********************************************************************************************************************************************-->
   
<ul>
    <!-- 票王 -->
            <li>
            <div class="hd">票王 <i>NO.1</i></div>
            <div class="bd clearfix">
                <div class="img ly-fl">
                    <img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img/130526/avatar/thumb_521994e436a42054125832ab0b578673.jpg" alt="" src="https://www.hbooker.com/resources/images/avatar-default-f.png">
                    <div class='medal medal_21_80'></div>                    <i class="icon-sex icon-female"></i>
                </div>
                <div class="cnt ly-fl">
                    <p class="name"><span><a href="https://www.hbooker.com/bookshelf/130526" target="_blank">不破爱花</a></span> <i class='icon-level-2'>• 初V</i></p>
                    <p class="level">经验等级：LV.8无双隐士</p>
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="130526"><i>&plus;</i> 关注</a>
                                                        </div>

            </div>
        </li>
    
    <!-- 第一粉丝 -->
            <li>
            <div class="hd">第一粉丝 <i>NO.1</i></div>
            <div class="bd clearfix">
                <div class="img ly-fl">
                    <img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/1260206/avatar/thumb_b642ffb289305b08879b36939896f4ba.jpg" alt="">
                    <div class='medal medal_21_80'></div>                    <i class="icon-sex icon-male"></i>
                </div>
                <div class="cnt ly-fl">
                    <p class="name"><span><a href="https://www.hbooker.com/bookshelf/1260206" target="_blank">伟大の石头</a></span> <i class='icon-level-4'>• 钻V</i></p>
                    <p class="level">经验等级：LV.12笑傲江湖</p>
                                                                <a href="javascript:;" class="foll J_Follow" data-follow="0" data-reader-id="1260206"><i>&plus;</i> 关注</a>
                                                        </div>

            </div>
        </li>
    
</ul>
<script type="text/javascript">
    $('img.lazyload').length && lazyloadHandle();
    function lazyloadHandle() {
        HB.util.require('jquery.lazyload', function(){
            $("img.lazyload").lazyload({
                threshold : 300,
                // effect : "fadeIn",
                // placeholder: "../images/transparent.png",
                failure_limit: 200,
                skip_invisible : false
            });
        });
    }
</script>
   
   <!--**********************************************************************************************************************************************-->

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--本书名人榜 end-->


                <div class="fans-tit ly-mt45">
                    <h4>粉丝荣誉榜单</h4>
                </div>

                <!--铁杆粉丝榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i>铁杆粉丝榜</h3></a>
                    </div>
                    <div class="mod-bd ly-mt30" style="background:#fafafa">
                        <div class="book-fansboard">
                            <ul>加载中...</ul>
                        </div>
                    </div>
                </div>
                <!--铁杆粉丝榜 end-->
                <!--点击榜 start-->
                <div class="mod-box ly-mt45">
                    <div class="recomm-list J_RecommList">
                        <div class="tit1">
                            <p class="ly-fl"><i></i>点击榜</p>
                            <div class="ly-fr rank-list J_RankList"> <a href="javascript:;" class="drop-down">周榜</a><b></b>
                                <ul style="display: none;">
                                    <li><a href="javascript:;" class="selected">周榜</a></li>
                                    <li><a href="javascript:;">月榜</a></li>
                                    <li><a href="javascript:;">总榜</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="tab">
                            <div class="t">本周点击排行</div>
                            <ul>

                                                                                                            <li class="top1">
                                            <a href="https://www.hbooker.com/book/100011781" target="_blank">
                                                <span class="num">73.6万</span><i class="icon-top icon-top1">1</i>【异界幻想】我的大宝剑                                            </a>
                                        </li>
                                                                            <li class="top2">
                                            <a href="https://www.hbooker.com/book/100049792" target="_blank">
                                                <span class="num">66.9万</span><i class="icon-top icon-top2">2</i>【动漫穿越】我，型月，漫画家！                                            </a>
                                        </li>
                                                                            <li class="top3">
                                            <a href="https://www.hbooker.com/book/100050877" target="_blank">
                                                <span class="num">52.1万</span><i class="icon-top icon-top3">3</i>【动漫穿越】贪吃蛇的目标是吞噬星空                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100034670" target="_blank">
                                                <span class="num">48.9万</span><i class="icon-top ">4</i>【超现实都市】遍地英灵的二十一世纪                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100052219" target="_blank">
                                                <span class="num">38.3万</span><i class="icon-top ">5</i>【游戏世界】出逃魔王与线上老婆                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049348" target="_blank">
                                                <span class="num">31.7万</span><i class="icon-top ">6</i>【青春日常】凭什么你也重生啊                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049782" target="_blank">
                                                <span class="num">30.7万</span><i class="icon-top ">7</i>【动漫穿越】魔法少女伊利丹                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100047615" target="_blank">
                                                <span class="num">29.8万</span><i class="icon-top ">8</i>【青春日常】我，日常番里的普通高中生                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100050780" target="_blank">
                                                <span class="num">28.3万</span><i class="icon-top ">9</i>【战争历史】致四千年后                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100042074" target="_blank">
                                                <span class="num">28.6万</span><i class="icon-top ">10</i>【游戏世界】悲惨世界                                            </a>
                                        </li>
                                                                    
                            </ul>
                        </div>
                        <div style="display:none" class="tab">
                            <div class="t">本月点击排行</div>
                            <ul>
                                                                                                            <li class="top1">
                                            <a href="https://www.hbooker.com/book/100049792" target="_blank">
                                                <span class="num">547.5万</span><i class="icon-top icon-top1">1</i>【动漫穿越】我，型月，漫画家！                                            </a>
                                        </li>
                                                                            <li class="top2">
                                            <a href="https://www.hbooker.com/book/100011781" target="_blank">
                                                <span class="num">391.6万</span><i class="icon-top icon-top2">2</i>【异界幻想】我的大宝剑                                            </a>
                                        </li>
                                                                            <li class="top3">
                                            <a href="https://www.hbooker.com/book/100034670" target="_blank">
                                                <span class="num">306.7万</span><i class="icon-top icon-top3">3</i>【超现实都市】遍地英灵的二十一世纪                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049782" target="_blank">
                                                <span class="num">250.4万</span><i class="icon-top ">4</i>【动漫穿越】魔法少女伊利丹                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100029943" target="_blank">
                                                <span class="num">232.8万</span><i class="icon-top ">5</i>【神秘未知】我，旧日支配者                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100042074" target="_blank">
                                                <span class="num">221.1万</span><i class="icon-top ">6</i>【游戏世界】悲惨世界                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100049642" target="_blank">
                                                <span class="num">218.3万</span><i class="icon-top ">7</i>【动漫穿越】次元漫展                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100048623" target="_blank">
                                                <span class="num">209.1万</span><i class="icon-top ">8</i>【动漫穿越】这个世界好危险                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100046232" target="_blank">
                                                <span class="num">202.3万</span><i class="icon-top ">9</i>【动漫穿越】救世主的一百万种求生法则                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100047615" target="_blank">
                                                <span class="num">196.5万</span><i class="icon-top ">10</i>【青春日常】我，日常番里的普通高中生                                            </a>
                                        </li>
                                                                                                </ul>
                        </div>
                        <div style="display:none" class="tab">
                            <div class="t">点击总排行</div>
                            <ul>
                                                                                                            <li class="top1">
                                            <a href="https://www.hbooker.com/book/100011781" target="_blank">
                                                <span class="num">13,962.0万</span><i class="icon-top icon-top1">1</i>【异界幻想】我的大宝剑                                            </a>
                                        </li>
                                                                            <li class="top2">
                                            <a href="https://www.hbooker.com/book/100025268" target="_blank">
                                                <span class="num">6,960.5万</span><i class="icon-top icon-top2">2</i>【青春日常】我为女儿〇一秒                                            </a>
                                        </li>
                                                                            <li class="top3">
                                            <a href="https://www.hbooker.com/book/100029943" target="_blank">
                                                <span class="num">6,422.8万</span><i class="icon-top icon-top3">3</i>【神秘未知】我，旧日支配者                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100018731" target="_blank">
                                                <span class="num">5,488.2万</span><i class="icon-top ">4</i>【超现实都市】我在东瀛画工口本子                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100020459" target="_blank">
                                                <span class="num">4,526.9万</span><i class="icon-top ">5</i>【动漫穿越】你很怠惰呢，德古拉                                            </a>
                                        </li>
                                                                            <li class="">
                                            <a href="https://www.hbooker.com/book/100034670" target="_blank">
                                                <span class="num">4,487.6万</span><i class="icon-top ">6</i>【超现实都市】遍地英灵的二十一世纪                                            </a>
                                        
                                                                                                </ul>
                        </div>
                        <div class="rank-more"><a href="https://www.hbooker.com/index/rank_book_list/click">查看更多 ></a></div>
                    </div>
                </div>
                <!--点击榜 end-->
            </div>
            <!-- ly-side -->

        </div>
        <!--书页 end-->


        <div class="go-top" id="J_GoTop">
            <a href="javascript:">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->

<!-- 用户操作 -->
<div id="J_TuiJianBox" class="J_GiveGift" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>您的余额:<br>
                <b class="J_HLB">0</b></p>
</div>
<div class="line">
    <p>您的推荐票余量:<br>
        <b class="J_Recommend">0</b></p>
</div>
<div class="line">
    <p>写得太好了，给作者投推荐票:<br>
        <a href="javascript:;" class="no-minus J_noMinus">-</a>
        <input type="text" value="1" class="text-amount J_NumResult" maxlength="10"/>
        <a href="javascript:;" class="no-plus J_noPlus">+</a> </p>
</div>
<div class="form-btn center ly-mt30">
    <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投推荐票</a></p>
    <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
</div>
</div>
</div>
<div id="J_YuePiaoBox" class="J_GiveGift" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>您的余额:<br>
                <b class="J_HLB">0</b></p>
        </div>
        <div class="line">
            <p>您的月票余量:<br>
                <b class="J_Stock">0</b></p>
        </div>
        <div class="line">
            <p>写得太好了，给作者投月票:<br>
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10"/>
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
            </p>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投月票</a></p>
            <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>
<div id="J_DingYueBox" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>
                您的余额:<br><b class="J_HLB">0</b>
            </p>
        </div>
        <div class="line">
            <ul class="input-radio J_InputRadio">
                                <li>
                    <a href="javascript:;" class="selected"> <i class="icon-select"></i>全本订阅                        <input type="radio" class="J_NumResult" value="1" style="display:none" checked="checked">
                    </a>
                    <div>需购章节：0 章，<br/>
                    	
                   		 应付总额：0 欢乐币<br>
                                                            </li>
            </ul>
            <!--新增  复选框 start-->
                        <!--新增  复选框 end-->
            <div class="dy-deac ly-mt10">
                1、全本订阅是订阅目前已更新的全部章节，如期间有免费章节和<br>
                已购买章节，下载时将一并下载。<br>
                2、免费章节及已购买章节不会重复扣费，请放心购买。
            </div>
        </div>
        <div class="form-btn center ly-mt30">
                            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01" disabled="true">无需订阅</a></p>
                        <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>
<div id="J_DaShangBox" style="display:none">
    <div class="account-type">
        <ol class="input-radio J_InputRadio clearfix">
            <li><a href="javascript:;" class="selected" data-type="shang">打赏</a></li>
            <li><a href="javascript:;" data-type="prop">道具</a></li>
        </ol>
    </div>
    <!-- <div class="account-info account-shang account-shang-planb J_AccountShang">-->
        <div class="account-info account-shang J_AccountShang account-shang-planb">
        <div class="line">
            <p>您的欢乐币余额:<br>
                <b class="J_HLB">0</b></p>
        </div>
        <div class="line line-pd0">
            <ul class="input-radio J_InputRadio clearfix">
                <li>
                    <a href="javascript:;" class="selected" data-prop-type="37"><span></span>
                        <input type="radio" class="J_NumResult" value="100" checked="checked">
                    </a>
                </li>
                <li>
                    <a href="javascript:;" data-prop-type="38"><span></span>
                        <input type="radio" class="J_NumResult" value="588">
                    </a>
                </li>
                <li>
                    <a class="bdright" href="javascript:;" data-prop-type="39"><span></span>
                        <input type="radio" class="J_NumResult" value="1688">
                    </a>
                </li>
                <li>
                    <a class="bgbottom" href="javascript:;" data-prop-type="40"><span></span>
                        <input type="radio" class="J_NumResult" value="5000">
                    </a>
                </li>
                <li>
                    <a class="bgbottom" href="javascript:;" data-prop-type="41"><span></span>
                        <input type="radio" class="J_NumResult" value="10000" style="display:none">
                    </a>
                </li>
                <li>
                    <a class="bgbottom bdright" href="javascript:;" data-prop-type="42"><span></span>
                        <input type="radio" class="J_NumResult" value="100000" style="display:none">
                    </a>
                </li>
            </ul>
        </div>
        <div class="line-amount J_NumCalculate">
                打赏数量：
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10">
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">立即打赏</a></p>
            <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
    <div class="account-info account-prop J_AccountProp" style="display: none;">
        <div class="line">
            <p>您的欢乐币余额:<br>
                <b class="J_HLB">0</b>
            </p>
        </div>
        <div class="line blade-info">
            <div class="blade ly-fl"></div>
            <h3 class="title">催更刀片</h3>
            <p>想要加快更新速度？试试给作者寄刀片吧！</p>
            <p>单价 <span class="J_BladePrice">100</span> 欢乐币</p>
            <p class="own-blade">拥有 <i class="J_OwnBlade">0</i> 个</p>
            <div class="blade-amount J_BladeAmount">
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10"/>
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
            </div>
        </div>
        <div class="line">
            <p>需购道具：<i class="J_BladeNum">1</i> x 催更刀片</p>
            <p>应付总额：<b class="J_Consume">100</b> 欢乐币</p>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投出道具</a></p>
            <p class="ly-mt10"><a href="https://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>

<!-- 登录框 -->
<div id="J_LoginBox" class="layout-login" style="display:none">
    <div class="login-box">
        <form action="https://www.hbooker.com/signup/doLoginBox" class="form-box" id="J_LoginForm" name="J_LoginForm" method="post" onsubmit="doLoginBox();return false;">
            <h3>登录</h3>
            <div class="form-group">
                <input type="text" placeholder="手机号/邮箱" class="username" name="username">
                <!--<label id="username-error" class="error" for="username">请填写用户名</label>-->
            </div>
            <div class="form-group">
                <input type="password" placeholder="密码" class="password" name="password">
            </div>
            <div class="form-group code-group">
									<div id="embed-geetest-captcha"></div>
					<p id="geetest-wait">正在加载验证码......</p>
					<p id="geetest-notice">请先拖动验证码到相应位置</p>
					<script>
						HB.util.loadGeetest = function () {
							if (window.geetestCaptchaObj) {
								return;
							}
							var head = document.getElementsByTagName("head")[0];
							var s = document.createElement("script");
							s.src = "https://www.hbooker.com/resources/js/gt.js";
							head.appendChild(s);

							s.onload = s.onreadystatechange = function() {
								if (!this.readyState || 'loaded' === this.readyState || 'complete' === this.readyState) {
									$("#geetest-notice").hide();
									var handlerEmbed = function (captchaObj) {
										$("#dosubmmit").click(function (e) {
											var validate = captchaObj.getValidate();
											if (!validate) {
												$("#geetest-notice").show();
												setTimeout(function () {
													$("#geetest-notice").hide();
												}, 2000);
												e.preventDefault();
											}
										});
										captchaObj.appendTo("#embed-geetest-captcha");
										captchaObj.onReady(function () {
											$("#geetest-wait").hide();
										});
										window.geetestCaptchaObj = captchaObj;
									};
									$.ajax({
										// 获取id，challenge，success（是否启用failback）
										url: "https://www.hbooker.com/signup/geetest_captcha?t=" + (new Date()).getTime(), // 加随机数防止缓存
										type: "get",
										dataType: "json",
										success: function (data) {
											// 使用initGeetest接口
											// 参数1：配置参数
											// 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
											initGeetest({
												gt: data.gt,
												challenge: data.challenge,
												product: "float", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
												offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
												// 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
											}, handlerEmbed);
										}
									});
								}
							};
						};
					</script>
							 </div>
            <div class="form-btn">
                <button type="submit" name="dosubmmit" id="dosubmmit">登录</button>
            </div>
            <div class="form-ft clearfix"> <span class="tl">
		        <label>
                    <input type="checkbox" checked="checked" name="autoLogin" value="1">
                    自动登录</label>
		        </span> <span> <a href="https://www.hbooker.com/signup/register?redirect=https://www.hbooker.com/book/100029012">注册</a> </span> <span class="tr"> <a class="fpw" href="https://www.hbooker.com/signup/modify_passwd_page?redirect=https://www.hbooker.com/book/100029012">忘记密码 ></a> </span> </div>
        </form>
        <div class="login-ft">
            <div class="otherUser">
                <div class="otherUser_T"><span>使用其他账号登录</span><b></b></div>
                <div class="otherUser_B">
                    <a href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2Fbook%2F100029012" class="qqLogin"></a>
<!--                    <a href="javascript:;" class="qqLogin"></a>-->
					<!-- <a href="https://www.hbooker.com/signup/weixin_login" class="weixinLogin"></a> -->
                    <a href="javascript:;" class="wbLogin"></a>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo e(asset('bootstrap/jquery.validate.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('home/js/dialog-form.js')); ?>"></script>
<script type="text/javascript">
    function doLoginBox(){
        var self = $(this);
        var username = $("input[name='username']").val();
        var password = $("input[name='password']").val();
        
        var autoLogin=$("input[name='autoLogin']:checked").val();
		
		var post_data = {};
		if(window.geetestCaptchaObj) {
			var validate = window.geetestCaptchaObj.getValidate();
			if (!validate) {
				$("#geetest-notice").show();
				setTimeout(function () {
					$("#geetest-notice").hide();
				}, 2000);
				return;
			}
			post_data = {username: username, password: password, autoLogin:autoLogin};
			var validateDict = window.geetestCaptchaObj.getValidate();
			for(var key in validateDict) {
				post_data[key] = validateDict[key];
			}
		} else {
			var code = $("input[name='code']").val();
			if(code==''){
				HB.util.alert("请输入验证码!");
				return;
			}
			post_data = {username: username, password: password, code: code,autoLogin:autoLogin};
		}

        var dosubmmit = $("#dosubmmit");
        if(dosubmmit.prop('disabled')) return false;

        $.ajax({
            url: HB.config.rootPath + 'signup/doLoginBox',
            data: post_data,
            beforeSubmit: function() {
                dosubmmit.prop("disabled", true);
            },
            complete: function () {
                dosubmmit.prop("disabled", false);
            },
            success: function (res) {
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '登录成功！';
                    HB.util.alert(msg);
                    //$("#J_LoginBox").attr('style','display:none');
                    window.location.reload();
                } else {
                    HB.util.alert(res.tip,1);
                    $("#code").trigger('click');
                }
            }
        });
    }
</script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/face.js"></script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/faceImg.js"></script>
<script type="text/javascript" src="https://www.hbooker.com/resources/js/book-detail.js"></script>

<script type="text/javascript">
    //加载右侧页面
    var load_right = function(){
        // 粉丝支持
        var fans = $(".book-fans-support");
        var url = "https://www.hbooker.com/book/get_book_operate_list?book_id=100029012";
        fans.load(url);

        // 本书名人榜
        var fans1 = $(".book-leaderboard");
        var url1 = "https://www.hbooker.com/book/get_book_operate_best_reader?book_id=100029012";
        fans1.load(url1);

        // 铁杆粉丝榜
        var fans2 = $(".book-fansboard");
        var url2 = "https://www.hbooker.com/book/get_book_fans_list?book_id=100029012";
        fans2.load(url2);
    }

    $(document).ready(function(){
        load_right();
    });

    (function(){
        var obj = $(".J_Face").closest(".J_BookChapterComment").find('.J_CommentInput');
        $(".J_Face").qfcfaceimg({area: obj});
    })();
    //书评前开始检测是否登陆
    $('.J_CommentInput').focus(function () {
        if (HB.userinfo.reader_id==0) {
            $('.J_CommentInput').blur();
            HB.util.loginDialog();
            return false;
        }
    })
</script>   


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>