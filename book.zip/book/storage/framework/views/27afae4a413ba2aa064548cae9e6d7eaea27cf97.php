<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Insert title here</title>
</head>
<body>
<form action="author/shangchuan" method="post" enctype="multipart/form-data">
    
    <?php echo e(csrf_field()); ?>

<!-- <input type="hidden" name="MAX_FILE_SIZE" value='176942' /> -->
请选择您要上传的文件：<input type="file" name='myfile' />
<!-- <input type="file" name="myFile"  accept="image/jpeg,image/gif,image/png"/><br /> -->
<input type="submit" value="上传文件" />
</form>
</body>
</html>