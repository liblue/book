<?php $__env->startSection('nav'); ?>
   <li><a href="<?php echo e(url('user')); ?>" >我的信息</a></li>
               
                <li><a href="/" class='selected'>我是作者</a></li>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote layui-text">
 <div class="site-demo-button" style="margin-bottom: 0;">
     <a href="<?php echo e(url('au/create')); ?>"><lable class="layui-btn site-demo-active" data-type="tabAdd" style="background-color: #67b242">新建作品</lable></a>
</div>
</blockquote>
<div style="height: 1000px">
  
    
    
    <table class="layui-table">
  <colgroup>
    <col width="150">
    <col width="200">
    <col>
  </colgroup>
  <thead>
    <tr>
        <th><input type="checkbox" class="selectAll" id="selectAll" name="choice"></th>
      <th>书名</th>
      <th>加入时间</th>
      <th>签名</th>
       <th>状态</th>
      <th>管理</th>
     
    </tr> 
  </thead>
  <tbody>
    <tr>
        <td  align="left"> <input type="checkbox" class="subSelect" name="choice" ></td>
      <td>贤心</td>
      <td>2016-11-29</td>
     
     <td>于千万人之中遇见你</td>
      <td>连载中</td>
      <td> <a  href="<?php echo e(url('au_info')); ?>"> <button class="layui-btn layui-btn-primary">设置</button></a>
          <button class="layui-btn layui-btn-primary">详情</button> <button class="layui-btn layui-btn-primary">添加章节</button></td>
    </tr>

   
  </tbody>
</table>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>