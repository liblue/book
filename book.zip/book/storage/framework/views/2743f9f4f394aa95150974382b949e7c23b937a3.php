
<!DOCTYPE html>
<html>
    <head>
        <base href="http://author.hbooker.com/">
        <title>欢乐书客作者平台</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('home/css/cms_screen.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('admin/lib/layui/css/layui.css')); ?>">

         <script src="<?php echo e(asset('admin/lib/layui/layui.js')); ?>" charset="utf-8"></script>
    </head>
    <body class="mainBody">
        <style>
    .popup-msg-modal {
		font-size: 14px;
	}
	.popup-msg-modal .modal-header,.popup-msg-modal .modal-footer{
		border: none;
	}
	.msg-content {
		margin-top: 20px;
	}
	.replay_title{ width:700px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
</style>
<div class="wrapp">
    
   
    <div class="cms-nav-container">
       
        <div class="container nav-container" style="background-color:" >
            <div  style="background:url(<?php echo e(asset('home/images/shouye.png')); ?>) no-repeat ;float:left;width:300px;height: 100%" ><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('home/images/shouye.png')); ?>"/></a></div>
<?php echo $__env->yieldContent('head'); ?>


        </div>
    </div>

    <div class="container cms-content clearfix">		
<!--        <div class="top-msg">
            <h5 class="msg-title">今天是2017-12-18，星期一&nbsp;&nbsp;<a href=http://author.hbooker.com/book_manage/view_list  class="active-link green" target="div-iframe-view">[ 点击此处查看 ]</a></h5>
						<a class="url-forward rewards-rule" href="http://author.hbooker.com/uploader_info/apply_bonus">奖励与缺勤制度</a>
		</div>-->
        <div class="left-nav-detail">
                           
                           
                    </div>
        <div class="content-out-container main-content" style="height:700px;overflow: scroll">
       <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>




		<!-- footer -->
		<div class="footer">
		
			<div class="copyright">Copyright © 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.</div>
			<p>打造中国最好的阅读软件 - 小说资源互助群 <span class="lighter-green">139851656</span>- 微信公众号 <span class="lighter-green">happybooker</span></p>
		</div>
    </body>
<script>
    /*
     * 登录页面操作
     */
    $('.login-form-content .login-verifyim').live('click',function(){
        var id= Math.round((Math.random()) * 100000000);
        var src ='http://author.hbooker.com/login/verifyimg?id='+id;//确保Firefox点击验证码可更换
        $(this).attr('src',src);
    });
</script>
</html>
