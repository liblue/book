    

<?php $__env->startSection('nav'); ?>
                <li><a href="<?php echo e(url('/')); ?>" >首页</a></li>
                <li><a href="paihang" class='selected'>排行</a></li>
                <li><a href="https://www.hbooker.com/index-zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index-tongren" >同人</a></li>
                <!--<li><a href="https://www.hbooker.com/index/header_cate_list/male" >男生</a></li>-->
                <li><a href="https://www.hbooker.com/index-female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index-comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index-game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs" >社区</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>   
    
<div class="container">
    <div class="ly-wrap">

        <div class="ly-main">
            
            <div class="first-col">
                <div class="banner banner-top J_Slider ly-fl">
                    <a href="javascript:;" class="slider-btn prev"></a>
                    <a href="javascript:;" class="slider-btn next"></a>
                    <ul>
                                                                                <li>
                                <a href="http://app.hbooker.com/setting/event?item=tonggao_tz&noticeid=53" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171205033229566.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="http://app.hbooker.com/setting/event?item=tonggao_tz&noticeid=53" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/publicity_dec" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171212104114173.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/publicity_dec" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171115095550417.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/yuanchuang" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20170901100447582.png" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/yuanchuang" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/book/100046943" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208024751496.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/book/100046943" target="_blank">
                                                驱魔人信条                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/book/100049742" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030210217.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/book/100049742" target="_blank">
                                                最强编辑                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/book/100000514" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171209044110807.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/book/100000514" target="_blank">
                                                比企谷雪乃的养成日记                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                                        </ul>
                </div>
                <ul class="topic ly-fl" id="J_Topic">
                                                                    <li>
                            <a href="https://www.hbooker.com/book/100047787" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030947512.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【咸鱼难翻身】</div>
                                    <div class="n">没错，我就是大流士lily！</div>
                                    <div class="num">6457人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100025268" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031005344.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【吾有八宗罪】</div>
                                    <div class="n">“爸爸，如果你不趁现在攻略妈妈，我就会因为历史改变而消失！”
本来以为注定孤独一生的吴申，一天醒来眼前却接二连三的出现自称来自未来的女儿们！
我怎么就喜当爹了呢？蛤，我说你们还是另请高明。
什么？你说你妈妈叫霞之丘诗羽？你说你妈咪是椎名真白？你说你母亲叫雪之下雪乃？你老妈是八云紫？
于是为了拯救自己可爱的萝莉女儿们，吴申踏上了浩浩荡荡的攻略之旅。
书友群：370725794  欢迎加入(/≧▽≦)/求月票求推荐票求打赏~~~</div>
                                    <div class="num">64505人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047734" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171124023856998.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【幽幽之灵】</div>
                                    <div class="n">神代幻想乡（大概距离现代3000年以上）——萝莉的子弹——冬木圣杯棋战（Fate Chess War）——待定
第一卷妖神战已经完结，现已进入第二卷漆黑的子弹。
......
新人写手，第一卷前面文笔略显粗糙，但往后会好很多。
所以，不想看第一卷的也可以从第二卷开始看啦φ(｀・ω・´)
（ps：前面一小段主角是男性的，但是本书确实是变百，这是作者姬的锅，咱自己背好了，其实并不怎么影响月读的，大概？）</div>
                                    <div class="num">3634人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047912" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031041982.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【咸鱼萝莉三】</div>
                                    <div class="n">一代神王叶洛重新睁开了眼睛，发现自己来到了一个叫地球的星球上面。夺舍了他人成为了一名东瀛的女高中生。
    “早知道找个胸小点的夺舍了！”叶洛瞥了瞥那丰满的胸部，皱着眉说道。
      作者是萌新，求月票，求收藏，求收藏！</div>
                                    <div class="num">1205人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047681" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031055305.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【胖子可以变身】</div>
                                    <div class="n">少年你渴望力量吗。
少年:力量我已经得到过，现在我渴望平静。
少年你渴望奶子吗
少年:等我先把轻度女性恐惧症治好再说。
修真界回归的大佬，回归世界却来到一个类似平行世界，这个世界的人好像有点熟悉啊。
雪之下阳乃，极度腹黑。狡猾。</div>
                                    <div class="num">1882人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="https://www.hbooker.com/book/100047146" target="_blank">
                                <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208031111876.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【智神大人】</div>
                                    <div class="n">重生归来的主角携带无敌的力量势要改变未来，不过......
“我的弟弟呢？”
PS：会有一部分动漫角色乱入，但整体还是以原创为主，所以不会有太多的乱入。
再PS：重生后与重生前一起写</div>
                                    <div class="num">114人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                            </ul>
            </div>

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>宅文推荐</h3>
                        <i class="line"></i>
                        <span>200位宅文大神鼎力打造</span>
                        <a href="https://www.hbooker.com/index/header_cate_list/zhaiwen">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100049774" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17102341-79943-100049774.jpg" alt="我和Caster谈恋爱">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-02/189853/avatar/thumb_85b543775ee54d6436914d2edadc95c1.jpeg" alt="">【殁言】</div>
                                        <div class="n">你问我美狄亚哪里好？体贴、温柔还有偶尔的小性子无时无刻都在吸引着我除了......咳咳，偶尔......不胜腰力</div>
                                        <div class="num">3806<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100049774" title="我和Caster谈恋爱" target="_blank">我和Caster谈恋爱</a></div>
                                <div class="info"><span>55.5万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100003327" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160411/11-04-16235453-2251-100003327.jpg" alt="幻想乡的琐碎日常">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img/108318/avatar/thumb_6e7fc1fcab9d87564553bd98b125a411.jpg" alt="">【锅巴夹馍】</div>
                                        <div class="n">这是幻想乡的琐碎日常。以及迷之情报分析师的学生的故事。并且，还是未曾向他人道述过的，博丽巫女老师的故事。。女主是灵梦，但每个出场的女孩都会发出自己的光彩。莫茗，不会被谎言所欺骗程度的能力。【注】是有节操的灵梦、以及……有节操的幻想乡。</div>
                                        <div class="num">5479<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100003327" title="幻想乡的琐碎日常" target="_blank">幻想乡的琐碎日常</a></div>
                                <div class="info"><span>111.0万</span>︱<span>同人</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100027358" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170611/11-06-17223133-48148-100027358.jpg" alt="剑客立于音乃木坂">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/197603/avatar/thumb_880ba44c6e9beae0e0d9b871d6f06680.jpg" alt="">【轩辕龙夜】</div>
                                        <div class="n">只要我还站在她们的面前，我就不会让任何人伤害到她们！！By-剑羽这是属于我们的奇迹，属于我们的故事，但......为什么你不在了？By-μ's不.....从头到尾，我就不属于奇迹By·剑羽《金光布袋戏》和《lovelive》的混合型世界观，奇迹正在萌芽</div>
                                        <div class="num">1282<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100027358" title="剑客立于音乃木坂" target="_blank">剑客立于音乃木坂</a></div>
                                <div class="info"><span>44.2万</span>︱<span>同人</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100020640" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171207/07-12-17142329-48047-100020640.jpg" alt="灰烬使者的英灵之旅">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/949310/avatar/thumb_314f90b722e4b7b408ea91f851872601.jpg" alt="">【老疯子】</div>
                                        <div class="n">我于此庄严宣誓：我坚信人心向善，我坚信钢铁意志，我坚信浩气长存，我坚信圣光不灭。此誓此言，凿刻我心。惊我頽唐，指我迷茫。——————————圣骑士大领主，白兰顿.奥杜尔这是一个十五岁的少年，被丢入了艾泽拉斯的战火当中磨砺整个青年时期后成长为一名英灵，为了心中的信仰征战四方的故事。已经历世界：里番校园世界→刺客信条2→FateZero（HAPPYEND版）→加勒比海盗（魔改版）→东方幻想乡（本作品封面随剧情不定期更换，另，qq群号：433126231）</div>
                                        <div class="num">6395<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100020640" title="灰烬使者的英灵之旅" target="_blank">灰烬使者的英灵之旅</a></div>
                                <div class="info"><span>229.5万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100050080" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171117/17-11-17202958-40868-100050080.jpg" alt="兵王变身萝莉之后">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【鸽子诗人】</div>
                                        <div class="n">一代兵王白叶，死前说的最后一句话是来生想做个漂亮的小女孩，安安稳稳过日子。萝莉直播+校园传说（变百）小学部恶霸胖虎，据说有着不为人知的悲惨过去。初中部音乐教室的美丽传说，乐观的金发少女。高中部的摸鱼兄妹——川川子与秦喵喵。外号野兽先辈的二十四岁班主任。以及，炸鱼平台的一众逗逼主播……</div>
                                        <div class="num">1466<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100050080" title="兵王变身萝莉之后" target="_blank">兵王变身萝莉之后</a></div>
                                <div class="info"><span>17.3万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100046519" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171021/21-10-17104007-74270-100046519.jpg" alt="爆头学姐巴麻美">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-07/416480/avatar/thumb_81c13b121b7986bfd30aa9189b3e48f6.jpg" alt="">【想作死的聆曦】</div>
                                        <div class="n">保护自己不掉头最好的办法，就是让别人先被爆头---by巴●麻美本书又名《麻美学姐至今未尝一败》《一枪学姐》ver.1：巴麻美踩着右方之火，一枪爆头，然后转身手捧红茶，对成为废墟的罗马正教露出温婉如水的微笑。ver.2：巴麻美挑起时崎狂三下颚，罂粟般的笑容绽放，“真是学不乖的孩子呢。”ver.3：呃……没想好呢。总之，这是个病娇黑化的巴麻美在无限里的故事。◆◆◆◆◆◆◆◆老书《我的贞操不可能轻易狗带》目前一百五十万字连载中~</div>
                                        <div class="num">1455<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100046519" title="爆头学姐巴麻美" target="_blank">爆头学姐巴麻美</a></div>
                                <div class="info"><span>20.8万</span>︱<span>未来幻想</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100049415" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171210/10-12-17162921-54379-100049415.jpg" alt="变身植物娘之系统供应商">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2468946/avatar/thumb_99318b0fd5fa188c727504fb605dd6bd.jpg" alt="">【壁立千丈】</div>
                                        <div class="n">“这年头，难道连日植物犯法吗？”屈无忧表示自己不过忍不住亲了一下夜来香就被送往异界开始自己的冒险之旅。顺带被“赠送”了一个系统。“话说系统你有什么用啊？”“我可以制造系统？”“那好，你现在就给我做一个变性系统。”“为什么啊？”“鬼知道哪个杀千刀的把我传送到异界的同时顺带把我变成了植物娘！我现在要变回男性！”“变性系统本系统无法制作，其实变身美娇娘不好吗？身轻体柔不是吗？⊙ω⊙”PS:本书种田＋休闲＋系统＋变身文。群号：517641196</div>
                                        <div class="num">815<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100049415" title="变身植物娘之系统供应商" target="_blank">变身植物娘之系统供应商</a></div>
                                <div class="info"><span>9.8万</span>︱<span>异界幻想</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100030011" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170410/10-04-17124234-40767-100030011.jpg" alt="魔女先生的小小麻烦">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-07/544131/avatar/thumb_b08ded594c49151ba09743a36b2a42ce.jpg" alt="">【余与鱼】</div>
                                        <div class="n">呜啊——虽然是个男孩子，可也是魔女的卡米拉先生，今天也有着小小的烦恼。魔女前辈的关爱——如果没有充满戏弄就好了！公主殿下的宠爱——如果不穿女装也能得到这样的关注，一定很棒吧？就算是神明的眷恋，也有着各种意外的惊喜——总而言之，新的生活，新的旅途，魔女先生，今天也要元气满满哟！(第一卷黑历史，主角存在感有些稀薄，大家请耐心，有些是背景铺垫，不喜欢可以跳着看，反正vip章节挺远的)（九十多万字了，更新稳定，已肥可宰。）————————————————萌新扑街作，群号596622319，欢迎大家落脚！</div>
                                        <div class="num">4587<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100030011" title="魔女先生的小小麻烦" target="_blank">魔女先生的小小麻烦</a></div>
                                <div class="info"><span>117.4万</span>︱<span>异界幻想</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100035990" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170706/06-07-17202329-41390-100035990.jpg" alt="阴影小姐在游戏世界">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-07/310574/avatar/thumb_03b68f7f09639e72dbf55684c2cdc9e2.jpg" alt="">【一血酱】</div>
                                        <div class="n">一本非百合的变身文。阴影小姐摸了摸脖颈上的项圈，怀疑自己是一个假主角。一血新书，请求大家多投票支持。书友群是老群，看到群名不要怀疑自己是不是打错数字，573583988</div>
                                        <div class="num">2244<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100035990" title="阴影小姐在游戏世界" target="_blank">阴影小姐在游戏世界</a></div>
                                <div class="info"><span>94.3万</span>︱<span>游戏世界</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100050780" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171123/23-11-17120059-32196.jpg" alt="致四千年后">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/350207/avatar/thumb_9b398d78d40a5a7bd19416378da72411.jpg" alt="">【祈耳喵】</div>
                                        <div class="n"> 带着文明系统穿越到公元前十世纪，但幸运或不幸的是，他哪怕是死了也会再度重生到下一个时代，直至四千年后。 他从公元前活到中世纪，从文艺复兴活到工业革命，从近未来活到星际时代。他当过国王也当过先知，做过骑士也做过贵族，他是全能的艺术家、天才的发明家……  这是一部长达四千年的人类史诗——  “致四千年后的我们：”  “世界和平了吗？饥荒灭绝了吗？人们能碰到星星了吗？人类的寿命几何？地球的疆界多远？人类……还记得我们吗？”  ——发掘自地球时代·公元前十世纪，《所罗门·祈祷书》。</div>
                                        <div class="num">16676<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100050780" title="致四千年后" target="_blank">致四千年后</a></div>
                                <div class="info"><span>166.3万</span>︱<span>战争历史</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100048664" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171127/27-11-17214041-640-100048664.jpg" alt="离线状态无限血量">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【天野栗子】</div>
                                        <div class="n">“你就站着被她用新手剑砍了半小时？”“没错，简直是恶魔。”“你为什么不跑？”“说来惭愧，作为一个记者，我竟然跑不过她。”“可在线玩家中怎么搜不到这个人？”“肯定是开挂卡掉线了，我记得当时打她也不掉血！”“等级排行榜也没有这个人？”“说出来你可能不信，她只有1级……大佬，你可要替我报仇啊！”“没问题，我如今已经满级，还有一身神装，会怕一个低等级挂逼？”三小时后。“大佬，你怎么现在才回来？你说说话呀！怎么还一脸被玩坏了的表情！”“我……我被砍了整整一万刀……终于死掉复活回来了……呜呜~”PS：变百，变百，变百。</div>
                                        <div class="num">909<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100048664" title="离线状态无限血量" target="_blank">离线状态无限血量</a></div>
                                <div class="info"><span>17.1万</span>︱<span>游戏世界</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100027692" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170215/15-02-17161009-47399.jpg" alt="我的脑中有个好感度系统">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-02/1300016/avatar/thumb_a7c2293bfeaecda2231197e27f87c9ad.jpg" alt="">【土见凛】</div>
                                        <div class="n">意外穿越人生再次重启，而且来到了一个貌似是二次元的世界，并且一不小心就得到了一个烂大街的金手指我的人生终于要喜闻乐见的登上巅峰了吗？咦，有些不对啊，为什么别人的金手指那么厉害，我的这个金手指那么废柴啊，连系统精灵什么的都没有等等，好像不对哦，好感度提升到满值之后居然有福利…………</div>
                                        <div class="num">38410<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100027692" title="我的脑中有个好感度系统" target="_blank">我的脑中有个好感度系统</a></div>
                                <div class="info"><span>1,389.1万</span>︱<span>青春日常</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100049931" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171210/10-12-17003300-39999-100049931.jpg" alt="欠下三点五个亿的我只好靠援〇还债">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/97110/avatar/thumb_7c39424e660c8496255a6bf6c3091c6e.jpg" alt="">【蓝莹小草】</div>
                                        <div class="n">节操欠下如此之多，小⑨可该如何是好。PS.听说了一个，玄学PS，『萳兮小姐姐超漂亮！』(世界：『绝地求生』→『尸鬼』→『狼人杀』→『东方幻想乡』→『魔獣浄化少女』→『约会大作战』→『永远的7日之都』→『待定』)</div>
                                        <div class="num">2818<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100049931" title="欠下三点五个亿的我只好靠援〇还债" target="_blank">欠下三点五个亿的我只好靠援〇还债</a></div>
                                <div class="info"><span>50.6万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100049895" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171130/30-11-17154714-78534-100049895.jpg" alt="超次元收割">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【時日】</div>
                                        <div class="n">当荒耶宗莲见到直死的志贵，他将何去何从？双份的直死魔眼，双份的shiki，得到的将会是双倍的快乐吧。余弦远远看着三个shiki，摸了摸自己的良心，一本满足，我真是个好人啊。————————————————————联合农业发展实验学院。不断培育着一批又一批的收割者，谷神天的新血液。谷神无绝日，万世尽长夜。幻想的收割者，虚空的掠夺者。顶座的文明，立于涂炭之巅。巡猎无垠的虚空深渊，劫掠万千的幻想次元。————————————————————换封面啦！简介第二期，糟糕的异变型月展开中。求收藏推荐评论间帖，用满满的数据，让我来写满200万字吧。</div>
                                        <div class="num">251<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100049895" title="超次元收割" target="_blank">超次元收割</a></div>
                                <div class="info"><span>3.9万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100048803" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171207/07-12-17224010-61346-100048803.jpg" alt="东方现世录">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-11/199028/avatar/thumb_28e56ad8ab8a34ff1392f0f5acdc1834.png" alt="">【绯红骷髅】</div>
                                        <div class="n">《入梦醒是梦中人·平安京篇》（完）《战国魔人之卷·誓约篇》一度人生，一度梦。再次入梦之时。是樱色记忆？血之回忆？来自异国他乡的恶魔之子被牵扯其中的笨蛋修女在战国乱世是解救？还是破坏呢？------------乱入人物居多，但是我会让这一切合理化的</div>
                                        <div class="num">710<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100048803" title="东方现世录" target="_blank">东方现世录</a></div>
                                <div class="info"><span>13.1万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100049755" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171209/09-12-17202348-61408-100049755.jpg" alt="现役轮回者不留情">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-03/323901/avatar/thumb_61bcc6be96369bad8febb0a7a48109af.jpg" alt="">【未知数字α】</div>
                                        <div class="n">异常之人，异常之心。无论如何也无法丢掉的执念，是既不耀眼，也并非平凡。而在其间维持着均衡，于各个残酷的世界间挣扎求生的，就是坚持着绝对效率理性、名为宁不语的青年。“我可能喜欢上了你，还请你别喜欢我。”他脱力的说。“但我还欠你份人情，所以我更要去喜欢你……”晓美焰答。本书半虐半狗粮，清者见清，污者见污，萌新作者童叟不欺，致力于奉上最治愈的故事~（世界：魔法少女小圆进行中-刀剑神域未开始-我的英雄学院未开始-待定）</div>
                                        <div class="num">583<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100049755" title="现役轮回者不留情" target="_blank">现役轮回者不留情</a></div>
                                <div class="info"><span>7.7万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100042036" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170815/15-08-17161136-85350-100042036.jpg" alt="这里是星际争霸玩家">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【你为什么这么熟练啊】</div>
                                        <div class="n">请注意，敌人是白球带冲锋，巨像能对空，枪兵带双攻，飞龙骑脸不用怂的星际瞎子玩家！（书友群390371564，这里是不持表星际玩家）爱蒙宇宙大乱，神秘系统上线！修罗场，白色相扑，fff团，狗粮大军也。。。。。。（本书和《这里是战地玩家》，《这里是拆迁玩家》联动，已取得作者同意）-----------------简介与内容无关，仅供参考。--------</div>
                                        <div class="num">1826<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100042036" title="这里是星际争霸玩家" target="_blank">这里是星际争霸玩家</a></div>
                                <div class="info"><span>53.9万</span>︱<span>游戏世界</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="https://www.hbooker.com/book/100048641" target="_blank">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171107/07-11-17220657-98789-100048641.jpg" alt="远征">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-02/159855/avatar/thumb_b3ef36ef225a1bfaa565083964383696.jpg" alt="">【我恨我失踪的账号】</div>
                                        <div class="n">我不要简介了GG！</div>
                                        <div class="num">2146<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="https://www.hbooker.com/book/100048641" title="远征" target="_blank">远征</a></div>
                                <div class="info"><span>31.0万</span>︱<span>游戏世界</span></div>
                            </li>
                                                    </ul>
                    </div>
                
            </div>
            <!--mod-box end-->

            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100027611">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20170707025948752.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100040797">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20170929022115593.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100037552">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030728883.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>同人推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="https://www.hbooker.com/index/header_cate_list/tongren">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048120" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171205/05-12-17010424-56806-100048120.jpg" alt="我，女武神八重凛（八重傲天）！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/1418305/avatar/thumb_b4e53d2b37d9a60d83ff80f4cb744179.jpg" alt="">【凌小潇】</div>
                                            <div class="n">真正的八重凛已经死了，我只不过是她的复制品而已。一个用八重樱的基因制造出来的人造人而已。我不是很清楚我被制造出来的意义到底是什么。“为什么要来受死呢？”“女武神是脆弱的。”“律者也是。”ps：文中会直接出现对人物的特定称谓，非崩崩崩玩家可以先去科普一下游戏设定，当然并非崩崩崩玩家也能愉快的观看。</div>
                                            <div class="num">1643<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048120" title="我，女武神八重凛（八重傲天）！" target="_blank">我，女武神八重凛（八重傲天）！</a></div>
                                    <div class="info"><span>31.0万</span>︱<span>游戏世界</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100044964" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170911/11-09-17174758-78887.jpg" alt="晕船的我居然穿越到了海贼王">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-10/2370909/avatar/thumb_55d013c187feceeff9c4b1341014a1e4.jpg" alt="">【拖更的黑月桑】</div>
                                            <div class="n">本书又名《慵懒的我该怎么抱紧路飞的大腿》，《变成贫乳妹子的我该怎么在这个基本全是巨乳的海贼王里活下去？》，完全体书名为《慵懒且晕船的我居然变成了贫乳少女穿越到了全是巨乳的海贼王里该怎么抱紧路飞的大腿活下去？》！！哇！！这书名屌炸了！！简介都不用写了！！！真是太爽了！！！扣扣群号：467795153！！我都发在这里了！我就不信还没人来！备注：本文前三十章，剧情速度极快！建议没看过《海贼王》原作的人，先将前三百话漫画补完再看！避免一脸迷茫！！</div>
                                            <div class="num">2557<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100044964" title="晕船的我居然穿越到了海贼王" target="_blank">晕船的我居然穿越到了海贼王</a></div>
                                    <div class="info"><span>69.9万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100031506" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170703/03-07-17163550-6381-100031506.jpg" alt="东方龙鸣录">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-10/1661987/avatar/thumb_08b04bf8ddeabe76881c40eb8b302649.jpg" alt="">【星落莲殿】</div>
                                            <div class="n">这是一本名为东方龙鸣录，写作东方龙神事件簿，读作圣杯龙神的搞事日常的书。没错，就是龙神，那个建立了幻想乡就不管不顾的家伙……那啥，不要打我，谢谢合作，龙神大人。=======================p.s.：这是一本正经向的东方，再三声明，没有大多数东方同人里面那种轻松的画风，就是这样。p.s.s.：本书又名《东方人设补完计划》p.s.s.s.：欢迎各位来到属于我的幻想乡。</div>
                                            <div class="num">2450<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100031506" title="东方龙鸣录" target="_blank">东方龙鸣录</a></div>
                                    <div class="info"><span>54.7万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100000677" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c151127/27-11-15113158-70229.jpg" alt="一本好看的神奇宝贝同人">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2016-12/38650/avatar/thumb_7f7ce599495d208e2a346a131cb19157.jpg" alt="">【爱武小兵】</div>
                                            <div class="n">这两天突然觉得……可以说是良心发现，觉得这样子下去这本书真不是事……一个月就两更，一年就二十四更。这样子想完本真的得到天荒地老了……新开的三国貌似也不冷不热的，所以就想要不然先专心把这书搞定了？各位书友，咱们打个商量吧。这本书是同人，是没有订阅的，想有点收入就要进推荐榜前十。因此我的方案是这样子的：从即日起，每200推荐票、10月票或1000打赏就折合额外更新一章，每月封顶按月份计28到29章不等，二月算26、27章。咱不要你们每天都推荐，反正满200就算一章加更，加上原本的两更，只要大家投票，日更也是可以做到的。总之大家支持下，我也努力下，咱们一起努力把这书尽快完本吧！加更条件如下：每50张月票或5000打赏就再额外加更一章，这个就不搞什么封顶了，不过我最多只能做到一天双更就是了……书友群群号：298603024</div>
                                            <div class="num">13222<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100000677" title="一本好看的神奇宝贝同人" target="_blank">一本好看的神奇宝贝同人</a></div>
                                    <div class="info"><span>466.5万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100045482" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171119/19-11-17123913-33206-100045482.jpg" alt="我一个人就是一部春物！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-10/1670133/avatar/thumb_011c99c8b12613e9cb4dde90df3ba36b.jpg" alt="">【污然】</div>
                                            <div class="n">一穿三的穿越，从无名之人，同时变成比企谷八幡、由比滨结衣和雪之下雪乃。疑点重重的身份，不可描述的三体一魂。在当不成文抄公的世界里成为编辑，遇到了一群问题作者。最终改变了整个日轻世界的格局。曾用名《整个世界都是我的马甲》《我一个人就是一本春物》。</div>
                                            <div class="num">1567<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100045482" title="我一个人就是一部春物！" target="_blank">我一个人就是一部春物！</a></div>
                                    <div class="info"><span>54.7万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048592" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171031/31-10-17202727-53900.jpg" alt="我怎么可能谈恋爱！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-07/199434/avatar/thumb_370ee7fe6c92fc6b8af7436ec6d519e4.jpg" alt="">【某中二的写作之旅】</div>
                                            <div class="n">穿越过来，本以为可以过上好日子，结果父母不要自己，幸好有个好堂姐平冢静，对自己好！但突然拿自己当沙包是什么鬼！然后还被揍得得了女性恐惧症是什么鬼？结果自己自暴自弃觉得应该找个美少年作对象，只要长得可爱，就可以了！目标：彩加、千寻、近卫昂。自以为自己是个基佬，喜欢可爱的男孩子。可是不知不觉中，自己好像招惹了一大群女的，凉月奏、雪之下姐妹、霞之秋诗羽、可儿那有多、山田妖精……平冢逸面对这么多的少女，只想说：“你们不要过来，真的会死人的，而且死的就是我！”</div>
                                            <div class="num">1832<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048592" title="我怎么可能谈恋爱！" target="_blank">我怎么可能谈恋爱！</a></div>
                                    <div class="info"><span>48.5万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049759" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171115/15-11-17101140-61474.jpg" alt="今后的生命，请多指教">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-f.png" data-original="" alt="">【一盏新茶】</div>
                                            <div class="n">本书又名《在克苏鲁世界里呼唤爱》《跑团默示录》《无限边缘》《能看懂算我输》—在国内，边缘人群不仅包括少年犯、高利贷者、欺诈师、性工作者，也包括那些不被主流观念所理解、认同和接纳的人们。你们喜欢的百合、女装大佬实质上所属的同性恋者、异装者同样是广义边缘人群的一部分。当然，也包括扑街写手景采，和正当防卫杀死父亲的晏惊鸿。一场主神空间的无限游戏，一场克苏鲁跑团式的穿梭历险。边缘者的挣扎，照见人性的反思。地狱空荡荡，恶魔在人间。但也得益于此……“今后的生命，请多指教。”一个仅此而已的故事。</div>
                                            <div class="num">1129<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049759" title="今后的生命，请多指教" target="_blank">今后的生命，请多指教</a></div>
                                    <div class="info"><span>14.5万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100050742" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17192212-60841.jpg" alt="抱歉，我是内测玩家">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-05/478575/avatar/thumb_c0078e0205c5dc74b6648e129125ebb6.jpg" alt="">【克里斯蒂污娜】</div>
                                            <div class="n">身为玩家，大腿挂件肯定是少不了的。而身为一个拳打宙斯脚踢英灵的精英玩家，有什么风浪没有见过？你说EA是神器，那东西就在我仓库放着吃灰。你说奥林匹斯之剑很强，确实很强，强到根本不需要掏出来用。见过黑暗撕裂者吗？我把它当柺棍使，想当年被打断腿的日子里，每天出门拄一把黑暗撕裂者，星球意识都哭爹喊娘。直到有一天，我碰见了一个人。那是一个雨夜，我在时间神殿前输给一位灰发女人，她用惯性横批连斩，她的刀速很快，我只看见她有个一个A哥同款的兜帽。在我陷入黑暗之前，我听见她说......抱歉，我是内测玩家</div>
                                            <div class="num">2125<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100050742" title="抱歉，我是内测玩家" target="_blank">抱歉，我是内测玩家</a></div>
                                    <div class="info"><span>32.2万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049525" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171121/21-11-17212821-10350-100049525.jpg" alt="咸鱼龙傲天的无限">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-10/759603/avatar/thumb_78ee5af0d5ee6609e7ea2ddb48cb5c33.jpg" alt="">【寒霜】</div>
                                            <div class="n">没有钱啊！肯定要写啊！不写没有钱用，打工是不可能打工的，这辈子不可能打工的，做生意又不会做，就是写小说这种东西，才能维持的了生活这样子，我进欢乐书客感觉像回家一样，在欢乐书客里的感觉嘛，在欢乐书客里面比家里感觉好多了！！在家里一个人好无聊，没有友仔玩，也没有友女玩，进到欢乐书客里面个个都是人才，说话又好听，又会女装嘤嘤嘤的，超喜欢在这里的！！</div>
                                            <div class="num">283<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049525" title="咸鱼龙傲天的无限" target="_blank">咸鱼龙傲天的无限</a></div>
                                    <div class="info"><span>2.2万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049937" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171130/30-11-17091305-1814-100049937.jpg" alt="我所攻略的未来，被重叠了">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img/19975/avatar/thumb_bb4f0ad55a854a9a894056428c6f4e1e.jpg" alt="">【緋夜笑】</div>
                                            <div class="n">我，吴诚，是一位时空秩序维护者。我的工作是负责修正被扭曲的世界线。做为退休的奖励，选择在日本重生至17岁，本来打算就这样当一个普通高中生，悠闲的度过一生。但就在这个时候，身边的女性突然多了起来。为什么突然多一个干妹妹，还被父母如此放心的送到日本这边由我来照顾?为什么同桌每次上课的时候都要拿她的黑丝长腿蹭我的脚?为什么隔壁家突然搬来一个没什么存在感，却总是在不经意的时候撞见她?白、霞之丘诗羽、加藤惠……还有越来越多的女性闯入他安逸的生活“为什么……明明是我先的，不管是被他所拯救也好，喜欢上他也好，明明是我先的，为什么有这么多的碧池在跟我抢哥哥。”“闭嘴!!是我先的”xn总之这是个无数条世界线被重叠后交织出来的白学未来书友群：600936678欢迎加入水群和讨论剧情求月票求推荐票求打赏~~~</div>
                                            <div class="num">17083<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049937" title="我所攻略的未来，被重叠了" target="_blank">我所攻略的未来，被重叠了</a></div>
                                    <div class="info"><span>222.3万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100043515" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171018/18-10-17184416-66274-100043515.jpg" alt="女圣骑士的FGO之旅">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-02/791225/avatar/thumb_e87517040fd9fa8eeee19fb4969edfe0.jpg" alt="">【芝士炸鸡巨无霸】</div>
                                            <div class="n">(说实在话，前面写的我自己都有点看不下去（趴））（大约是七十章之前建议没有毒抗的人跳过。）（后面至少比前面好上一些吧（趴）就一些）简介一：顾炎璃带着圣骑士小姐姐的技能来到FGO世界，脚踩魔神王，拳打混沌恶的故事。（不存在的）简介二：顾炎璃穿越到游戏世界，最终逆天改命大开后宫的故事。（全是假的）简介三：一个狗头人在迦勒底中摸鱼的悠哉日子。（实际上就是这样）简介四：只知晓前面一点剧情，拥有女圣职者技能的顾炎璃，来到了人理被烧却时期的迦勒底，结识众多的英灵，与他们在战斗的同时也在普通的的生活下去的轻松治愈的故事。（想要写的东西）（PS.作者小学生文笔，求各位dalao放过！厚颜无耻的求收藏推荐QAQ）（顺便宣传一下群：496312623欢迎来闲聊！）</div>
                                            <div class="num">1742<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100043515" title="女圣骑士的FGO之旅" target="_blank">女圣骑士的FGO之旅</a></div>
                                    <div class="info"><span>47.4万</span>︱<span>游戏世界</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048003" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171022/22-10-17163147-48708.jpg" alt="致力于退役的我为什么还要干回老本行？">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【rinyumi】</div>
                                            <div class="n">我，白罗，三十年前为了妹子选择去当兵。陆军有可爱的战术人形小姐姐；海军有可爱的舰娘小姐姐；空军有可爱的空战姬小姐姐然而我却去了猛男如云的国土战略局当了三十年的苦力。我不干了！我要退休！我要在夏威夷最舒服的沙滩上泡最好的小姐姐！！！！！这是一个讲述致力于退休国土战略局特工一边翘班一边谈恋爱的故事......大概......</div>
                                            <div class="num">1866<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048003" title="致力于退役的我为什么还要干回老本行？" target="_blank">致力于退役的我为什么还要干回老本行？</a></div>
                                    <div class="info"><span>37.6万</span>︱<span>未来幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048595" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171211/11-12-17152050-922-100048595.jpg" alt="我想要条好船">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-11/101600/avatar/thumb_bd11908daae0051a939f094642a9ff27.jpg" alt="">【大林子】</div>
                                            <div class="n">给奥罗金帝国卖过命，新伊甸里跑过腿，血战的时候划过水。现在的洛基只想给自己建艘船当狗窝，再找一群船员到处浪。但是，为什么身边的过期萝莉越来越多？新手上路求收藏反叛的鲁鲁修→上古卷轴5→VBF·改</div>
                                            <div class="num">205<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048595" title="我想要条好船" target="_blank">我想要条好船</a></div>
                                    <div class="info"><span>4.8万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048671" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171205/05-12-17223047-68134-100048671.jpg" alt="海贼世界的CPX">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【醉虾】</div>
                                            <div class="n">主角雷班托·杜肯在海贼世界，寻找自己的道路。本书无后宫，主角不知道剧情，80%原创，无系统有恶魔果实</div>
                                            <div class="num">70<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048671" title="海贼世界的CPX" target="_blank">海贼世界的CPX</a></div>
                                    <div class="info"><span>1.8万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100050061" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171126/26-11-17195050-56069-100050061.jpg" alt="提亚马特的主神空间之旅">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/155858/avatar/thumb_6ef11aa71b5f28e98a6cfceb2c5a2879.jpg" alt="">【诸神眷恋】</div>
                                            <div class="n">Aaaaaaa——总之，提妈超可爱！</div>
                                            <div class="num">5558<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100050061" title="提亚马特的主神空间之旅" target="_blank">提亚马特的主神空间之旅</a></div>
                                    <div class="info"><span>113.9万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100050491" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171119/19-11-17220022-29743.jpg" alt="型月里番女主是大佬">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2562010/avatar/thumb_f574b9b96fc34157c97e28810c501da6.jpg" alt="">【银枫落叶】</div>
                                            <div class="n">我，白萌萌，一直许愿做男孩子，结果穿了四次还是妹。嗯，她一定是上辈子抽卡把欧气用完了吧。既然这样，干脆跳楼得了。“砰”天台的门突然被打开，一个气质柔弱十分可爱的少年站在门口，喘着气看着不远处的女孩。白萌萌转过身，摊开了双手，闭上了眼睛，在少年呆滞的目光中身体向后倒去。脑子里最后的想法是，二分之一的机率，我就不信我是非酋。</div>
                                            <div class="num">1251<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100050491" title="型月里番女主是大佬" target="_blank">型月里番女主是大佬</a></div>
                                    <div class="info"><span>25.1万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048559" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171129/29-11-17130820-13345-100048559.jpg" alt="我的生活不可能是后宫GAME！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【占扑者】</div>
                                            <div class="n">知道吗？有些时候，外挂只能是多余的东西......所谓的穿越到十年以后的异能力，除了能让自己明白十年之后的妻子是谁，疯狂的流失营养以外还能做到什么？什么？十年后的我大难临头？什么？十年后的我一无所有？什么？十年后的我成为了种马？这特么都什么鬼未来，我决定了，要改变这样的未来，创造幸福的人生！现在，开始改变——“我宁愿十年以后在一无所知的情况下被柴刀，也不愿意像这样，被全世界的亚人盯紧下面，我不是种马，不渴望sex，美女们，请自重！！！”——by·某个幸福结局当中的吕奉仙【请帮忙投一投推荐票，萝莉控在这里谢过了】【渴望ing】【白天第一次更新结束后，下午五点前票票过三十，七点再更新一章】</div>
                                            <div class="num">6255<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048559" title="我的生活不可能是后宫GAME！" target="_blank">我的生活不可能是后宫GAME！</a></div>
                                    <div class="info"><span>99.6万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048663" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171115/15-11-17123247-98320-100048663.jpg" alt="黄漫老师龙之介">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-06/1359867/avatar/thumb_280971a1fd8224e37925a517db07d38e.jpg" alt="">【越前殿下】</div>
                                            <div class="n">恋爱的酸臭味……</div>
                                            <div class="num">520<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048663" title="黄漫老师龙之介" target="_blank">黄漫老师龙之介</a></div>
                                    <div class="info"><span>7.7万</span>︱<span>青春日常</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->


            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100037374">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030611104.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100030130">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030139448.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100043954">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171110024251580.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>男生推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="https://www.hbooker.com/index/header_cate_list/male">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048661" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171101/01-11-17164210-53941.jpg" alt="老师，我不想结婚">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-03/1291625/avatar/thumb_35d5c4ad4e3a2b700983fa1b6bf62f79.jpg" alt="">【一天不吃肉就要死】</div>
                                            <div class="n">本来已经创造了一个美好的国家，没想到，人类是如此的贪婪，为了欲望，他们甚至蚕食同类。常树原本放弃了一切，只想做一个普通人，做一个普通的高中生...但那群人的触手又一次伸了过来</div>
                                            <div class="num">3792<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048661" title="老师，我不想结婚" target="_blank">老师，我不想结婚</a></div>
                                    <div class="info"><span>105.5万</span>︱<span>超现实都市</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049302" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171108/08-11-17215952-27294.jpg" alt="狂赌之渊 绫">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2227830/avatar/thumb_a725a914a23d8a6c5d6ea007cf19e232.jpg" alt="">【花海】</div>
                                            <div class="n">私立百花王学园，一座拥有122年历史的财政界名校。这所名门学校并不会以学习或者体育出众而衡量学生，而是以培养学生战术策略、读心术及关机时刻掌握胜负能力，即赌博能力为阶级划分的学校。只是，这次的百花王学园，迎来的不仅仅是一条蛇。而是两条。本书讲述的便是超高校级的赌徒忘记了自己的姓名，穿越到狂赌之渊的故事。</div>
                                            <div class="num">195<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049302" title="狂赌之渊 绫" target="_blank">狂赌之渊 绫</a></div>
                                    <div class="info"><span>4.0万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100050573" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17184752-36801-100050573.jpg" alt="另一个艾克斯奥特曼">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【狮子红猎户座】</div>
                                            <div class="n">这是另一个世界的艾克斯奥特曼，不仅有超越形态，还有你意向不到的其他的形态。而且，这个艾克斯还会穿越到在平成年代的各个奥特曼的世界里。不仅有原创的新形态，还有原创的怪兽，原创的最终BOSS，你，真的不来一发（一看）吗？</div>
                                            <div class="num">357<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100050573" title="另一个艾克斯奥特曼" target="_blank">另一个艾克斯奥特曼</a></div>
                                    <div class="info"><span>8.0万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100036245" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170618/18-06-17222553-78165-100036245.jpg" alt="德意志玫瑰">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/151413/avatar/thumb_aa26a09792e838c6650ab1978ff4caf1.jpg" alt="">【绿色草药】</div>
                                            <div class="n">呼啸而来的斯图卡，狂飙而至的喷火。残酷至极的奥马哈海滩，闷热无比的阿拉曼战场。前世屌丝大学生的他，却穿越成为一名德军女军官。PS.群号71045303</div>
                                            <div class="num">2812<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100036245" title="德意志玫瑰" target="_blank">德意志玫瑰</a></div>
                                    <div class="info"><span>69.6万</span>︱<span>战争历史</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048717" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171113/13-11-17193206-83619-100048717.jpg" alt="角色扮演游戏">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【白魔法师卡尔max】</div>
                                            <div class="n">第二卷简介：糟糕！现实中遭遇生化危机，而且我被咬了。咦？怎么没事？【契约成立，你现在已经是我的所有物了。你的权利和义务如下……】……目前进度：第一卷，普通的角色扮演游戏，金发平胸萝莉遭遇山间神隐，大佬降临拯救世界。（已完结）第二卷，大平与小麦的僵尸世界大战（进行中）计划：第三卷，宅男与邪神穿越游戏世界，兴致缺缺的救世之旅。第四卷，星际佣兵被全面通缉，念能力者的宇宙大逃亡。</div>
                                            <div class="num">96<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048717" title="角色扮演游戏" target="_blank">角色扮演游戏</a></div>
                                    <div class="info"><span>1.9万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049569" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171112/12-11-17173020-78957.jpg" alt="我在没有异性恋的世界里搬砖还要伐魔物">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【甜瓜】</div>
                                            <div class="n">乔治，一个出生在同性恋是正道，异性恋是异端的世界里的普通男孩，喜欢女孩子的乔治一直以来都备受煎熬。每天都要辛苦劳作的他面对世界灾难的来临被迫前往前线搬砖，关于他和他和他我也不知道有没有她（笑）的故事就此展开</div>
                                            <div class="num">109<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049569" title="我在没有异性恋的世界里搬砖还要伐魔物" target="_blank">我在没有异性恋的世界里搬砖还要伐魔物</a></div>
                                    <div class="info"><span>3.7万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100050816" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171211/11-12-17161913-6804-100050816.jpg" alt="推土机的忏悔之旅">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【万俟万四】</div>
                                            <div class="n">正常版：一个曾经梦想着成为推土机的男人，在经历战火的洗礼和感情的创伤后最终回到了家乡，决定从此做个普通人。热血版：封平——我有一刀四十米斩断伤痛，我有一刀洞爷湖守护羁绊。文艺版：寒士平妖录。----------------------------------------------------------------求收藏，求推荐，各种求……</div>
                                            <div class="num">326<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100050816" title="推土机的忏悔之旅" target="_blank">推土机的忏悔之旅</a></div>
                                    <div class="info"><span>5.8万</span>︱<span>未来幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100046365" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171005/05-10-17065241-8706-100046365.jpg" alt="我的青春日常不可能有这么bug">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【檀黎斗】</div>
                                            <div class="n">“芥川君，这是怎么回事？”霞之丘诗羽拿着自己那黑历史的笔记本说着。芥川翼真的很想死啊！那充满满满的黑历史的笔记本，应该被我烧了才对。“我才是世界的露露？我是卡密哒！”看上去普通又正常的青春日常，对于芥川翼来说却是bug的，还有个某高中生、猩猩混入。</div>
                                            <div class="num">467<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100046365" title="我的青春日常不可能有这么bug" target="_blank">我的青春日常不可能有这么bug</a></div>
                                    <div class="info"><span>18.5万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100047666" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171109/09-11-17002727-27790-100047666.jpg" alt="请让我安安静静的打游戏！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-05/620687/avatar/thumb_bbaf8ce655fde8e710e4c2819c71a50b.jpg" alt="">【八云蓝九条尾巴】</div>
                                            <div class="n">这是讲述某个家里蹲玩家的生活琐事与欢乐日常的故事。而这本小说所想要叙说的，是关于游戏——这门第九艺术，它在过去与现在，所一直都在带给我们的那些感动。警告：本书内描述的游戏，内含大量原创内容与魔改，请勿对号入座。</div>
                                            <div class="num">1268<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100047666" title="请让我安安静静的打游戏！" target="_blank">请让我安安静静的打游戏！</a></div>
                                    <div class="info"><span>23.2万</span>︱<span>游戏世界</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100024177" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170221/21-02-17124235-86672-100024177.jpg" alt="这个阿拉德有问题">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-02/1318121/avatar/thumb_8049c9e80e192d57f7e489a7cbb226a9.jpg" alt="">【禊】</div>
                                            <div class="n">据说哥布林是与史莱姆齐名的新手怪…“呸，你见过身高两米的新手怪吗？”少年摆了摆手。据说元素师是四大元素的主宰者，各个都是强大的魔法师…“口胡，我见过的就是一个菜鸡！”少年耸了耸肩。据说精灵是生命悠长，智慧过人的种族…“呵，这倒是真的，所以能他们想要找乐子的时候对被盯上的人来说简直就是灾难…”少年竖起了一根中指。据说系统是穿越者最好的帮手之一…“淦，我的那个就是个坑货废柴！”少年开始跳脚。“我怀疑我穿了个假越，为什么画风全都不对？这个阿拉德一定有问题！”封面忘了哪找的，不知道侵权没，如果侵了联系我我换掉。</div>
                                            <div class="num">1109<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100024177" title="这个阿拉德有问题" target="_blank">这个阿拉德有问题</a></div>
                                    <div class="info"><span>33.8万</span>︱<span>游戏世界</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100000834" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c151201/01-12-15191631-78456.jpg" alt="海贼王之反派">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img/47441/avatar/thumb_054be2b495c402e95ad7034ca0228cb3.jpg" alt="">【软妹的黄瓜】</div>
                                            <div class="n">富强！民主！文明！和谐！自由！平等！公正！法制！爱国！敬业！诚信！奶子！噫，混进了什么奇怪的东西。是“友善”啦！一路披荆斩棘走到现在的尤涅若这才发现自己的梦想已不再是小小的海贼王，而是重铸世界，亲手创造出一个自己理想中的社会。海军、海贼、革民军、世界政府、世界贵族、草帽，一切阻拦自己前进步伐的人都是阶级敌人。反派是14年的书，前3卷都是15年前的内容，预计160W-250W字完本，本书按照海贼王的世界设定写作和推剧情，还算严谨，没大漏洞。单女主，东海出发，不跟船，会死人。QQ群【尤涅若海贼团】149353400</div>
                                            <div class="num">2925<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100000834" title="海贼王之反派" target="_blank">海贼王之反派</a></div>
                                    <div class="info"><span>82.9万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100019095" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160920/20-09-16133903-90451.jpg" alt="中二病也要玩食戟">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【黑咖啡不加牛奶】</div>
                                            <div class="n">樱花飞舞的季节中，远月迎来了开学。“第一是我的，你们只能去抢第二。”绘里奈自信的宣言着。“我要在这所学校中登上顶点!”BY野心勃勃的幸平创真。“哈哈，你们的野心都太小了!我要帮助我弟弟战胜毁天灭地的面包师，所以我是最强的!”东小米自信的发表了自己的中二言论。这是一个自以为穿越到日式面包王中的穿越者再远月奋斗的故事。</div>
                                            <div class="num">1196<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100019095" title="中二病也要玩食戟" target="_blank">中二病也要玩食戟</a></div>
                                    <div class="info"><span>24.2万</span>︱<span>同人</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->


            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100048520">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030503427.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100049838">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030709641.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100046345">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030523731.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>女生推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="https://www.hbooker.com/index/header_cate_list/female">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100045193" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170914/14-09-17210835-54954.jpg" alt="咕哒子的圣杯战争">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【挨揍的会长】</div>
                                            <div class="n">“前辈，出现特异点，前后十年，迦勒底已完全消失在历史之中！有人在故意抹消我们的存在！”“……可以找到线索吗？”“没……不过……前……前辈！”“怎么了？那么慌张？”“那……那个是十年前的前辈吗？卡哇伊……”</div>
                                            <div class="num">731<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100045193" title="咕哒子的圣杯战争" target="_blank">咕哒子的圣杯战争</a></div>
                                    <div class="info"><span>21.4万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100047748" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171115/15-11-17111436-86359-100047748.jpg" alt="我，屈原，变成了矢泽妮可">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2495218/avatar/thumb_4bd2dac675f02bbdceb48c6c36348be3.jpg" alt="">【道生印】</div>
                                            <div class="n">简介内的内容会在第二卷出现！第二卷内容会在12月中旬开启！还望诸位大佬收藏！一代文豪屈原过世后，意外地在重生矢泽妮可身上。后偶遇重生在其他少年少女的王司徒，诸葛亮，杜甫。神给了他们重生的机会！同时还给了他们四个艰巨的任务！只有四人完成了任务，他们才能获得新的身体，获得真正意义上的重生，被他们占领躯体的少年少女也将再次重生！一切回归正常。王司徒（空条承太郎）：“老夫一个算命先生，怎么打的过DIO那种家伙”诸葛亮（夏目贵志）：“老贼，不是还有我吗？我会呼风唤雨、草船借箭……”屈原（矢泽妮可）：“我有天问护体，离骚对敌，又能召来亡魂大军……”杜甫（御坂美琴）：“我有唐诗一千四百首！”王司徒（空条承太郎）：“mmp，老夫不跟你们玩了。”</div>
                                            <div class="num">536<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100047748" title="我，屈原，变成了矢泽妮可" target="_blank">我，屈原，变成了矢泽妮可</a></div>
                                    <div class="info"><span>12.5万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049757" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171207/07-12-17002532-72133-100049757.jpg" alt="她改变了驱逐舰">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2129346/avatar/thumb_e7803b7579e4f75fe3e2b0050e346e6a.jpg" alt="">【第一黑v国际】</div>
                                            <div class="n">建造池用驱逐公式歪出了战列舰，怎么办？在线等，挺急的！什么？！原来维内托本来就是驱逐舰，怪不得能在驱逐公式里出货。这本书讲的就是带着系统的维内托，在一个个动漫世界里冒险的故事。第一个世界战舰少女R（有较大魔改）第二个世界预定是刀剑神域（有乱入角色）第三个世界待定</div>
                                            <div class="num">1294<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049757" title="她改变了驱逐舰" target="_blank">她改变了驱逐舰</a></div>
                                    <div class="info"><span>19.2万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100047448" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171014/14-10-17005901-38939.jpg" alt="来到异界的我当起了月之女神">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-10/148122/avatar/thumb_17a46420c0426fa96c24d730e0fb7589.jpg" alt="">【最萌之剑】</div>
                                            <div class="n">穿越了，变身了，还被钦定为月之女神，什么，异界没有月亮？作为不缺钱的二小姐，宅一辈子的愿望终于实现了吗？只是，坑爹啊，异界没有网络啊！伪高冷的月亮女神在异界建立网络的日常----每日4K，悄悄放群493973427-----新人第一本书，请多多收藏和推荐吧。有任何不适或者bug，请直接指出，每条书评和吐槽我都会看。</div>
                                            <div class="num">3016<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100047448" title="来到异界的我当起了月之女神" target="_blank">来到异界的我当起了月之女神</a></div>
                                    <div class="info"><span>44.0万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049242" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171129/29-11-17131931-58393-100049242.jpg" alt="被选中的蔚蓝海洋">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-10/1622083/avatar/thumb_442b5f21b9c249ee4f363c3a796375a3.jpg" alt="">【孤帆去远行】</div>
                                            <div class="n">这是一场没有未来的战争，这也是一次希望渺茫的拯救。呼啸的炮弹、疾驰的战舰、飞舞的战机、悄无声息的鱼雷。由舰娘们掌控着的钢铁巨兽之间最原始的厮杀，最无情的碰撞。最黑暗的时代，最蔚蓝的大海，而我，一个普通的人类？在这里扮演着什么角色？又携带着怎样的使命降临的呢……？楚陌：话说，为啥我这里的船都是驱逐舰呢？等等，vv！别打脸！————本人萌新一名，玩了舰r后喜欢上了这些可爱的舰娘们，当然也沉迷于那些历史上的辉煌海战，但是历史实在太少，我就想通过我的文笔描绘出一个死宅心中最爽，最刺激的海战~当然萌萌哒的舰娘也是少不了滴~</div>
                                            <div class="num">159<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049242" title="被选中的蔚蓝海洋" target="_blank">被选中的蔚蓝海洋</a></div>
                                    <div class="info"><span>2.2万</span>︱<span>战争历史</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049392" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171113/13-11-17170638-55035-100049392.jpg" alt="女尊之这里的女人一点都不矜持！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【三鲜馒头】</div>
                                            <div class="n">肖易一朝穿越，一不小心进入女尊世界。以为美滋滋的生活就要来了，哪想到……某女A（冷脸邪笑）：肖美人，今天本宫翻的是你的牌子。某女B（温柔抿嘴）：我今天这身衣服好看吗，好看的话，夫君你替我脱了可好？某女C（大眼睛眨呀眨）：主人，我们一起睡觉好不好？某女……救命！我要回地球！</div>
                                            <div class="num">557<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049392" title="女尊之这里的女人一点都不矜持！" target="_blank">女尊之这里的女人一点都不矜持！</a></div>
                                    <div class="info"><span>9.8万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100045076" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170919/19-09-17094356-46484-100045076.jpg" alt="重生少女不会抄书">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/65610/avatar/thumb_2c41912500ac022a47a55d9d0d574d9f.jpg" alt="">【音透湖】</div>
                                            <div class="n">尹桃重生了，重生后的她成了一只青春美少女——嗯，虽然她前世也是一只青春美少女。还是一只爱好女的青春美少女。她钻了学校的空子，成功在大学和三个后宫同居——女生和女生住一起是当然的事。为了生计以及打发太过幸福的时间，她只好无可奈何地提起笔头，然后发现，在这个本应该是文抄公装逼打脸的剧本里，她居然画风清奇地，把自己抄成了一个天才——神经病女作家。呃——都说天下文章一大抄，看你会抄不会抄，可能尹桃就是最不会抄的那一类。尹桃根本不是什么扇动翅膀的蝴蝶，而是给世界带来更多热闹欢笑和爱的哥斯拉。</div>
                                            <div class="num">139<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100045076" title="重生少女不会抄书" target="_blank">重生少女不会抄书</a></div>
                                    <div class="info"><span>2.8万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100047128" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171210/10-12-17190932-89629-100047128.jpg" alt="拜托了，制作人先生">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-10/160386/avatar/thumb_7e07b59302611a71f20d33b6f0afed5b.jpg" alt="">【TaihoZwei】</div>
                                            <div class="n">“少女，我看你很有天赋，要不要和我签下契约，成为一名偶像呢？”每个女孩的心中都有一个梦，渴望着成为童话故事中的灰姑娘，在魔法光辉的照耀下，站在舞台中央。但是，魔法总有消散的一天。当午夜十二点的钟声响起，施加在灰姑娘身上的魔法还能持续下去吗？所以……“拜托了，制作人先生，请帮助我成为最棒的偶像吧！”【偶像大师同人，灰姑娘开局，中期预定乱入本家。】【萌新作者，请多多包涵，每天保底一更。建了个小群87215759，欢迎来提醒作者去码字……】</div>
                                            <div class="num">873<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100047128" title="拜托了，制作人先生" target="_blank">拜托了，制作人先生</a></div>
                                    <div class="info"><span>16.2万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049666" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171117/17-11-17171030-64779-100049666.jpg" alt="变身堀北铃音在日本当阴阳师">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【汪星人】</div>
                                            <div class="n">千奇百怪的妖怪，凶神恶煞的恶鬼总是隐藏在各个角落，或善，或恶！善可扬，恶当除！重生为女高中生的天才阴阳师堀北铃音，就是专门治退这些污秽的人！……【新书发布，每日更新，欢迎收藏养肥！】【一板正经的原创剧情文，作者君只是喜欢堀北铃音套用了人物名字，内容并不影响阅读！】</div>
                                            <div class="num">787<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049666" title="变身堀北铃音在日本当阴阳师" target="_blank">变身堀北铃音在日本当阴阳师</a></div>
                                    <div class="info"><span>12.0万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100046478" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171001/01-10-17222102-73920.jpg" alt="崩坏相簿">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-02/57877/avatar/thumb_cad16d3953399c981934657a9b5fedfa.jpg" alt="">【幻想乡路人】</div>
                                            <div class="n">那日，神明开始了世界的终焉。少年盯着一张照片，面如死灰。而少女无力回天。最后神明出现在他面前，语气温婉却透着哀凉。“带上这个，希望，这次你可以挽救这一切吧。”</div>
                                            <div class="num">1645<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100046478" title="崩坏相簿" target="_blank">崩坏相簿</a></div>
                                    <div class="info"><span>44.1万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100036171" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170926/26-09-17223858-85865-100036171.jpg" alt="一拳巫女">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【纸片猫】</div>
                                            <div class="n">拳打吸血鬼，脚踢境界妖。作为一名巫女，绮玉既不会法术，也不会符咒。“退治那些家伙，用拳头就够了吧！”有时候，她也会接到奇怪的委托——“所以说和哥斯拉战斗什么的给我去找奥特曼啊！！”</div>
                                            <div class="num">829<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100036171" title="一拳巫女" target="_blank">一拳巫女</a></div>
                                    <div class="info"><span>24.9万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100050298" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171118/18-11-17213345-16246-100050298.jpg" alt="士官长，你也综漫？">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/2606827/avatar/thumb_94d8a6bb14dcca4ef1c1b671c9a469b2.jpg" alt="">【五年高考三年模拟】</div>
                                            <div class="n">当第三次世界大战爆发，学园都市上演魔法与科学的交响乐。当轮回的转盘重新开启，名为圣杯的战争再次奏鸣。当坚固的城墙被打破，巨人张开血盆大口人类的残肢断臂交杂在一起。“欢迎您的加入，轮回者117号。”天空中划过一道炽色的轨迹，令人牙酸的金属摩擦声响起。屹立在空降舱碎片中央的，是一个名为战场之神的战士，他手持着武器，盔甲上折射着远方的天空。“这里是117号，我已双脚着地。”——————这是一个孤独的战士，在无限的轮回中寻找自己的Ai的故事。仅此而已。</div>
                                            <div class="num">1394<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100050298" title="士官长，你也综漫？" target="_blank">士官长，你也综漫？</a></div>
                                    <div class="info"><span>22.6万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->

            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100043473">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030744355.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100046092">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030439683.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="https://www.hbooker.com/book/100038507">
                                    <img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171208030543478.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>BOSS任性推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="https://www.hbooker.com/book_list/">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list1 J_BookList">
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100050042" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171209/09-12-17232417-32055-100050042.jpg" alt="次元幻想者">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/2553745/avatar/thumb_931eaee86e801074a38acc71794e46ed.jpg" alt="">【神无月】</div>
                                            <div class="n">“引导小精灵惨遭玩家煲汤，这背后究竟是人性的冷漠，还是道德的沦丧。”“鸽了一百年的游戏终于问世，这背后的开发商都是怪物吗？”本书又名《我的穿越都很有问题》，《抱歉，我有个废系统》本书的剧情和设定全是魔改或半魔改，不要随意代入原著。</div>
                                            <div class="num">179<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100050042" title="次元幻想者" target="_blank">次元幻想者</a></div>
                                    <div class="info"><span>2.7万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100048494" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171123/23-11-17124126-43444-100048494.jpg" alt="魔法咕咕伊莉雅">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【池里的鱼】</div>
                                            <div class="n">变身成自己亲手画出来的人物，这样的展开你幻想过吗？青年变身了。他仔细一看，他发现自己居然变成了自己制作出来的翼人版本的伊莉雅？咕莉亚！？这是一只叫作咕莉亚的翼人穿越到了异世界之后的故事。</div>
                                            <div class="num">539<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100048494" title="魔法咕咕伊莉雅" target="_blank">魔法咕咕伊莉雅</a></div>
                                    <div class="info"><span>11.1万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100039413" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170722/22-07-17131622-83459-100039413.jpg" alt="技术宅拯救世界">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/79867/avatar/thumb_945c1f1e2c73d0a19b8de67ddd26e504.jpg" alt="">【萌萌哒宇宙】</div>
                                            <div class="n">一夜之间面前出现系统，而且任务是让我穿女装跳《极乐净土》还要直播，怎么办？在线等，挺急的！这是一个技术宅拯救世界的故事，不过拯救……“饮め!芸术は爆発だ”我们的口号是：“威力无极限！！！”</div>
                                            <div class="num">3302<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100039413" title="技术宅拯救世界" target="_blank">技术宅拯救世界</a></div>
                                    <div class="info"><span>162.5万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100049483" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171201/01-12-17121747-61679-100049483.jpg" alt="无限作死之旅">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2565438/avatar/thumb_90466ae154e12bafc13428ab50c02e65.jpg" alt="">【夜弹月下琴】</div>
                                            <div class="n">无厘头搞笑文，目前世界：开挂阿三欢乐多。听最嗨的歌，日最野的狗，开最快的车，住最好的医院，打最贵的石膏，玩最炫的轮椅，睡最好的棺材，挖最深的坑，埋最好的土，烧最厚的纸，长最高的坟头草。无限流，原创世界，欢迎看腻了动漫和影视穿越的朋友。作者多年飙车老司机，种子爆仓，脑洞超出银河系。</div>
                                            <div class="num">760<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100049483" title="无限作死之旅" target="_blank">无限作死之旅</a></div>
                                    <div class="info"><span>14.0万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100046249" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171001/01-10-17180427-50207-100046249.jpg" alt="我，新世界之主">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-10/665598/avatar/thumb_3504ab20191b2fc3bde5f49f5bd935d8.jpg" alt="">【二次元平民】</div>
                                            <div class="n">作者君决定，大修第一第二章，所以读者千万不要点击第一、二卷，内容干巴巴很毒点少。。。。。作者君建议从第三卷学园都市卷开始阅读。。。。学园都市卷就是封面人物的活跃之地。学园都市三大明面守备力量——警备员、风纪委员、多啦军团。学园都市两大暗处力量——多啦军团、暗部。学园都市唯一一位天生绝对能力者LV6？？？。学园都市七大超能力者——一方通行、未元物质、超电磁炮、原子崩坏、心理掌控、质量爆散、空间移动。学园都市都市传说。。。学园都市的真相究竟是什么？为什么有领先外界一百年的科技啊？</div>
                                            <div class="num">2718<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100046249" title="我，新世界之主" target="_blank">我，新世界之主</a></div>
                                    <div class="info"><span>82.7万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="https://www.hbooker.com/book/100016042" target="_blank">
                                        <img class="lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160805/05-08-16011216-64932.jpg" alt="我只想刷个成就">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="https://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-12/548678/avatar/thumb_c76fc31431c76e9a7c332eae0988857f.jpg" alt="">【薪王柴薪】</div>
                                            <div class="n">当灰烬从长眠中再度苏醒后，他发现一切都变了——不止是世界，还有系统。“圣杯——成为圣杯战争的胜利者”嗯，这个成就很正常。“艹狐狂人——你懂的。”我不懂啊！我真的不懂啊！“完美补魔——解锁所有的姿势。”灰烬：……excuseme？简而言之，就是作为成就党的灰烬因为系统抽风而让其他人鸡飞狗跳的故事。</div>
                                            <div class="num">30641<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="https://www.hbooker.com/book/100016042" title="我只想刷个成就" target="_blank">我只想刷个成就</a></div>
                                    <div class="info"><span>1,025.4万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->

            <!--mod-box start-->
                        <div class="mod-box ly-mt60">
                <div class="mod-tit1 ly-mr30">
					<h3><i></i>最近更新小说</h3>
                    <a class="ly-fr" href="https://www.hbooker.com/book_list" target="_blank">查看更多 &gt;</a>
                </div>

                <div class="mod-body">
                    <div class="book-list-table-wrap">
                        <table class="ly-mt30 book-list-table" width="100%">
                            <tr>
                                <th><span>序号</span></th>
                                <th><span>小说类别</span></th>
                                <th><span>小说书名/小说章节</span></th>
                                <th><span>字数</span></th>
                                <th><span>小说作者</span></th>
                                <th>更新时间</th>
                            </tr>
                                                                                                <tr>
                                        <td><p class="code center">1</p></td>
                                        <td><p class="type center">【同人】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100044182" title="风吹草地见幽香" target="_blank">风吹草地见幽香</a><span>鼻炎发作，去医院，停更几天鼻炎发作，去医院，停更几天</span></p></td>
                                        <td><p class="num center">172770</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/520796" target="_blank">风见幽狼</a></p></td>
                                        <td><p class="date center">2017-12-12 11:23:27</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">2</p></td>
                                        <td><p class="type center">【游戏世界】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100034104" title="为这无趣的异界献上ACG革命" target="_blank">为这无趣的异界献上ACG革命</a><span>第三百三十七章 最后的轮回</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">1115859</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/522112" target="_blank">企鹅老爷</a></p></td>
                                        <td><p class="date center">2017-12-12 11:22:59</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">3</p></td>
                                        <td><p class="type center">【神秘未知】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100054090" title="命运恶作剧正" target="_blank">命运恶作剧正</a><span>第06章：大家都在算计什么</span></p></td>
                                        <td><p class="num center">13094</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2702095" target="_blank">v命运v</a></p></td>
                                        <td><p class="date center">2017-12-12 11:22:54</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">4</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100053530" title="Alter小姐的奇妙冒险" target="_blank">Alter小姐的奇妙冒险</a><span>您的好友决斗王已上线</span></p></td>
                                        <td><p class="num center">27702</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/542040" target="_blank">清华折刀xy</a></p></td>
                                        <td><p class="date center">2017-12-12 11:22:04</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">5</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100048940" title="我，守护者" target="_blank">我，守护者</a><span>005.刀剑神域</span></p></td>
                                        <td><p class="num center">7561</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2201405" target="_blank">七宁道长</a></p></td>
                                        <td><p class="date center">2017-12-12 11:20:02</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">6</p></td>
                                        <td><p class="type center">【同人】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100054021" title="被伊莉雅收养的士郎" target="_blank">被伊莉雅收养的士郎</a><span>序章</span></p></td>
                                        <td><p class="num center">1118</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/1618516" target="_blank">你的名字：不知道，滚</a></p></td>
                                        <td><p class="date center">2017-12-12 11:20:00</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">7</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100054219" title="这么不正经的小说真的有人会看么" target="_blank">这么不正经的小说真的有人会看么</a><span>第二章：死寂</span></p></td>
                                        <td><p class="num center">6654</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2703217" target="_blank">咸皇</a></p></td>
                                        <td><p class="date center">2017-12-12 11:19:51</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">8</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100035488" title="合成超兽奇美拉" target="_blank">合成超兽奇美拉</a><span>第三章:对三</span></p></td>
                                        <td><p class="num center">62917</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/200975" target="_blank">圣诞毛玉</a></p></td>
                                        <td><p class="date center">2017-12-12 11:16:41</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">9</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100050049" title="第二十代哈桑加藤惠" target="_blank">第二十代哈桑加藤惠</a><span>第十七章 老年人们</span></p></td>
                                        <td><p class="num center">34794</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/314797" target="_blank">肠胃康爱好者</a></p></td>
                                        <td><p class="date center">2017-12-12 11:16:16</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">10</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100049817" title="欢迎来到哈桑事务所" target="_blank">欢迎来到哈桑事务所</a><span>29·紫藤宫的目标</span></p></td>
                                        <td><p class="num center">54937</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/647888" target="_blank">李宅大人</a></p></td>
                                        <td><p class="date center">2017-12-12 11:15:26</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">11</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100051080" title="精灵使的幻想" target="_blank">精灵使的幻想</a><span>第十七章丛雾切 下</span></p></td>
                                        <td><p class="num center">43167</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2399040" target="_blank">夜喵</a></p></td>
                                        <td><p class="date center">2017-12-12 11:14:59</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">12</p></td>
                                        <td><p class="type center">【同人】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100046654" title="藤原妹红的养成手册" target="_blank">藤原妹红的养成手册</a><span>第四章  天使！又见秒杀！</span></p></td>
                                        <td><p class="num center">5263</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2448741" target="_blank">永远亭的辉夜</a></p></td>
                                        <td><p class="date center">2017-12-12 11:13:33</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">13</p></td>
                                        <td><p class="type center">【游戏世界】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100044854" title="战士在那一角患过伤风" target="_blank">战士在那一角患过伤风</a><span>第二十四章 小棱！我想你！</span></p></td>
                                        <td><p class="num center">183936</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/118791" target="_blank">恋恋看不见</a></p></td>
                                        <td><p class="date center">2017-12-12 11:13:13</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">14</p></td>
                                        <td><p class="type center">【超现实都市】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100052578" title="三重变身穿越的我想回家" target="_blank">三重变身穿越的我想回家</a><span>第三章 我们来对一下口供吧</span></p></td>
                                        <td><p class="num center">6333</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/140262" target="_blank">绝望之主</a></p></td>
                                        <td><p class="date center">2017-12-12 11:13:10</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">15</p></td>
                                        <td><p class="type center">【女频】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100054222" title="苏景元的古代日常" target="_blank">苏景元的古代日常</a><span>第1章.神马情况啊？</span></p></td>
                                        <td><p class="num center">2061</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2702671" target="_blank">梵凡</a></p></td>
                                        <td><p class="date center">2017-12-12 11:13:04</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">16</p></td>
                                        <td><p class="type center">【同人】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100019769" title="一千年前/后的我竟然是男/女生" target="_blank">一千年前/后的我竟然是男/女生</a><span>第五十章我有一句MMP不知.......唔唔唔！</span></p></td>
                                        <td><p class="num center">323200</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/796684" target="_blank">最最最</a></p></td>
                                        <td><p class="date center">2017-12-12 11:12:06</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">17</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100052305" title="我差不多是个废吸魂鬼了" target="_blank">我差不多是个废吸魂鬼了</a><span>第十五章 吃余烬是PK的前提条件</span></p></td>
                                        <td><p class="num center">35871</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/231071" target="_blank">飞翔的科莫多</a></p></td>
                                        <td><p class="date center">2017-12-12 11:12:03</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">18</p></td>
                                        <td><p class="type center">【超现实都市】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100024019" title="任务在线" target="_blank">任务在线</a><span>第六百零六章：不断上升</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">1259744</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/834540" target="_blank">A少</a></p></td>
                                        <td><p class="date center">2017-12-12 11:10:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">19</p></td>
                                        <td><p class="type center">【青春日常】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100051723" title="重生一魂双体" target="_blank">重生一魂双体</a><span>11.自习中</span></p></td>
                                        <td><p class="num center">28466</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/51515" target="_blank">月神舞</a></p></td>
                                        <td><p class="date center">2017-12-12 11:07:39</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">20</p></td>
                                        <td><p class="type center">【青春日常】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100046221" title="这是你点的轻松日常吗？" target="_blank">这是你点的轻松日常吗？</a><span>第五章：说白了都是问题儿童</span></p></td>
                                        <td><p class="num center">128363</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/640677" target="_blank">一只水獭呀</a></p></td>
                                        <td><p class="date center">2017-12-12 11:07:04</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">21</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100051150" title="带着不明神恩转生闯荡异世界" target="_blank">带着不明神恩转生闯荡异世界</a><span>31这就是烂尾了</span></p></td>
                                        <td><p class="num center">126214</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2604726" target="_blank">御宅族东南枝</a></p></td>
                                        <td><p class="date center">2017-12-12 11:06:32</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">22</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100049058" title="佩丝特的穿越之旅" target="_blank">佩丝特的穿越之旅</a><span>第二十四章 被揭开的伤疤</span></p></td>
                                        <td><p class="num center">85002</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2438049" target="_blank">此之彼方</a></p></td>
                                        <td><p class="date center">2017-12-12 11:06:14</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">23</p></td>
                                        <td><p class="type center">【游戏世界】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100052920" title="终末与绝望与98k" target="_blank">终末与绝望与98k</a><span>第十八章 前奏</span></p></td>
                                        <td><p class="num center">29130</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/642333" target="_blank">好想咬一口月亮</a></p></td>
                                        <td><p class="date center">2017-12-12 11:05:22</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">24</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100048560" title="由我来当救世主肯定没有问题" target="_blank">由我来当救世主肯定没有问题</a><span>第九十二章 赫斯缇雅大人天下无双</span></p></td>
                                        <td><p class="num center">208751</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/1735297" target="_blank">提亚斯蜜林</a></p></td>
                                        <td><p class="date center">2017-12-12 11:04:59</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">25</p></td>
                                        <td><p class="type center">【神秘未知】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100049244" title="誓做污客最长" target="_blank">誓做污客最长</a><span>近代词人逸事</span></p></td>
                                        <td><p class="num center">6703760</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/1577202" target="_blank">吟虫</a></p></td>
                                        <td><p class="date center">2017-12-12 11:04:31</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">26</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100038850" title="我只是一名路过的不死人" target="_blank">我只是一名路过的不死人</a><span>第二百零八章 逆熵议会</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">488494</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/497869" target="_blank">充当背景的龙套君</a></p></td>
                                        <td><p class="date center">2017-12-12 11:00:28</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">27</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100053482" title="不告白你能变强吗？" target="_blank">不告白你能变强吗？</a><span>004，再遇</span></p></td>
                                        <td><p class="num center">10034</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/1724633" target="_blank">永远十五岁的四季</a></p></td>
                                        <td><p class="date center">2017-12-12 11:00:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">28</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100050866" title="JOJO的无限冒险" target="_blank">JOJO的无限冒险</a><span>第三十七章 挽歌</span></p></td>
                                        <td><p class="num center">77884</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/2628498" target="_blank">醋溜阳春面</a></p></td>
                                        <td><p class="date center">2017-12-12 11:00:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">29</p></td>
                                        <td><p class="type center">【游戏世界】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100042030" title="村长小姐不迷茫" target="_blank">村长小姐不迷茫</a><span>134 布布安定的暴走</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">372329</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/148156" target="_blank">罪歌子</a></p></td>
                                        <td><p class="date center">2017-12-12 11:00:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">30</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="https://www.hbooker.com/book/100053206" title="吾名息吹暴风" target="_blank">吾名息吹暴风</a><span>第三章 终末</span></p></td>
                                        <td><p class="num center">20647</p></td>
                                        <td><p class="author center"><a href="https://www.hbooker.com/reader/1795574" target="_blank">wind</a></p></td>
                                        <td><p class="date center">2017-12-12 10:57:32</p></td>
                                    </tr>
                                                                                    </table>
                    </div>
                </div>
            </div>
                        <!--mod-box end-->
        </div>
        <div class="ly-side index-side">
            <!-- 公告 begin -->
            <div class="big-event">
                                                                                        <div><a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://www.hbooker.com/resources/imagesactivity/zhengwen_nov_banner.jpg" alt="活动"></a></div>
                                                                                                <div><a href="https://www.hbooker.com/index/fuli" target="_blank"><img class="lazyload" src="https://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_notice/20170601112204377.jpg" alt=""></a></div>
                                                                        </div>
            <!-- 公告 end -->
            <div class="recomm-tit ly-mt30">
                <h4>精选荣誉榜单</h4>
            </div>

                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">主编强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 精挑细选</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100038671" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170719/19-07-17155944-511-100038671.jpg" alt="">
                                <span class="num">69.4万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【未来幻想】变身二次元角色拯救世界吧</p>
                                <p class="author">正在旅行的穿越者</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050129" target="_blank">
                                    <span class="num">1.7万</span><i class="icon-top icon-top2">2</i>【异界幻想】穿越之后的我成了救世之神                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100049620" target="_blank">
                                    <span class="num">1.6万</span><i class="icon-top icon-top3">3</i>【游戏世界】少女安娜不需要眼泪                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100049886" target="_blank">
                                    <span class="num">11.2万</span><i class="icon-top">4</i>【动漫穿越】无限，王座之下                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100037286" target="_blank">
                                    <span class="num">0.8万</span><i class="icon-top">5</i>【异界幻想】圣堂游记                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100035235" target="_blank">
                                    <span class="num">1,137.9万</span><i class="icon-top">6</i>【战争历史】1860战记                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100051225" target="_blank">
                                    <span class="num">1.9万</span><i class="icon-top">7</i>【游戏世界】卷宗学者的诸界之旅                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100029012" target="_blank">
                                    <span class="num">42.8万</span><i class="icon-top">8</i>【未来幻想】苍蓝的战舰少女之现代战争                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100043064" target="_blank">
                                    <span class="num">13.4万</span><i class="icon-top">9</i>【同人】我的青春恋爱物语如今变成了青春恋爱喜剧！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100031461" target="_blank">
                                    <span class="num">237.3万</span><i class="icon-top">10</i>【同人】我的哥哥是轻小说男主                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">宅文强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 宅力无边</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100045605" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170928/28-09-17112737-92275-100045605.jpg" alt="">
                                <span class="num">526.1万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【青春日常】我的二次元很有问题</p>
                                <p class="author">我姐是幽香</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100044547" target="_blank">
                                    <span class="num">597.9万</span><i class="icon-top icon-top2">2</i>【动漫穿越】多元宇宙帝国崛起                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100044256" target="_blank">
                                    <span class="num">325.2万</span><i class="icon-top icon-top3">3</i>【动漫穿越】我们，卫宫一家，都是英灵                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100044876" target="_blank">
                                    <span class="num">444.6万</span><i class="icon-top">4</i>【动漫穿越】我彩虹小队就要教教你怎么拯救世界！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048490" target="_blank">
                                    <span class="num">10.1万</span><i class="icon-top">5</i>【超现实都市】简单的异能使用方式                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100047848" target="_blank">
                                    <span class="num">7.6万</span><i class="icon-top">6</i>【异界幻想】反派25仔的自我修养                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100047417" target="_blank">
                                    <span class="num">24.3万</span><i class="icon-top">7</i>【未来幻想】黑衣仓鼠                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100019194" target="_blank">
                                    <span class="num">108.4万</span><i class="icon-top">8</i>【青春日常】变身文青女神                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100045051" target="_blank">
                                    <span class="num">24.7万</span><i class="icon-top">9</i>【同人】我？亡灵死骑？不，我是圣骑士                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100045987" target="_blank">
                                    <span class="num">46.7万</span><i class="icon-top">10</i>【同人】崩坏末世                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">同人强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 我要的次元</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100049809" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171126/26-11-17105103-71368-100049809.jpg" alt="">
                                <span class="num">64.6万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【动漫穿越】吾有妹，名武藏</p>
                                <p class="author">sariel</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100002476" target="_blank">
                                    <span class="num">125.4万</span><i class="icon-top icon-top2">2</i>【动漫穿越】用传销的方式在二次元搞和谐主义                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100046408" target="_blank">
                                    <span class="num">31.3万</span><i class="icon-top icon-top3">3</i>【动漫穿越】无限中的我却过着限制级生涯是否搞错了什么                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048630" target="_blank">
                                    <span class="num">12.6万</span><i class="icon-top">4</i>【超现实都市】我，妹妹，兽娘，修罗场！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100046341" target="_blank">
                                    <span class="num">36.3万</span><i class="icon-top">5</i>【超现实都市】小莫的爱情不死于吾王安排相亲                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100021663" target="_blank">
                                    <span class="num">112.0万</span><i class="icon-top">6</i>【未来幻想】私就是超级机器人                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100046598" target="_blank">
                                    <span class="num">25.7万</span><i class="icon-top">7</i>【动漫穿越】神奇宝贝之炎の祭礼                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100047280" target="_blank">
                                    <span class="num">41.6万</span><i class="icon-top">8</i>【游戏世界】薪柴与他的伙伴们                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100031172" target="_blank">
                                    <span class="num">170.0万</span><i class="icon-top">9</i>【同人】巨人长夜                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100047823" target="_blank">
                                    <span class="num">30.1万</span><i class="icon-top">10</i>【同人】某圣杯的圣杯战争                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">男生强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100046362" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170930/30-09-17221920-74169.jpg" alt="">
                                <span class="num">12.5万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【同人】天才麻将少女有珠山篇</p>
                                <p class="author">佐仓心爱</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100050152" target="_blank">
                                    <span class="num">3.7万</span><i class="icon-top icon-top2">2</i>【动漫穿越】穿越失败的救世主                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100048793" target="_blank">
                                    <span class="num">8.9万</span><i class="icon-top icon-top3">3</i>【女频】伏魔大萨满                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100050228" target="_blank">
                                    <span class="num">20.4万</span><i class="icon-top">4</i>【动漫穿越】我！穿越者！无敌！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100030856" target="_blank">
                                    <span class="num">125.4万</span><i class="icon-top">5</i>【异界幻想】爱丽丝梦游异境                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048104" target="_blank">
                                    <span class="num">12.1万</span><i class="icon-top">6</i>【异界幻想】请叫我时崎狂三                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100046148" target="_blank">
                                    <span class="num">206.6万</span><i class="icon-top">7</i>【游戏世界】给我惠某人一个面子                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100041993" target="_blank">
                                    <span class="num">210.3万</span><i class="icon-top">8</i>【游戏世界】我，一只牧师                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100045613" target="_blank">
                                    <span class="num">148.4万</span><i class="icon-top">9</i>【游戏世界】从山贼开始的boss之路                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100044556" target="_blank">
                                    <span class="num">21.9万</span><i class="icon-top">10</i>【同人】狐妖小红娘之东方幻想乡                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">女生强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100046094" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170929/29-09-17221644-79387-100046094.jpg" alt="">
                                <span class="num">139.8万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【青春日常】我家干物妹总是被穿越</p>
                                <p class="author">醉久</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100049622" target="_blank">
                                    <span class="num">8.7万</span><i class="icon-top icon-top2">2</i>【动漫穿越】弑神者的打工日常                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100049951" target="_blank">
                                    <span class="num">4.8万</span><i class="icon-top icon-top3">3</i>【动漫穿越】他以为是穿越者                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100049350" target="_blank">
                                    <span class="num">10.4万</span><i class="icon-top">4</i>【动漫穿越】博丽灵梦的无限恐怖                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100051908" target="_blank">
                                    <span class="num">3.9万</span><i class="icon-top">5</i>【异界幻想】就让我深渊来教你怎么吃土                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048176" target="_blank">
                                    <span class="num">15.9万</span><i class="icon-top">6</i>【异界幻想】冥王萝莉伊莉雅绝不是变太！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100023863" target="_blank">
                                    <span class="num">852.5万</span><i class="icon-top">7</i>【青春日常】幻想乡与V家之间的无限修罗场                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100049872" target="_blank">
                                    <span class="num">11.5万</span><i class="icon-top">8</i>【动漫穿越】喜欢捉弄人的霞之丘小姐                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048120" target="_blank">
                                    <span class="num">31.0万</span><i class="icon-top">9</i>【游戏世界】我，女武神八重凛（八重傲天）！                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100048254" target="_blank">
                                    <span class="num">61.7万</span><i class="icon-top">10</i>【同人】崩坏3：镰刀娘战记                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">往期BOSS推荐</div>
                    <div class="sub-tit"><i>TOP 10</i> 总裁的秘密书库</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="https://www.hbooker.com/book/100025156" target="_blank">
                                <img class="img lazyload" src="https://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170208/08-02-17181652-54910-100025156.jpg" alt="">
                                <span class="num">936.0万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【青春日常】才不是天才偶像少女</p>
                                <p class="author">正义凛然</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="https://www.hbooker.com/book/100010823" target="_blank">
                                    <span class="num">35.1万</span><i class="icon-top icon-top2">2</i>【动漫穿越】神姬Online                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="https://www.hbooker.com/book/100050353" target="_blank">
                                    <span class="num">46.5万</span><i class="icon-top icon-top3">3</i>【动漫穿越】材木座的青春恋爱物语可能有问题。                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100049944" target="_blank">
                                    <span class="num">23.3万</span><i class="icon-top">4</i>【动漫穿越】其实我是名侦探                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100046507" target="_blank">
                                    <span class="num">7.2万</span><i class="icon-top">5</i>【超现实都市】失格者的混乱人生                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100039188" target="_blank">
                                    <span class="num">15.0万</span><i class="icon-top">6</i>【超现实都市】阿萨辛不死于柴刀                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100042109" target="_blank">
                                    <span class="num">896.1万</span><i class="icon-top">7</i>【游戏世界】手游大玩家                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100034473" target="_blank">
                                    <span class="num">52.6万</span><i class="icon-top">8</i>【未来幻想】咸鱼战记                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100021919" target="_blank">
                                    <span class="num">1,113.3万</span><i class="icon-top">9</i>【游戏世界】网游之羽化                                </a>
                            </li>
                                                    <li>
                                <a href="https://www.hbooker.com/book/100022236" target="_blank">
                                    <span class="num">1,207.2万</span><i class="icon-top">10</i>【青春日常】我的二次元绝对不正常                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <!--recomm-list end-->
                    </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
    
    
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>