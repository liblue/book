<?php $__env->startSection('content'); ?>   
    
<div class="container bbs-painter">
    <div class="ly-wrap">

      
  <div class="breakcrumb">
            <a href="<?php echo e(url('/')); ?>">首页</a> &gt;
            论坛</a>
          
          
        </div>
  

        <div class="ly-mt45 clearfix">
            <div class="ly-main">
                <div class="bbs-table">
                    <div class="bbs-publish">
                    	                        <a href="<?php echo e('forum/create'); ?>" class="btn btn-blue">发帖</a>
                    </div>
                    <table class="book-list-table ly-mt20" width="100%">
                        <tr>
                            <th colspan="4">
                                <span class="bname">综合讨论区</span>
                            </th>
                        </tr>
                        <tr>
                            <th width="600">
									<span class="type">
																			<a href="http://www.hbooker.com/bbs/zonghe/all" class="selected" >全部</a>
										<a href="http://www.hbooker.com/bbs/zonghe/time"  >最新</a>
										<a href="http://www.hbooker.com/bbs/zonghe/hot"  >热门</a>
																		</span>
                            </th>
                            <th width="150"><span>作者</span></th>
                            <th width="150"><span>回复/查看</span></th>
                        
                        </tr>
                        
                        <?php foreach($data as $k=>$v): ?>
                        
                                                    <tr>
                                <td>
                                    <p class="title">
                                        <i class="up"></i>
                                        
                                        <?php if($k < 3): ?>
                                        <a class="hot-topic" href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                                                                <?php echo e($v->title); ?></a>  
                                       <?php else: ?>
                                       <a href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank">
                                                                                <?php echo e($v->title); ?></a>  
                                          <?php endif; ?>
                                    </p>
                                </td>
                                <td>
                                    <div class="author clearfix">
                                        <div class="img ly-fl">
						<img class="lazyload" alt="" data-original="https://avatar.kuangxiangit.com/novel/img-2018-01/668727/avatar/thumb_23e24663c3bd6ab8bec6a79386f0c084.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png">
                                            <div class='medal medal_3_40'></div>                                        </div>
                                        <div class="ly-fl">
                                            <span><?php echo e($v->poster); ?></span>
                                            <br>
                                            <?php echo e(date('m-d h:i:s',$v->date)); ?>                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p class="num1">
                                        <span>15</span> / 70                                    </p>
                                </td>
                            
                            </tr>
                            
                          
                                                   
                                   <?php endforeach; ?>                     
                                                    
                                                    
                                                 
                                                   
                                                   
                                            </table>

                    <div class="pagination" style="margin-right:0">
                        <div class="PageIn">
                            <ul>
                                <li class='selected'><a href='javascript:'>1</a></li><li><a href="javascript:change_bbs_page(2)" data-ci-pagination-page="2">2</a></li><li><a href="javascript:change_bbs_page(3)" data-ci-pagination-page="3">3</a></li><li><a href="javascript:change_bbs_page(2)" data-ci-pagination-page="2" rel="next">>></a></li>                                <li class="pageSkip">
                                    <span class="ly-fl">跳转到:</span>
                                    <input type="text" value="1" class="ly-fl skipBox" name="directPageNum" id="directPageNum">
                                    <span class="ly-fl">/<i>8535</i>页</span>
                                    <a onclick="" href="javascript:void(0);" class="ly-fl pageSkipQd">确认</a>
                                </li>
                                <input type="hidden" value="1" name="curr_page" id="curr_page">
                                <input type="hidden" value="http://www.hbooker.com/bbs/zonghe/all" name="curr_url" id="curr_url">
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <div class="ly-side">
                <div class="mod-box bbs-side">
                    <div class="mod-tit1">
                        <h3><i></i><span class="selected">本区信息</span></h3>
                    </div>
                    <div class="mod-bd ly-mt30 box-shadow">
                        <div class="manager-box clearfix">
                            <h3 class="tit">本区管理员</h3>
                                                            <div class="img ly-fl">
                                    <a target="_blank" href="http://www.hbooker.com/bookshelf/reader_book_shelf/281494"><img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-07/281494/avatar/thumb_8e4015f36f2f99be46057e825b2759f8.png" src="http://www.hbooker.com/resources/images/avatar-default-m.png"></a>
                                </div>
                                <div class="cnt">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/reader_book_shelf/281494" target="_blank">刀客骑兵</a></p>
                                    <p class="level">LV.6 出类拔萃</p>
                                </div>
                                                            <div class="img ly-fl">
                                    <a target="_blank" href="http://www.hbooker.com/bookshelf/reader_book_shelf/782671"><img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2017-04/782671/avatar/thumb_b89296bbf83dc1e6a45bd6b3f4149786.jpg" src="http://www.hbooker.com/resources/images/avatar-default-m.png"></a>
                                </div>
                                <div class="cnt">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/reader_book_shelf/782671" target="_blank">机器人EVA</a></p>
                                    <p class="level">LV.12 笑傲江湖</p>
                                </div>
                                                            <div class="img ly-fl">
                                    <a target="_blank" href="http://www.hbooker.com/bookshelf/reader_book_shelf/47613"><img class="lazyload" data-original="https://avatar.kuangxiangit.com/novel/img-2016-08/47613/avatar/thumb_c404c7d41bbf55c629122c17528761e9.jpg" src="http://www.hbooker.com/resources/images/avatar-default-f.png"></a>
                                </div>
                                <div class="cnt">
                                    <p class="name"><a href="http://www.hbooker.com/bookshelf/reader_book_shelf/47613" target="_blank">天才Wo酱米修号</a></p>
                                    <p class="level">LV.12 笑傲江湖</p>
                                </div>
                            <!--                            <p class="msg">今日发帖：<span>500</span></p>-->
<!--                            <p class="msg">今日回复：<span>500</span></p>-->
<!--                            <p class="msg">当前在线：<span>500人</span></p>-->
<!--                            <a class="apply-for-manager" href="javascript:;">申请管理员</a>-->
                        </div>
                    </div>
                </div>
                <div class="mod-box bbs-side ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i><span class="selected">本区最热话题</span></h3>
                    </div>
                    <div class="mod-bd ly-mt30 box-shadow">
                        <ul>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/439358" target="_blank"><i class="top">1</i>之前的水楼没了</a>
                                </li>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/32159" target="_blank"><i class="top">2</i>小贴士：IOS、安卓充值未到账怎么办？</a>
                                </li>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/69104" target="_blank"><i class="top">3</i>水区好无聊啊</a>
                                </li>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/141705" target="_blank"><i >4</i>萤草水贴</a>
                                </li>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/74418" target="_blank"><i >5</i>霸区(ಡωಡ)</a>
                                </li>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/141214" target="_blank"><i >6</i>大家都去次饭惹</a>
                                </li>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/464253" target="_blank"><i >7</i>因某人要求</a>
                                </li>
                                                            <li>
                                    <a href="http://www.hbooker.com/bbs/99260" target="_blank"><i >8</i>自创了一个水楼规则（我看你们能水到几楼）</a>
                                </li>
                                                    </ul>
                    </div>
                </div>
                <div class="mod-box bbs-side ly-mt45">
                    <div class="mod-tit1">
                        <h3><i></i><span class="selected">最新话题</span></h3>
                    </div>
                    <div class="mod-bd ly-mt30 box-shadow">
                        <ul>
                             <?php foreach($data as $k=>$v): ?>
                            
                                                            <li>
                                    <a href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>" target="_blank"><i class="top"><?php echo e($k+1); ?></i><?php echo e($v->title); ?></a>
                                </li>
                                
                                   <?php endforeach; ?>  
                                                            
                                                    </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.ziyuan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>