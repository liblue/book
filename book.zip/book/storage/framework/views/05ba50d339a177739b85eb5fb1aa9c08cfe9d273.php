
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>阅读社区</title>


    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/style.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/response.css')); ?>"/>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('bootstrap/jquery.js')); ?>"></script>
        <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
        HB.book = {book_id: "", chapter_id: "", up_reader_id: "", is_paid: 0};
        HB.userinfo = {reader_id: 0,tel_num: '',license: '',redis_license: '', reader_name: '""', avatar_thumb_url: '""', vip_lv: ""};
        HB.urlinfo ={redirect:'https://www.hbooker.com/reader/modify_mobile?redirect=https%3A%2F%2Fwww.hbooker.com%2F'};        
    </script>
    <script type="text/javascript" src="<?php echo e(asset('home/js/initResponse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('home/js/base.js')); ?>"></script>
    <!--<script type="text/javascript" src="<?php echo e(asset('home/js/dialog-min.js')); ?>"></script>-->

    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

</head>
<body>

 <!-- 当前是章节阅读页 -->
 <!-- 当前是漫画阅读页 -->
<div id="bdstat" style="display: none"></div>

<div class="nav-top">
    <div class="ly-wrap">
        <ul class="login-info ly-fl">
                           <!--  <li><a class="wb" href="#" rel="nofollow"></a></li> -->
<!--                <li><a class="qq" href="#" rel="nofollow"></a></li>-->
                <li><a class="qq" href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow"></a></li>
				<!--<li><a class="weixin" href="https://www.hbooker.com/signup/weixin_login" rel="nofollow"></a></li> -->
               <?php if(Session::has('user_name')): ?>
          <input type="hidden" value="cunzai"  id="denglu">
             
                    <li class="userinfo">
                    <a class="avatar" href="<?php echo e(url('user')); ?>" target="_selfk" rel="nofollow">
                        <img class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">
                    </a>
                    <i><a href="<?php echo e(url('user')); ?>" target="_blank" rel="nofollow"> <?php echo e(Session::get('user_nickname')); ?> </a> </i>
                    <a href="<?php echo e(url('logout')); ?>" class="logout" rel="nofollow">[退出]</a>
                    <span>经验等级：LV.1书中过客</span>
                    
                    
                  
                </li>         
                
        <?php else: ?>
                 <input type="hidden" value="meiyou"  id="denglu">
                 <li><a href="<?php echo e(url('login')); ?>" rel="nofollow">登录</a></li>
                
                
                <li class="line">|</li>
                <li><a href="<?php echo e('register'); ?>" rel="nofollow">注册</a></li>
                
                
           <?php endif; ?>
                    </ul>
           <?php if(Session::has('user_name')): ?>
         
<!--        <div class="nav-top-right ly-fr">
            <ul class="special ly-fl clearfix">
                <li class="recharge"><a href="https://www.hbooker.com/recharge/index"><i></i>充值中心</a></li>
                <li class="line">|</li>
                <li class="author"><a href="<?php echo e(url('au_manage')); ?>" target="_blank"><i></i>作者后台</a></li>
                <li class="line">|</li>
            </ul>
            <a class="app-download ly-fl" href="http://app.hbooker.com" target="_blank"><img src="" alt=""/></a>
            <div class="qr-code ly-fl">
                <a id="J_QrCode" href="javascript:;"><div><p>扫码下载客户端</p></div></a>
            </div>
        </div>-->
           <?php endif; ?>
    </div>
</div>

<!--  欢迎每日登录 领取推荐票 -->




<div class="header">
    <div class="ly-wrap header-inner">
  
    </div>
    <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
                
                     <?php if( $cate_name==='shouye'): ?>
           <li><a href="<?php echo e(url('/')); ?>"  >首页</a></li>
            <?php else: ?>
             <li><a href="<?php echo e(url('/')); ?>"  >首页</a></li>
           <?php endif; ?>
           <?php foreach($cate as $val): ?> 
              <?php if( $cate_name===$val->enname): ?>
           <li ><a href="<?php echo e(url('list/'.$val->enname)); ?>" ><?php echo e($val->name); ?></a></li>
           <?php else: ?>
              <li><a href="<?php echo e(url('list/'.$val->enname)); ?>" ><?php echo e($val->name); ?></a></li>
           <?php endif; ?>
             <?php endforeach; ?>
                <li><a href="<?php echo e(url('forum')); ?>" >论坛</a></li>
                <?php echo $__env->yieldContent('nav'); ?>
            </ul>
            <div class="ly-fr">
                <form class="search-form" action="<?php echo e(url('search')); ?>"  method="post">
                      <?php echo e(csrf_field()); ?>

                    <input name="keyword"  placeholder="搜索更多作品或作者" data-url="">
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>
    </div><!--container start-->
    
    
    
    
      <?php echo $__env->yieldContent('content'); ?>
    
    
       
    
    





<div class="footer">
    <div class="ly-wrap">
     
     
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
      
     <script>
         
      
         
         
         
         
function nav(obj){
    
   $(obj).siblings().children(":first").removeClass('selected');
   $(obj).children(":first").addClass('selected');
}
</script>
 
      
</body>
</html>