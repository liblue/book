<html>
    <head>
        
   
    </head>
    <body>
        
       <p style="text-indent: 2em; margin-top: 30px;">
系统将在 <span id="time">4</span> 秒钟后自动返回

如果未能跳转<a href="<?php echo e($url); ?>" title="点击访问">请点击</a>。
       
<input type="hidden" value="<?php echo e($url); ?>" id="url">
       
       
       </p>
       
       
       
       
<script type="text/javascript">  
    delayURL();    
    function delayURL() { 
        var delay = document.getElementById("time").innerHTML;
 var t = setTimeout("delayURL()", 1000);
        if (delay > 0) {
            delay--;
            document.getElementById("time").innerHTML = delay;
        } else {
     clearTimeout(t); 
     url=document.getElementById("url").value;
            window.location.href = url;
        }        
    } 
</script>
 
    </body>
    
</html>


