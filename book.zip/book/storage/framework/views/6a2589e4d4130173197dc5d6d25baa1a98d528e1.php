
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="332107236654575254534635167011671463757037317650747716" />
    <title>登录 - 欢乐书客</title>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <link rel="shortcut icon" type="image/x-icon" href=""/>
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/style.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/response.css')); ?>"/>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('bootstrap/jquery.js')); ?>"></script>
    <!--<script type="text/javascript" src="https://www.hbooker.com/resources/js/artDialog/6.0.4/dialog-min.js"></script>-->
<!--    <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
    </script>
	<script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>-->
     <script type="text/javascript" src="<?php echo e(asset('home/js/initResponse.js')); ?>"></script>
</head>
<body>
<script type="text/javascript">
    function initResponse(){var d,b,a=window.innerWidth||document.documentElement.clientWidth,g=navigator.userAgent.toLowerCase(),h=/(msie) ([\w.]+)/,f=h.exec(g),c;if(f!==null&&f[1]==="msie"){c=f[2];if(c==="8.0"||c==="7.0"||c==="6.0"){a=a+21}}document.body.style.width="";var e=(document.body.className&&document.body.className.indexOf("sw-list-")!=-1);if(a>=1280||e){d=1}else{d=0}switch(d){case 1:b="s-layout-1190";break;case 0:b="s-layout-990";break;default:b="s-layout-990";break}document.body.className=b}initResponse();
</script>

<div class="header header-other">
    
    <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
                <li><a href="https://www.hbooker.com/index" class='selected'>首页</a></li>
                <li><a href="https://www.hbooker.com/index/rank_index" >排行</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/tongren" >同人</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index/comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index/game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs/zonghe">社区</a></li>
            </ul>
            <div class="ly-fr">
                <form action="" name="myform" id="" target="_blank" class="search-form">
                    <input name="keyword" autocomplete='off' type="text" autocomplete="off" x-webkit-speech="" data-type="1" x-webkit-grammar="builtin:translate" placeholder="搜索更多作品或作者" data-url="https://www.hbooker.com/get-search-book-list/{key}">
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>

</div><div class="login-header">欢乐书客，让阅读更精彩\^o^/</div>

<!--container start-->
<div class="container">
    <div class="ly-wrap">
        <div class="login-box">
            <form action="https://www.hbooker.com/signup/modify_passwd" class="form-box" id="J_ModifyPassForm" method="post">
                <input type="hidden" name="verify_type" id="verify_type" value="2">
                <input type="hidden" name="redirect" id="redirect" value="https://www.hbooker.com/index-zhaiwen">
                <input type="hidden" name="email_or_mobile" id="email_or_mobile" value="mobile">
                <h3>修改密码</h3>
                <div class="type-mobile">
                    <div class="form-group">
                        <input type="text" placeholder="手机号" class="mobile" name="mobile">
                        <div class="wrongBox">
                            <b>*</b>
                            <span class="tip-msg">目前仅支持中国大陆手机号</span>
                        </div>
                    </div>
                </div>
                <div class="type-email" style="display:none">
                    <div class="form-group">
                        <input type="text" placeholder="邮箱" class="email" name="email">
                        <div class="wrongBox">
                            <b>*</b>
                            <span class="tip-msg">请使用常用邮箱</span>
                        </div>
                    </div>
                </div>
										<div>
						<div id="embed-geetest-captcha"></div>
						<script src="https://www.hbooker.com/resources/js/gt.js"></script>
						<script>
							var handlerEmbed = function (captchaObj) {
								captchaObj.appendTo("#embed-geetest-captcha");
								window.geetestCaptchaObj = captchaObj;
							};
							$.ajax({
								// 获取id，challenge，success（是否启用failback）
								url: "https://www.hbooker.com/signup/geetest_captcha?t=" + (new Date()).getTime(), // 加随机数防止缓存
								type: "get",
								dataType: "json",
								success: function (data) {
									// 使用initGeetest接口
									// 参数1：配置参数
									// 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
									initGeetest({
										gt: data.gt,
										challenge: data.challenge,
										product: "popup", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
										offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
										// 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
									}, handlerEmbed);
								}
							});
						</script>
					                  
                </div>
                <div class="type-mobile">
                    <div class="form-group">
                        <input type="text" placeholder="短信验证" class="receive-code receive-code-mobile" maxlength="4" name="receive-code-mobile"><a href="javascript:;" class="btn-receive-code" id="J_GetMobileReceiveCode"><span>获取短信验证码</span><b class="J_Timer" style="display:none"><i>60</i>秒</b></a>
                        <div class="wrongBox">
                            <b>*</b>
                            <span class="tip-msg">请输入手机收到的4位验证码</span>
                        </div>
                    </div>
                </div>
                <div class="type-email" style="display:none">
                    <div id="" class="form-group">
                        <input type="text" placeholder="邮箱验证" class="receive-code receive-code-email" maxlength="4" name="receive-code-email"><a href="javascript:;" class="btn-receive-code" id="J_GetEmailReceiveCode"><span>获取邮箱验证码</span><b class="J_Timer" style="display:none"><i>60</i>秒</b></a>
                        <div class="wrongBox">
                            <b>*</b>
                            <span class="tip-msg">请输入邮箱收到的4位验证码</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <input type="password" placeholder="设置密码" class="password" maxlength="16" name="password">
                    <div class="wrongBox">
                        <b>*</b>
                        <span class="tip-msg">密码长度为6~16位，只能由a-z不限大小写英文字母或0-9的数字组成！</span>
                    </div>
                </div>
                <div class="form-group">
                    <input type="password" placeholder="请再次输入密码" class="password-confirm" maxlength="16" name="password-confirm">
                    <div class="wrongBox">
                        <b>*</b>
                        <span class="tip-msg">请在此输入相同的密码</span>
                    </div>
                </div>
                <div class="form-btn">
                    <input type="hidden" name="type" value="mobile">
                    <button type="submit" id="geetest-submit">修改密码</button>
                </div>
                <div class="form-ft clearfix">
                        <!--<span class="tl ly-fl" style="width:auto">
                            <label><input checked type="checkbox">我已阅读并同意</label><a href="javascript:;">《用户服务协议》</a>
                        </span>-->
                        <span class="ly-fr tr" style="float: right;">
                            <a class="reg-login" href="https://www.hbooker.com/signup/login">直接登录 &gt;</a>
                        </span>
                </div>
            </form>
            <div class="login-ft">
                <div class="otherUser">
                    <div class="otherUser_T">
                        <a class="J_ChangeRegType type-mobile" href="javascript:;" data-type="email">用邮箱修改密码</a>
                        <a class="J_ChangeRegType type-email" style="display:none" href="javascript:;" data-type="mobile">用手机修改密码</a>
                        <b></b>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--container end-->

<script type="text/javascript" src='https://www.hbooker.com/resources/js/jquery-plugins/jquery.validate/jquery.validate.min.js'></script>
<script type="text/javascript" src='https://www.hbooker.com/resources/js/form.js'></script>
<script type="text/javascript">
    var errorStr = "";
    if(errorStr!="")
        HB.util.alert(errorStr);
</script>
<div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="https://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
<!--             <li>
                <dl>
                    <dt>安全认证</dt>
                    <dd><a logo_size="83x30" logo_type="realname" href="http://www.anquan.org" ><script src="http://static.anquan.org/static/outer/js/aq_auth.js"></script></a></dd>
                </dl>
            </li> -->
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
</body>
</html>