
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>阅读社区</title>


    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/style.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/response.css')); ?>"/>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('bootstrap/jquery.js')); ?>"></script>

  
        <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
        HB.book = {book_id: "", chapter_id: "", up_reader_id: "", is_paid: 0};
        HB.userinfo = {reader_id: 0,tel_num: '',license: '',redis_license: '', reader_name: '""', avatar_thumb_url: '""', vip_lv: ""};
        HB.urlinfo ={redirect:'https://www.hbooker.com/reader/modify_mobile?redirect=https%3A%2F%2Fwww.hbooker.com%2F'};        
    </script>
    <script type="text/javascript" src="<?php echo e(asset('home/js/initResponse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('home/js/base.js')); ?>"></script>
    <!--<script type="text/javascript" src="<?php echo e(asset('home/js/dialog-min.js')); ?>"></script>-->

    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

</head>
<body>

 

<!--container start-->
<div class="container">
    <div class="ly-wrap">

        <div class="breakcrumb">
            <a href="<?php echo e(url('/')); ?>">首页</a> &gt;
            <a href="<?php echo e(url('forum')); ?>">论坛</a> &gt;
          
            发帖
        </div>

        <div class="mod-box ly-mt30">
            <div class="mod-tit1">
                <h3><i></i>综合讨论区发帖</h3>
            </div>
            <div class="mod-bd">
                <div class="bbs-form">
                    <form id="bbs_add_form"  action ="<?php echo e(url('forum')); ?>"  method="post">
                         <?php echo e(csrf_field()); ?>

                       
                        <div class="form-group">
                        	                            <input type="text" id="bbs_title" name="title" placeholder="请输入标题" class="input-large bbs-title" maxlength="30">
                                                        <span class="input-group-addon">0/30</span>
                        </div>
                        <div class="form-group">
                            <textarea name="content" id="editor" cols="30" rows="10" style="height: 470px;"></textarea>
                            
                        </div>
                        <div class="form-group action" style="text-align: right">
                            <span class="J_TopicWordsCount">0</span>/<span class="J_TopicWordsCountLimit">1000</span>
                          
                            <button type="submit" onclick='return fabiao()' id="add_bbs_submit" type="button" class="ly-ml10">发表</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->






<div class="footer">
    <div class="ly-wrap">
     
     
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
      
     <script>
         
         function fabiao(){
             if( !$("#bbs_title").value()){
                 
                 alert(1);
                 return true;
                 
                 
             }else{
                  alert(2);
                 $("#bbs_title").foucs();
                 return false;
             }
           
             
         }
function nav(obj){
    
   $(obj).siblings().children(":first").removeClass('selected');
   $(obj).children(":first").addClass('selected');
}
</script>
 
      
</body>
</html>