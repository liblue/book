<?php $__env->startSection('nav'); ?>
   <li><a href="/" class='selected'>我的信息</a></li>
               
                <li><a href="<?php echo e(url('author')); ?>" >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container"  style="height: 1000px">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="<?php echo e(url('myself')); ?>" >我的书架</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_reader_review_list">我的书评</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="https://www.hbooker.com/recharge/get_reader_wallet">钱包君</a></li>
                    <li><a href="<?php echo e(url('my_info')); ?>" class="selected">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
        
     <div class="ly-fl bookshelf">
            <div class="mod-box">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">基本资料</span><!--<span>修改密码</span>--></h3>
					<a class="J_InfoSubmit btn-bg01 btn-operate " href="javascript:;">保存</a>
                </div>
                <div class="comment-list information">
                    <ul>
                        
                        
                        <li class="clearfix">
                            <label>账户名：</label>
                            <div class="info-item" >书客69271084732</div>
                        </li>
                        <li class="clearfix">
                            <label>书龄：</label>
                            <div class="info-item">1年</div>
                        </li>
                        <li class="clearfix">
                            <label>昵称：</label>
                            <div class="support-mod info-item nickname hide">书客69271084732</div>
                            <div class="ly-fl item ">
                                <input type="text" name="newNickname" class="newNickname" placeholder="请输入昵称"/>
                            </div>
                            <div class="wrongBox ">
                                <b>*</b>
                                <span class="tip-msg">不支持非法词汇和特殊符号</span>
                            </div>
                            <!-- <a href="javascript:;" class="modify info-modify h40" id="J_ModifyNickname"><i class="icon icon-modify"></i>修改</a>
                            <a href="javascript:;" class="confirm info-confirm h40 hide" id="J_ConfirmNickname"><i class="icon icon-confirm"></i>确认</a> -->
                        </li>
                        <li class="clearfix">
                            <label>性别：</label>
                          
                            <div class="info-item input-radio J_InputRadio selectSex ">
                                <select name="sex" id="sex">
                                    <option value="1">男</option>
                                    <option value="2">女</option>
                                </select>
                            </div>
                            <!-- <a href="javascript:;" class="modify info-modify h40" id="J_ModifySex"><i class="icon icon-modify"></i>修改</a>
                            <a href="javascript:;" class="confirm info-confirm h40 hide" id="J_ConfirmSex"><i class="icon icon-confirm"></i>确认</a> -->
                        </li>
                        <li class="clearfix">
                            <label>邮箱：</label>
                            <div class="info-item">1252388940@qq.com</div>
                        </li>
                        <li class="clearfix">
                            <label>手机号：</label>
                            <div class="support-mod info-item"></div>
                                    <!--<a href="javascript:">[更换手机号]</a>-->
                            <!--<a href="" class="modify info-modify h40"><i class="icon icon-modify"></i>更换</a>-->
                            <a href="javascript:;" class="J_BindMobile btn-blue btn-modify" data-value="http://www.hbooker.com/reader/modify_mobile?redirect=http%3A%2F%2Fwww.hbooker.com%2Freader%2Fmy_info">换绑</a>
								<div class="wrongBox ">
									<b>*</b><span class="tip-msg">请绑定中国内地手机号码，如无手机号，请进行实名认证</span>
								</div>
                        </li>
                   
                        <li class="clearfix">
                            <!--<label>登录密码：</label>
                            <a href="" class="modify info-modify h40"><i class="icon icon-modify"></i>修改</a>-->
                            <label>登录密码：</label> <div class="support-mod info-item nickname hide"></div>
							    <div class="ly-fl item ">
                                <input type="text" name="newNickname" class="newNickname" placeholder="请输入原来的密码"/>
                            </div>
                        </li>
                        <li class="clearfix">
                            <!--<label>登录密码：</label>
                            <a href="" class="modify info-modify h40"><i class="icon icon-modify"></i>修改</a>-->
                            <label>重置密码：</label> <div class="support-mod info-item nickname hide"></div>
							    <div class="ly-fl item ">
                                <input type="text" name="newNickname" class="newNickname" placeholder="请输入新密码"/>
                            </div>
                        </li>
							
                    </ul>
                </div>
            </div>

        </div>


        <!--我的关注,我的粉丝 start-->
       
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>