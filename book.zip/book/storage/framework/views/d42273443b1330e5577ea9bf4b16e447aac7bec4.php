    


<?php $__env->startSection('content'); ?>   
    
    
      


<div class="container">
    <div class="ly-wrap">
      
        <div class="ly-main">
         
            <div class="search-result ly-mt30">有 <span>32884</span> 条符合关键词""的搜索结果</div>
            <div class="charts-box search-list ly-mt30">
                <div class="box-list">
                    <ul>
                        
                        
                           <?php foreach($res as $k=>$v): ?>
                                                                                    <li data-book-id="100019390">
                                    <i><?php echo e($k+1); ?></i>
                                    <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" class="img ly-fl"><img src="<?php echo e($v->pic_addr); ?>" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a target="_blank"><!--<s class="search-ky">崩</s>--><?php echo e($v->title); ?></a></p>
                                        <p>小说作者：<a ><?php echo e($v->author); ?></a></p>
                                        <p>日期：<?php echo e(date('Y-m-d h:i:s',$v->date)); ?></p>
                                        <div class="desc"><?php echo e($v->intro); ?></div>
                                    </div>
                                   
                                </li>
                                      <?php endforeach; ?>                   
                                             <?php foreach($res1 as $k=>$v): ?>
                                                                                    <li data-book-id="100019390">
                                    <i><?php echo e($k+1); ?></i>
                                    <a href="<?php echo e(url('content')); ?>?id=<?php echo e($v->id); ?>" class="img ly-fl"><img src="<?php echo e($v->pic_addr); ?>" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a target="_blank"><!--<s class="search-ky">崩</s>--><?php echo e($v->title); ?></a></p>
                                        <p>小说作者：<a ><?php echo e($v->author); ?></a></p>
                                        <p>日期：<?php echo e(date('Y-m-d h:i:s',$v->date)); ?></p>
                                        <div class="desc"><?php echo e($v->intro); ?></div>
                                    </div>
                                   
                                </li>
                                      <?php endforeach; ?>                         
                                                           
                                                           
                                                            
                                                           
                                                                        </ul>
                </div>
            </div>
            <div class="pagination">
                                    <div class="PageIn">
                        <ul>
                            <li class='selected'><a href='javascript:'>1</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/2" data-ci-pagination-page="2">2</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/3" data-ci-pagination-page="3">3</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/2" data-ci-pagination-page="2" rel="next">>></a></li>                            <li class="pageSkip">
                                <span class="ly-fl">跳转到:</span>
                                <input type="text" id="directPageNum" name="directPageNum" class="ly-fl skipBox" value="1">
                                <span class="ly-fl">/<i>33</i>页</span>
                                <a class="ly-fl pageSkipQd" href="javascript:void(0);" onclick="">确认</a>
                            </li>
                            <input type="hidden" value="http://www.hbooker.com/get-search-book-list/3/" name="curr_url" id="curr_url">
                        </ul>
                    </div>
                            </div>
        </div>
  

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->







    
    
       
    <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layout.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>