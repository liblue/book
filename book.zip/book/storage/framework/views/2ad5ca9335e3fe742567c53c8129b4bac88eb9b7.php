<?php $__env->startSection('nav'); ?>
   <li><a href="<?php echo e(url('user')); ?>" >我的信息</a></li>
   <li><a href="<?php echo e(url('author')); ?>" class='selected' >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- <div  style="margin-left:30%;height: 50px">   <button class="layui-btn layui-btn-primary">原始按钮</button>
    <button class="layui-btn">默认按钮</button>
    <button class="layui-btn layui-btn-normal">百搭按钮</button>
    
        </div>-->
<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>

                    <input value="<?php echo e($date); ?>"  type="hidden" id="date">
                   <?php foreach($chapter as $k=>$v): ?>
                
           <?php if($k===0): ?>
        
           <a href="#"  class="selected"  onclick="fun(this)" > <li>   <input type="hidden" value="<?php echo e($count-$k); ?>">章节<?php echo e($count-$k); ?>&nbsp;<?php echo e($v); ?></li></a>
                 <?php else: ?>
          <a href="#"    onclick="fun(this)" > <li>   <input type="hidden" value="<?php echo e($count-$k); ?>">章节<?php echo e($count-$k); ?>&nbsp;<?php echo e($v); ?></li></a>
                 <?php endif; ?>

                   <?php endforeach; ?>
                </ul>
            </div>
            
        </div>
  
        <div class="ly-fl bookshelf" style="width: 80%">
     
          

       <div class="layui-form-item">
      <a  href="<?php echo e(url('author')); ?>"> <button class="layui-btn layui-btn-primary">返回作品管理</button></a>    <a  <a href="<?php echo e(url('author/write/'.$date)); ?>"> <button class="layui-btn">添加章节</button></a>
    <div class="layui-input-block">        
<form class="layui-form" action="<?php echo e(url('author')); ?>" method="post">
    
     <?php echo e(csrf_field()); ?>

  
<!--    //在表单中提交会默认走store方法 所以放在外面（虽然是a链接）
  <div class="layui-form-item">
      <a  href="<?php echo e(url('author')); ?>"> <button class="layui-btn layui-btn-primary">返回作品管理</button></a>
    <div class="layui-input-block">  -->
   
    </div>
  </div>
  <div class="layui-form-item layui-form-text">


      <textarea  class="layui-textarea" name="intro"  style="min-height: 500px"   readonly>
<?php echo e($content); ?>

      </textarea>

<!--  </div>

  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit="" lay-filter="demo1">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>-->
</form>
             
           
        </div>

        <!--我的关注,我的粉丝 start-->
        <div class="ly-side" style="display: none">
            <div class="mod-box fans">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的关注</span></h3>
                </div>
            </div>

            <div class="mod-box fans ly-mt45">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的粉丝</span></h3>
                </div>
            </div>
        </div>
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>

<script>
function fun(obj){
      
   $(obj).siblings().removeClass('selected');
   $(obj).addClass('selected');

   a=$(obj).children().eq(0).children().eq(0).val();//找到a节点的第一个子节点的子节点的值;
   date=$('#date').val();

   $.post("<?php echo e(url('author/change')); ?>",{'_token':'<?php echo e(csrf_token()); ?>','chapter':a,'date':date},function(data){
            if(data.status == 0){

           $('.layui-textarea').val(data.content);
            }
            else{
                alert('no');
            }
    });
  

         
}
</script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>