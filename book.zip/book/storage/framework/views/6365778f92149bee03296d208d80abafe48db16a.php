
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="2554576230602773526375" />
    <meta name="baidu-site-verification" content="81BLZ1C2Te" />
    <!-- 百度验证  -->
    <meta name="baidu-site-verification" content="23p76Y9LU3" />
    <!--360验证-->
    <meta name="360-site-verification" content="1247af3cd890cf522c64a0188211dfba" />
    <!--神马平台验证-->
    <meta name="shenma-site-verification" content="6ddf919e460df88fe12310e2097a23cc_1497866600" />
    <title>欢乐书客官网_贼新贼全的综漫小说阅读网，火影小说，海贼小说，动漫小说，动漫同人</title>
    <meta name="keywords" content="综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <meta name="description" content="欢乐书客提供最新好看的全本二次元穿越，娘化百合，各种萌化后宫小说在线阅读，综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/style.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/response.css')); ?>"/>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('bootstrap/jquery.js')); ?>"></script>
        <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
        HB.book = {book_id: "", chapter_id: "", up_reader_id: "", is_paid: 0};
        HB.userinfo = {reader_id: 0,tel_num: '',license: '',redis_license: '', reader_name: '""', avatar_thumb_url: '""', vip_lv: ""};
        HB.urlinfo ={redirect:'https://www.hbooker.com/reader/modify_mobile?redirect=https%3A%2F%2Fwww.hbooker.com%2F'};        
    </script>
    <script type="text/javascript" src="<?php echo e(asset('home/js/initResponse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('home/js/base.js')); ?>"></script>
    <!--<script type="text/javascript" src="<?php echo e(asset('home/js/dialog-min.js')); ?>"></script>-->

    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>
    <script>
		(function(para) {
		  var p = para.sdk_url, n = para.name, w = window, d = document, s = 'script',x = null,y = null;
		  w['sensorsDataAnalytic201505'] = n;
		  w[n] = w[n] || function(a) {return function() {(w[n]._q = w[n]._q || []).push([a, arguments]);}};
		  var ifs = ['track','quick','register','registerPage','registerOnce','clearAllRegister','trackSignup', 'trackAbtest', 'setProfile','setOnceProfile','appendProfile', 'incrementProfile', 'deleteProfile', 'unsetProfile', 'identify','login','logout','trackLink','clearAllRegister','getAppStatus'];
		  for (var i = 0; i < ifs.length; i++) {
		    w[n][ifs[i]] = w[n].call(null, ifs[i]);
		  }
		  if (!w[n]._t) {
		    x = d.createElement(s), y = d.getElementsByTagName(s)[0];
		    x.async = 1;
		    x.src = p;
		    x.setAttribute('charset','UTF-8');
		    y.parentNode.insertBefore(x, y);
		    w[n].para = para;
		  }
		})({
		  sdk_url: 'https://www.hbooker.com/resources/js/sensorsdata/sensorsdata.min.js',
		  name: 'sa',
		  web_url: 'https://sensorsdata.hbooker.com:4006/?project=production',
		  server_url: 'https://sensorsdata.hbooker.com:4006/sa?project=production',
		  heatmap:{}
		});
		sa.quick('autoTrack');
	</script>
</head>
<body>
    <!--360自动收录JS代码-->
<script>
(function(){
   var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2":"https://jspassport.ssl.qhimg.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2";
   document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>
 <!-- 当前是章节阅读页 -->
 <!-- 当前是漫画阅读页 -->
<div id="bdstat" style="display: none"></div>

<div class="nav-top">
    <div class="ly-wrap">
        <ul class="login-info ly-fl">
                           <!--  <li><a class="wb" href="#" rel="nofollow"></a></li> -->
<!--                <li><a class="qq" href="#" rel="nofollow"></a></li>-->
                <li><a class="qq" href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow"></a></li>
				<!--<li><a class="weixin" href="https://www.hbooker.com/signup/weixin_login" rel="nofollow"></a></li> -->
               <?php if(Session::has('user_name')): ?>
         
             
                    <li class="userinfo">
                    <a class="avatar" href="<?php echo e(url('myself')); ?>" target="_blank" rel="nofollow">
                        <img class="lazyload" data-original="https://www.hbooker.com/resources/images/avatar-default-m.png" src="https://www.hbooker.com/resources/images/avatar-default-m.png" alt="">
                                            </a>
                    <i><a href="<?php echo e(url('myself')); ?>" target="_blank" rel="nofollow"> <?php echo e(Session::get('user_name')); ?>   </a> </i>
                    <a href="<?php echo e(url('logout')); ?>" class="logout" rel="nofollow">[退出]</a>
                    <span>经验等级：LV.1书中过客</span>
                    
                    
                    <span class="count">书架： <i><a href="https://www.hbooker.com/bookshelf/my_book_shelf/" target="_blank" rel="nofollow"><?php echo e(Session::get('user_favorates')); ?></a></i></span>
                    <span class="count msg">消息： <i><a href="https://www.hbooker.com/reader/get_message_list/" target="_blank" rel="nofollow">0</a></i></span>
                </li>         
                
        <?php else: ?>
                 <li><a href="<?php echo e(url('login')); ?>" rel="nofollow">登录</a></li>
                
                
                <li class="line">|</li>
                <li><a href="<?php echo e('register'); ?>" rel="nofollow">注册</a></li>
                
                
           <?php endif; ?>
                    </ul>
           <?php if(Session::has('user_name')): ?>
         
<!--        <div class="nav-top-right ly-fr">
            <ul class="special ly-fl clearfix">
                <li class="recharge"><a href="https://www.hbooker.com/recharge/index"><i></i>充值中心</a></li>
                <li class="line">|</li>
                <li class="author"><a href="<?php echo e(url('au_manage')); ?>" target="_blank"><i></i>作者后台</a></li>
                <li class="line">|</li>
            </ul>
            <a class="app-download ly-fl" href="http://app.hbooker.com" target="_blank"><img src="" alt=""/></a>
            <div class="qr-code ly-fl">
                <a id="J_QrCode" href="javascript:;"><div><p>扫码下载客户端</p></div></a>
            </div>
        </div>-->
           <?php endif; ?>
    </div>
</div>

<!--  欢迎每日登录 领取推荐票 -->
<div class="dialogLoginBox" id="J_DialogLoginBox" style="display: none;">
    <h3 class="title">欢迎每日登录</h3>
    <div class="cnt">
        <p>  你好~~</p>
        <p>送你 <span>
			0		</span> 张推荐票哦~</p>
        <p class="tips">登陆欢乐书客APP，<br/>完成每日签到任务，更有欢乐币相送。</p>
        <p>么么哒~~</p>
    </div>
    <div class="opt">
        <!--        <a class="btn-gettuijian" href="javascript:;" id="J_GetTJTicket">领取推荐票</a>-->
        <p class="auto-close"><i id="J_Timer">3</i>s后关闭</p>
    </div>
</div><div class="header">
    <div class="ly-wrap header-inner">
        <div class="ly-fl">
            <div class="logo">
                <h1><a href="https://www.hbooker.com/index"><img src="https://www.hbooker.com/resources/images/logo.png" alt="logo"></a></h1>
                <div>让阅读更精彩，让写作更简单 \^o^/</div>
            </div>
        </div>
    </div>

    <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
<!--                <li><a href="/" class='selected'>首页</a></li>
                <li><a href="paihang" >排行</a></li>
                <li><a href="https://www.hbooker.com/index-zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index-tongren" >同人</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/male" >男生</a></li>
                <li><a href="https://www.hbooker.com/index-female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index-comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index-game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs" >社区</a></li>-->
                
                <?php echo $__env->yieldContent('nav'); ?>
            </ul>
            <div class="ly-fr">
                <form action="" name="myform" id="" target="_blank" class="search-form" onsubmit="return false">
                    <input name="keyword" autocomplete='off' type="text" x-webkit-speech="" data-type="1" x-webkit-grammar="builtin:translate" placeholder="搜索更多作品或作者" data-url="<?php echo e(url('search_result')); ?>">
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>
    </div><!--container start-->
    
    
    
    
      <?php echo $__env->yieldContent('content'); ?>
    
    
       
    
    





<div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="https://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
<!--             <li>
                <dl>
                    <dt>安全认证</dt>
                    <dd><a logo_size="83x30" logo_type="realname" href="http://www.anquan.org" ><script src="http://static.anquan.org/static/outer/js/aq_auth.js"></script></a></dd>
                </dl>
            </li> -->
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
</body>
</html>