
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="2554576230602773526375" />
    <meta name="baidu-site-verification" content="81BLZ1C2Te" />
    <!-- 百度验证  -->
    <meta name="baidu-site-verification" content="23p76Y9LU3" />
    <!--360验证-->
    <meta name="360-site-verification" content="1247af3cd890cf522c64a0188211dfba" />
    <!--神马平台验证-->
    <meta name="shenma-site-verification" content="6ddf919e460df88fe12310e2097a23cc_1497866600" />
    <title>欢乐书客官网_贼新贼全的综漫小说阅读网，火影小说，海贼小说，动漫小说，动漫同人</title>
    <meta name="keywords" content="综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <meta name="description" content="欢乐书客提供最新好看的全本二次元穿越，娘化百合，各种萌化后宫小说在线阅读，综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">
    <link rel="stylesheet" type="text/css" href="http://localhost/book/public/home/css/style.css"/>
    <link rel="stylesheet" type="text/css" href="http://localhost/book/public/home/css/response.css"/>
    <script type="text/javascript" language="javascript" src="http://localhost/book/public/bootstrap/jquery.js"></script>
        <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
        HB.book = {book_id: "", chapter_id: "", up_reader_id: "", is_paid: 0};
        HB.userinfo = {reader_id: 0,tel_num: '',license: '',redis_license: '', reader_name: '""', avatar_thumb_url: '""', vip_lv: ""};
        HB.urlinfo ={redirect:'https://www.hbooker.com/reader/modify_mobile?redirect=https%3A%2F%2Fwww.hbooker.com%2F'};        
    </script>
    <script type="text/javascript" src="http://localhost/book/public/home/js/initResponse.js"></script>
    <script type="text/javascript" src="http://localhost/book/public/home/js/base.js"></script>
    <!--<script type="text/javascript" src="http://localhost/novel/public/home/js/dialog-min.js"></script>-->

    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>
    <script>
		(function(para) {
		  var p = para.sdk_url, n = para.name, w = window, d = document, s = 'script',x = null,y = null;
		  w['sensorsDataAnalytic201505'] = n;
		  w[n] = w[n] || function(a) {return function() {(w[n]._q = w[n]._q || []).push([a, arguments]);}};
		  var ifs = ['track','quick','register','registerPage','registerOnce','clearAllRegister','trackSignup', 'trackAbtest', 'setProfile','setOnceProfile','appendProfile', 'incrementProfile', 'deleteProfile', 'unsetProfile', 'identify','login','logout','trackLink','clearAllRegister','getAppStatus'];
		  for (var i = 0; i < ifs.length; i++) {
		    w[n][ifs[i]] = w[n].call(null, ifs[i]);
		  }
		  if (!w[n]._t) {
		    x = d.createElement(s), y = d.getElementsByTagName(s)[0];
		    x.async = 1;
		    x.src = p;
		    x.setAttribute('charset','UTF-8');
		    y.parentNode.insertBefore(x, y);
		    w[n].para = para;
		  }
		})({
		  sdk_url: 'https://www.hbooker.com/resources/js/sensorsdata/sensorsdata.min.js',
		  name: 'sa',
		  web_url: 'https://sensorsdata.hbooker.com:4006/?project=production',
		  server_url: 'https://sensorsdata.hbooker.com:4006/sa?project=production',
		  heatmap:{}
		});
		sa.quick('autoTrack');
	</script>
</head>
<body>
    <!--360自动收录JS代码-->
<script>
(function(){
   var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2":"https://jspassport.ssl.qhimg.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2";
   document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>
 <!-- 当前是章节阅读页 -->
 <!-- 当前是漫画阅读页 -->
<div id="bdstat" style="display: none"></div>

<div class="nav-top">
    <div class="ly-wrap">
        <ul class="login-info ly-fl">
                           <!--  <li><a class="wb" href="#" rel="nofollow"></a></li> -->
<!--                <li><a class="qq" href="#" rel="nofollow"></a></li>-->
                <li><a class="qq" href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow"></a></li>
				<!--<li><a class="weixin" href="https://www.hbooker.com/signup/weixin_login" rel="nofollow"></a></li> -->
                <li><a href="http://localhost/novel/public/login" rel="nofollow">登录</a></li>
                <li class="line">|</li>
                <li><a href="register" rel="nofollow">注册</a></li>
                    </ul>
        <div class="nav-top-right ly-fr">
            <ul class="special ly-fl clearfix">
                <li class="recharge"><a href="https://www.hbooker.com/recharge/index"><i></i>充值中心</a></li>
                <li class="line">|</li>
                <li class="author"><a href="http://author-new.hbooker.com" target="_blank"><i></i>作者后台</a></li>
                <li class="line">|</li>
            </ul>
            <a class="app-download ly-fl" href="http://app.hbooker.com" target="_blank"><img src="" alt=""/></a>
            <div class="qr-code ly-fl">
                <a id="J_QrCode" href="javascript:;"><div><p>扫码下载客户端</p></div></a>
            </div>
        </div>
    </div>
</div>

<!--  欢迎每日登录 领取推荐票 -->
<div class="dialogLoginBox" id="J_DialogLoginBox" style="display: none;">
    <h3 class="title">欢迎每日登录</h3>
    <div class="cnt">
        <p>  你好~~</p>
        <p>送你 <span>
			0		</span> 张推荐票哦~</p>
        <p class="tips">登陆欢乐书客APP，<br/>完成每日签到任务，更有欢乐币相送。</p>
        <p>么么哒~~</p>
    </div>
    <div class="opt">
        <!--        <a class="btn-gettuijian" href="javascript:;" id="J_GetTJTicket">领取推荐票</a>-->
        <p class="auto-close"><i id="J_Timer">3</i>s后关闭</p>
    </div>
</div><div class="header">
    <div class="ly-wrap header-inner">
        <div class="ly-fl">
            <div class="logo">
                <h1><a href="https://www.hbooker.com/index"><img src="https://www.hbooker.com/resources/images/logo.png" alt="logo"></a></h1>
                <div>让阅读更精彩，让写作更简单 \^o^/</div>
            </div>
        </div>
    </div>

    <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
<!--                <li><a href="/" class='selected'>首页</a></li>
                <li><a href="paihang" >排行</a></li>
                <li><a href="https://www.hbooker.com/index-zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index-tongren" >同人</a></li>
                <li><a href="https://www.hbooker.com/index/header_cate_list/male" >男生</a></li>
                <li><a href="https://www.hbooker.com/index-female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index-comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index-game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs" >社区</a></li>-->
                
                                <li><a href="http://localhost/novel/public" class='selected'>首页</a></li>
                <li><a href="paihang" >排行</a></li>
                <li><a href="https://www.hbooker.com/index-zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index-tongren" >同人</a></li>
                <!--<li><a href="https://www.hbooker.com/index/header_cate_list/male" >男生</a></li>-->
                <li><a href="https://www.hbooker.com/index-female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index-comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index-game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs" >社区</a></li>
            </ul>
            <div class="ly-fr">
                <form action="" name="myform" id="" target="_blank" class="search-form" onsubmit="return false">
                    <input name="keyword" autocomplete='off' type="text" x-webkit-speech="" data-type="1" x-webkit-grammar="builtin:translate" placeholder="搜索更多作品或作者" data-url="http://localhost/novel/public/search_result">
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>
    </div><!--container start-->
    
    
    
    
      


<div class="container">
    <div class="ly-wrap">
        <div class="breakcrumb">
            <a href="http://www.hbooker.com/index">首页</a>  &gt; 搜索
        </div>
        <div class="ly-main">
            <div class="search-form ly-mt30">
                <form name="myform" action="http://www.hbooker.com/get-search-book-list" method="get" onsubmit="get_search_book_list();return false;">
                    <input type="text" name="keyword" id="keyword" autocomplete="off" data-type="0" value="3" placeholder="输入你感兴趣的作者作品" data-url="http://www.hbooker.com/get-search-book-list/{key}"></button>
                </form>
            </div>
            <div class="search-result ly-mt30">有 <span>324</span> 条符合关键词""的搜索结果</div>
            <div class="charts-box search-list ly-mt30">
                <div class="box-list">
                    <ul>
                                                                                    <li data-book-id="100019390">
                                    <i>1</i>
                                    <a href="http://www.hbooker.com/book/100019390" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c160927/27-09-16110331-5717-100019390.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100019390" target="_blank"><!--<s class="search-ky">崩</s>-->塔尔塔罗斯舰队的奇妙冒险</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/113296" target="_blank">奥蕾迦娜00032</a></p>
                                        <p>最近更新：2017-12-13 01:54:28 / 第343章：跳了跳了啊，蓝点集合</p>
                                        <div class="desc">巨大的要塞伫立在虚无的宇宙中，燃烧着橙色火焰的恒星安静的发出光芒照耀着这个星系里的一切，和无数年前一样。采矿驳船移动着笨重的身躯，缓慢的从船坞中行驶出来，跟上早已等候在前面的工业指挥舰后面。“船头指向XI-784号异常信号区，等待旗舰带跳。干完这一批，我们就有资源造战列舰了。”“了解，今天就挖完它吧！”“超载无人机，超载采矿无人机！”“最好是可以啦！”这是个关于某个由坐在电脑前的死宅们组成的军团，穿越到一个迷样未知世界，并不挣扎但仍旧求生的故事。</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100019390" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100052541">
                                    <i>2</i>
                                    <a href="http://www.hbooker.com/book/100052541" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17171854-80747.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100052541" target="_blank"><!--<s class="search-ky">崩</s>-->我与崩3女武神们的日常</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/2375896" target="_blank">老年人十六</a></p>
                                        <p>最近更新：2017-12-13 00:33:39 / 第八章 适合笨蛋的只有体力活？！</p>
                                        <div class="desc">我叫南翔，是一名观星爱好者兼一名高二学生。在暑假时我去了一座山上观星露营，可是忽然就有一颗陨石掉在我附近。然后我因为好奇而去看了，发现掉下来的是三个少女。她们的名字是：琪亚娜·卡斯兰娜、雷电芽衣和布洛妮娅·扎伊切克。经过一些事情，我跟这三个女孩同居了。但是作为穷学生（房子够大）的我养不起这三个人啊！没办法了，琪亚娜和芽衣你们去打工吧，当然我也要去......所以就诞生了外卖少女琪亚娜，超市员工芽衣以及无法打工的初中生布洛妮娅......“听好了，你们现在是普通人，所以暂时忘掉你们女武神的身份吧！”女武神转职正常人日常生活喜剧，开幕！</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100052541" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100050840">
                                    <i>3</i>
                                    <a href="http://www.hbooker.com/book/100050840" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171126/26-11-17175530-54022-100050840.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100050840" target="_blank"><!--<s class="search-ky">崩</s>-->琪亚娜·K·阿波卡利斯</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/49836" target="_blank">K423</a></p>
                                        <p>最近更新：2017-12-13 00:06:58 / 第二十一章 火锅</p>
                                        <div class="desc">为世上所有美好而战；我是琪亚娜，琪亚娜·卡斯兰娜！</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100050840" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100052314">
                                    <i>4</i>
                                    <a href="http://www.hbooker.com/book/100052314" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/images/default.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100052314" target="_blank"><!--<s class="search-ky">崩</s>-->帝国指挥官=k423？</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/441280" target="_blank">月下欢宴</a></p>
                                        <p>最近更新：2017-12-12 23:22:22 / 第二章 告白</p>
                                        <div class="desc">一个二穿的少女混在崩坏学园的故事。“果然，目标是完成老爸遗愿！”“喂喂，你老爸我还没死啊！”“╮（﹀＿﹀）╭身体都烂了还说什么没死！”卡斯兰那家的人无论付出什么代价，都要守护住自己最爱的人。---------琪亚娜.卡斯兰那</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100052314" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100030864">
                                    <i>5</i>
                                    <a href="http://www.hbooker.com/book/100030864" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170512/12-05-17151224-44907-100030864.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100030864" target="_blank"><!--<s class="search-ky">崩</s>-->伪娘之二次元萌妹</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/1593178" target="_blank">梦幻3</a></p>
                                        <p>最近更新：2017-12-12 23:10:01 / 第26章梦幻333.1</p>
                                        <div class="desc">这是一只伪娘与众多二次元萌妹的欢乐搞笑日常的故事……ps1:本书慢热型，有一点变百剧情，大概不到三十章，届时大家不喜请跳过。Ps2:群号:636990229，答案:伪娘百合大法好。</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100030864" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100053964">
                                    <i>6</i>
                                    <a href="http://www.hbooker.com/book/100053964" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/images/default.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100053964" target="_blank"><!--<s class="search-ky">崩</s>-->红色警戒3自由之鹰</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/2700537" target="_blank">哈达塔尔·艾克</a></p>
                                        <p>最近更新：2017-12-12 22:21:37 / 第一章：哈瓦那：巨熊陷阱</p>
                                        <div class="desc">苏联被盟军击溃前夕——苏联阿纳托利·查丹科上校和库可夫将军利用时间机器回到过去1927年，使得爱因斯坦消失于时间长河中，历史又一次被大幅改写。失去爱因斯坦后，盟军相对于苏联的科技优势不复存在，因此在和苏联的正面对抗中节节败退。而我们的盟军主人公将面临着前所未有强大的苏联……</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100053964" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100052790">
                                    <i>7</i>
                                    <a href="http://www.hbooker.com/book/100052790" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171205/05-12-17210159-95702.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100052790" target="_blank"><!--<s class="search-ky">崩</s>-->崩坏？300！</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/2186136" target="_blank">田阳花田的花匠</a></p>
                                        <p>最近更新：2017-12-12 22:18:07 / 第八章 笨蛋果然还是笨蛋</p>
                                        <div class="desc">金木怼崩坏兽？天外律者？丸子胡脸？星爆气流斩！！！！九头龙闪！！！！看来要掀起最后的底牌了！！文笔有限，所以请见谅</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100052790" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100050566">
                                    <i>8</i>
                                    <a href="http://www.hbooker.com/book/100050566" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171120/20-11-17192327-13120.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100050566" target="_blank"><!--<s class="search-ky">崩</s>-->前面那位轮回者，请留步！</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/1544261" target="_blank">327</a></p>
                                        <p>最近更新：2017-12-12 22:00:01 / 24.尴尬的贞德，尽情忽悠</p>
                                        <div class="desc">幻想乡被一群轮回者入侵毁灭，同伴们全数被擒获，不怀好意的魔爪正缓缓伸来。生死危难之际，帕秋莉站了出来，准备奋起反抗！————幻想乡已被核平，有事请找帕秋莉。</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100050566" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100053783">
                                    <i>9</i>
                                    <a href="http://www.hbooker.com/book/100053783" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c171210/10-12-17175409-87580-100053783.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100053783" target="_blank"><!--<s class="search-ky">崩</s>-->旅法师与革命</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/2684531" target="_blank">330ml白鹿杯</a></p>
                                        <p>最近更新：2017-12-12 21:40:01 / 第七章 婚约</p>
                                        <div class="desc">本作全名为《旅行中的术法师偶尔闹闹革命》，是一个关于少女/御姐被一枚戒指诓骗着创造魔法，顺便给这个世界闹闹改革的旅行故事。[吼吼吼，总有一天我们会被刻在历史上的，依卡]“是吗，但会被刻在历史上是只有我而已，你会要求人家记住一枚卖相一般的戒指？”[!!!∑(ﾟДﾟノ)ノ诶！][(｀・ω・´)那以后你和别人说话的时候就该有意无意往他脸上闪戒指，顺便偶尔的说我的强大全来自这枚戒指，这样我就会成为指环王了，哈哈哈...]“呵.....”依卡捷琳再一次对这枚不靠谱的戒指绝望了ps：本书作者新人无误。ps：我对自己的设定和剧情很有自信ps：小学生文笔，慎入</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100053783" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                            <li data-book-id="100029840">
                                    <i>10</i>
                                    <a href="http://www.hbooker.com/book/100029840" class="img ly-fl"><img src="http://novel-cdn.kuangxiangit.com/uploads/allimg/c170317/17-03-17223436-39228.jpg" /></a>
                                    <div class="cnt">
                                        <p class="tit"><a href="http://www.hbooker.com/book/100029840" target="_blank"><!--<s class="search-ky">崩</s>-->崩坏学园之我是律者</a></p>
                                        <p>小说作者：<a href="http://www.hbooker.com/reader/1517703" target="_blank">御坂10031号</a></p>
                                        <p>最近更新：2017-12-12 21:01:34 / 第一百二十九章:猜测的游戏主线</p>
                                        <div class="desc">从一个小小的僵尸娘开始，最终会变成如何的样貌呢？ps:剧毒！！作者自己的都被毒死了！</div>
                                    </div>
                                    <div class="ly-fr">
                                        <p><a data-list="1" href="http://www.hbooker.com/book/100029840" target="_blank" class="btn-read ly-btn btn-bg01">点击阅读</a></p>
                                        <p class="ly-mt10">
                                             <a data-list="1" class="ly-btn btn-bg02 J_ShouCang" href="javascript:">收藏</a>                                         </p>
                                        <p class="ly-mt10"><a data-list="1" href="javascript:" class="ly-btn btn-bg02 J_TuiJian">投推荐票</a></p>
                                    </div>
                                </li>
                                                                        </ul>
                </div>
            </div>
            <div class="pagination">
                                    <div class="PageIn">
                        <ul>
                            <li class='selected'><a href='javascript:'>1</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/2" data-ci-pagination-page="2">2</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/3" data-ci-pagination-page="3">3</a></li><li><a href="http://www.hbooker.com/get-search-book-list/3/2" data-ci-pagination-page="2" rel="next">>></a></li>                            <li class="pageSkip">
                                <span class="ly-fl">跳转到:</span>
                                <input type="text" id="directPageNum" name="directPageNum" class="ly-fl skipBox" value="1">
                                <span class="ly-fl">/<i>33</i>页</span>
                                <a class="ly-fl pageSkipQd" href="javascript:void(0);" onclick="">确认</a>
                            </li>
                            <input type="hidden" value="http://www.hbooker.com/get-search-book-list/3/" name="curr_url" id="curr_url">
                        </ul>
                    </div>
                            </div>
        </div>
        <!--<div class="ly-side">
            <div class="recommon-book ly-mt30">
                <ul>
                    <li class="box-shadow">
                        <div class="hd">
                            <span>【同人】</span><a href="#" target="_blank">崩坏的棕漫之旅</a>
                        </div>
                        <div class="bd">
                            <p>小说作者：<a href="#" target="_blank">张晗</a></p>
                            <p>更新时间：2015-02-04 18:00</p>
                            <p>最新章节：第五十二节  雪（一）</p>
                            <div class="cnt clearfix">
                                <a href="#" target="_blank" class="ly-fl img">
                                    <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                </a>
                                <div class="ly-fr">
                                    <p>
                                        武者，锤皮炼骨，飞花摘页皆可武，锤皮炼骨，飞花摘页皆可武者，锤武者，锤皮炼骨，飞花摘页皆可武，锤皮炼骨，飞花摘页皆可武者，锤
                                    </p>
                                    <a href="#" class="btn-read" target="_blank">点击阅读</a>
                                </div>
                            </div>
                        </div>
                        <div class="ft">
                            <ul class="clearfix">
                                <li>
                                    <p class="num">222.5万</p>
                                    <p>点击</p>
                                </li>
                                <li>
                                    <div class="middle">
                                        <p class="num">12005</p>
                                        <p>推荐</p>
                                    </div>
                                </li>
                                <li>
                                    <p class="num">12333</p>
                                    <p>月票</p>
                                </li>
                            </ul>
                            <div class="img-wrap clearfix">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                            </div>
                            <p class="book-count">
                                2555位读者打赏或订阅
                            </p>
                        </div>
                    </li>
                    <li class="box-shadow">
                        <div class="hd">
                            <span>【同人】</span><a href="#" target="_blank">崩坏的棕漫之旅</a>
                        </div>
                        <div class="bd">
                            <p>小说作者：<a href="#" target="_blank">张晗</a></p>
                            <p>更新时间：2015-02-04 18:00</p>
                            <p>最新章节：第五十二节  雪（一）</p>
                            <div class="cnt clearfix">
                                <a href="#" target="_blank" class="ly-fl img">
                                    <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                </a>
                                <div class="ly-fr">
                                    <p>
                                        武者，锤皮炼骨，飞花摘页皆可武，锤皮炼骨，飞花摘页皆可武者，锤武者，锤皮炼骨，飞花摘页皆可武，锤皮炼骨，飞花摘页皆可武者，锤
                                    </p>
                                    <a href="#" class="btn-read" target="_blank">点击阅读</a>
                                </div>
                            </div>
                        </div>
                        <div class="ft">
                            <ul class="clearfix">
                                <li>
                                    <p class="num">222.5万</p>
                                    <p>点击</p>
                                </li>
                                <li>
                                    <div class="middle">
                                        <p class="num">12005</p>
                                        <p>推荐</p>
                                    </div>
                                </li>
                                <li>
                                    <p class="num">12333</p>
                                    <p>月票</p>
                                </li>
                            </ul>
                            <div class="img-wrap clearfix">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                                <img class="lazyload" src="../images/transparent.png" data-original="../images/tmp/cover.jpg" alt="">
                            </div>
                            <p class="book-count">
                                2555位读者打赏或订阅
                            </p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>-->

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->

<!-- 用户操作 -->
<div id="J_TuiJianBox" class="J_GiveGift" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>您的余额:<br>
                <b class="J_HLB">0</b></p>
</div>
<div class="line">
    <p>您的推荐票余量:<br>
        <b class="J_Recommend">0</b></p>
</div>
<div class="line">
    <p>写得太好了，给作者投推荐票:<br>
        <a href="javascript:;" class="no-minus J_noMinus">-</a>
        <input type="text" value="1" class="text-amount J_NumResult" maxlength="10"/>
        <a href="javascript:;" class="no-plus J_noPlus">+</a> </p>
</div>
<div class="form-btn center ly-mt30">
    <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投推荐票</a></p>
    <p class="ly-mt10"><a href="http://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
</div>
</div>
</div>
<div id="J_YuePiaoBox" class="J_GiveGift" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>您的余额:<br>
                <b class="J_HLB">0</b></p>
        </div>
        <div class="line">
            <p>您的月票余量:<br>
                <b class="J_Stock">0</b></p>
        </div>
        <div class="line">
            <p>写得太好了，给作者投月票:<br>
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10"/>
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
            </p>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投月票</a></p>
            <p class="ly-mt10"><a href="http://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>
<div id="J_DingYueBox" style="display:none">
    <div class="account-info">
        <div class="line">
            <p>
                您的余额:<br><b class="J_HLB">0</b>
            </p>
        </div>
        <div class="line">
            <ul class="input-radio J_InputRadio">
                                <li>
                    <a href="javascript:;" class="selected"> <i class="icon-select"></i>全本订阅                        <input type="radio" class="J_NumResult" value="1" style="display:none" checked="checked">
                    </a>
                    <div>需购章节： 章，<br/>
                    	
                   		 应付总额： 欢乐币<br>
                                                            </li>
            </ul>
            <!--新增  复选框 start-->
                        <!--新增  复选框 end-->
            <div class="dy-deac ly-mt10">
                1、全本订阅是订阅目前已更新的全部章节，如期间有免费章节和<br>
                已购买章节，下载时将一并下载。<br>
                2、免费章节及已购买章节不会重复扣费，请放心购买。
            </div>
        </div>
        <div class="form-btn center ly-mt30">
                            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01" disabled="true">无需订阅</a></p>
                        <p class="ly-mt10"><a href="http://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>
<div id="J_DaShangBox" style="display:none">
    <div class="account-type">
        <ol class="input-radio J_InputRadio clearfix">
            <li><a href="javascript:;" class="selected" data-type="shang">打赏</a></li>
            <li><a href="javascript:;" data-type="prop">道具</a></li>
        </ol>
    </div>
    <!-- <div class="account-info account-shang account-shang-planb J_AccountShang">-->
        <div class="account-info account-shang J_AccountShang account-shang-planb">
        <div class="line">
            <p>您的欢乐币余额:<br>
                <b class="J_HLB">0</b></p>
        </div>
        <div class="line line-pd0">
            <ul class="input-radio J_InputRadio clearfix">
                <li>
                    <a href="javascript:;" class="selected" data-prop-type="37"><span></span>
                        <input type="radio" class="J_NumResult" value="100" checked="checked">
                    </a>
                </li>
                <li>
                    <a href="javascript:;" data-prop-type="38"><span></span>
                        <input type="radio" class="J_NumResult" value="588">
                    </a>
                </li>
                <li>
                    <a class="bdright" href="javascript:;" data-prop-type="39"><span></span>
                        <input type="radio" class="J_NumResult" value="1688">
                    </a>
                </li>
                <li>
                    <a class="bgbottom" href="javascript:;" data-prop-type="40"><span></span>
                        <input type="radio" class="J_NumResult" value="5000">
                    </a>
                </li>
                <li>
                    <a class="bgbottom" href="javascript:;" data-prop-type="41"><span></span>
                        <input type="radio" class="J_NumResult" value="10000" style="display:none">
                    </a>
                </li>
                <li>
                    <a class="bgbottom bdright" href="javascript:;" data-prop-type="42"><span></span>
                        <input type="radio" class="J_NumResult" value="100000" style="display:none">
                    </a>
                </li>
            </ul>
        </div>
        <div class="line-amount J_NumCalculate">
                打赏数量：
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10">
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">立即打赏</a></p>
            <p class="ly-mt10"><a href="http://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
    <div class="account-info account-prop J_AccountProp" style="display: none;">
        <div class="line">
            <p>您的欢乐币余额:<br>
                <b class="J_HLB">0</b>
            </p>
        </div>
        <div class="line blade-info">
            <div class="blade ly-fl"></div>
            <h3 class="title">催更刀片</h3>
            <p>想要加快更新速度？试试给作者寄刀片吧！</p>
            <p>单价 <span class="J_BladePrice">100</span> 欢乐币</p>
            <p class="own-blade">拥有 <i class="J_OwnBlade">0</i> 个</p>
            <div class="blade-amount J_BladeAmount">
                <a href="javascript:;" class="no-minus J_noMinus">-</a>
                <input type="text" value="1" class="text-amount J_NumResult" maxlength="10"/>
                <a href="javascript:;" class="no-plus J_noPlus">+</a>
            </div>
        </div>
        <div class="line">
            <p>需购道具：<i class="J_BladeNum">1</i> x 催更刀片</p>
            <p>应付总额：<b class="J_Consume">100</b> 欢乐币</p>
        </div>
        <div class="form-btn center ly-mt30">
            <p><a href="javascript:;" class="J_BoxSubmit ly-btn btn-bg01">投出道具</a></p>
            <p class="ly-mt10"><a href="http://www.hbooker.com/recharge/index" target="_blank" class="ly-btn btn-bg02">充值中心</a></p>
        </div>
    </div>
</div>

<!-- 登录框 -->
<div id="J_LoginBox" class="layout-login" style="display:none">
    <div class="login-box">
        <form action="http://www.hbooker.com/signup/doLoginBox" class="form-box" id="J_LoginForm" name="J_LoginForm" method="post" onsubmit="doLoginBox();return false;">
            <h3>登录</h3>
            <div class="form-group">
                <input type="text" placeholder="手机号/邮箱" class="username" name="username">
                <!--<label id="username-error" class="error" for="username">请填写用户名</label>-->
            </div>
            <div class="form-group">
                <input type="password" placeholder="密码" class="password" name="password">
            </div>
            <div class="form-group code-group">
									<div id="embed-geetest-captcha"></div>
					<p id="geetest-wait">正在加载验证码......</p>
					<p id="geetest-notice">请先拖动验证码到相应位置</p>
					<script>
						HB.util.loadGeetest = function () {
							if (window.geetestCaptchaObj) {
								return;
							}
							var head = document.getElementsByTagName("head")[0];
							var s = document.createElement("script");
							s.src = "http://www.hbooker.com/resources/js/gt.js";
							head.appendChild(s);

							s.onload = s.onreadystatechange = function() {
								if (!this.readyState || 'loaded' === this.readyState || 'complete' === this.readyState) {
									$("#geetest-notice").hide();
									var handlerEmbed = function (captchaObj) {
										$("#dosubmmit").click(function (e) {
											var validate = captchaObj.getValidate();
											if (!validate) {
												$("#geetest-notice").show();
												setTimeout(function () {
													$("#geetest-notice").hide();
												}, 2000);
												e.preventDefault();
											}
										});
										captchaObj.appendTo("#embed-geetest-captcha");
										captchaObj.onReady(function () {
											$("#geetest-wait").hide();
										});
										window.geetestCaptchaObj = captchaObj;
									};
									$.ajax({
										// 获取id，challenge，success（是否启用failback）
										url: "http://www.hbooker.com/signup/geetest_captcha?t=" + (new Date()).getTime(), // 加随机数防止缓存
										type: "get",
										dataType: "json",
										success: function (data) {
											// 使用initGeetest接口
											// 参数1：配置参数
											// 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
											initGeetest({
												gt: data.gt,
												challenge: data.challenge,
												product: "float", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
												offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
												// 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
											}, handlerEmbed);
										}
									});
								}
							};
						};
					</script>
							 </div>
            <div class="form-btn">
                <button type="submit" name="dosubmmit" id="dosubmmit">登录</button>
            </div>
            <div class="form-ft clearfix"> <span class="tl">
		        <label>
                    <input type="checkbox" checked="checked" name="autoLogin" value="1">
                    自动登录</label>
		        </span> <span> <a href="http://www.hbooker.com/signup/register?redirect=http://www.hbooker.com/get-search-book-list/3">注册</a> </span> <span class="tr"> <a class="fpw" href="http://www.hbooker.com/signup/modify_passwd_page?redirect=http://www.hbooker.com/get-search-book-list/3">忘记密码 ></a> </span> </div>
        </form>
        <div class="login-ft">
            <div class="otherUser">
                <div class="otherUser_T"><span>使用其他账号登录</span><b></b></div>
                <div class="otherUser_B">
                    <a href="http://www.hbooker.com/signup/qqlogin?redirect=http%3A%2F%2Fwww.hbooker.com%2Fget-search-book-list%2F3" class="qqLogin"></a>
<!--                    <a href="javascript:;" class="qqLogin"></a>-->
					<!-- <a href="http://www.hbooker.com/signup/weixin_login" class="weixinLogin"></a> -->
                    <a href="javascript:;" class="wbLogin"></a>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src='http://www.hbooker.com/resources/js/jquery-plugins/jquery.validate/jquery.validate.min.js'></script>
<script type="text/javascript" src="http://www.hbooker.com/resources/js/dialog-form.js"></script>
<script type="text/javascript" src="http://www.hbooker.com/resources/js/artDialog/6.0.4/dialog-min.js"></script>
<script type="text/javascript">
    function doLoginBox(){
        var self = $(this);
        var username = $("input[name='username']").val();
        var password = $("input[name='password']").val();
        
        var autoLogin=$("input[name='autoLogin']:checked").val();
		
		var post_data = {};
		if(window.geetestCaptchaObj) {
			var validate = window.geetestCaptchaObj.getValidate();
			if (!validate) {
				$("#geetest-notice").show();
				setTimeout(function () {
					$("#geetest-notice").hide();
				}, 2000);
				return;
			}
			post_data = {username: username, password: password, autoLogin:autoLogin};
			var validateDict = window.geetestCaptchaObj.getValidate();
			for(var key in validateDict) {
				post_data[key] = validateDict[key];
			}
		} else {
			var code = $("input[name='code']").val();
			if(code==''){
				HB.util.alert("请输入验证码!");
				return;
			}
			post_data = {username: username, password: password, code: code,autoLogin:autoLogin};
		}

        var dosubmmit = $("#dosubmmit");
        if(dosubmmit.prop('disabled')) return false;

        $.ajax({
            url: HB.config.rootPath + 'signup/doLoginBox',
            data: post_data,
            beforeSubmit: function() {
                dosubmmit.prop("disabled", true);
            },
            complete: function () {
                dosubmmit.prop("disabled", false);
            },
            success: function (res) {
                if (res.code == 100000) {
                    var msg = res.tip ? res.tip : '登录成功！';
                    HB.util.alert(msg);
                    //$("#J_LoginBox").attr('style','display:none');
                    window.location.reload();
                } else {
                    HB.util.alert(res.tip,1);
                    $("#code").trigger('click');
                }
            }
        });
    }
</script>
<script type="text/javascript">
    function get_search_book_list(){
        var key = $("input[name='keyword']").val();
        key = key.replace(/(^\s*)|(\s*$)/g,"");
        if(key.length!=0)
            window.location.href = "http://www.hbooker.com/get_search_book_list/" + key;
    }
</script>
    
    
       
    
    





<div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="https://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="https://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
<!--             <li>
                <dl>
                    <dt>安全认证</dt>
                    <dd><a logo_size="83x30" logo_type="realname" href="http://www.anquan.org" ><script src="http://static.anquan.org/static/outer/js/aq_auth.js"></script></a></dd>
                </dl>
            </li> -->
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="https://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
</body>
</html>