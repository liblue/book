<?php $__env->startSection('nav'); ?>
   <li><a href="<?php echo e(url('user')); ?>" class='selected'>我的信息</a></li>
               
                <li><a href="<?php echo e(url('author')); ?>"  >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="javascript:" >我的书架</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_reader_review_list">我的书评</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="<?php echo e(url('user/post')); ?>" class="selected">我的帖子</a></li>
                    <li><a href="<?php echo e(url('user/showinfo')); ?>">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
      
        <div class="ly-fl bookshelf" style="width: 80%">
     
            <button class="layui-btn" onclick="fun()">删除</button>

                
                <table class="layui-table">

  <thead>
    <tr>
        <th></th>
       
      <th>标题</th>
     
      <th>发帖时间</th>
      
     
       <th>回复</th>
      <th>管理</th>
     
    </tr> 
  </thead>
  <tbody>
      
      <?php foreach($data as $k=>$v): ?>
    <tr>
        <td  align="left"> 
            <input type="checkbox" class="subSelect" name="choice" value="<?php echo e($v->id); ?>"></td>
       <input type="hidden" value="<?php echo e($v->id); ?>" name="date" >
            
       <td><?php echo e($v->title); ?></td>
      <td><?php echo e(date("Y-m-d",$v->date)); ?></td>
     
     
        <td><?php echo e($v->favorate); ?></td>
      <td>   
          <a  href="<?php echo e(url('item')); ?>?date=<?php echo e($v->date); ?>"> <button class="layui-btn layui-btn-primary">详情</button> </a>
          <a   onclick="del('<?php echo e($v->id); ?>')"><button class="layui-btn layui-btn-primary">删除</button></a></td>
    </tr>
       <?php endforeach; ?>
  </tbody>
     
</table>
             
       
        </div>

        <!--我的关注,我的粉丝 start-->
       
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>

<script>

  
  function del(date){
  
   $.post("<?php echo e(url('user/postdelete')); ?>",{'_token':'<?php echo e(csrf_token()); ?>','id':date},function(data){
            if(data.status === 0){

            location.reload(true);
            }
            else{
                alert('no');
            }
    });
  
  
    }
  

   
    function fun(){
    
      $('input:checkbox[name=choice]:checked').each(function(i){
        date = $(this).val();
//        alert(date);
         $.post("<?php echo e(url('user/postdelete')); ?>",{'_token':'<?php echo e(csrf_token()); ?>','id':date},function(data){
            if(data.status === 0){
//                alert(data.msg);
            location.reload(true);
            }
            else{
                alert('no');
            }
    });
      });
      
       //location.href = location.href;
    }
    </script>

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>