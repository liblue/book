<?php $__env->startSection('nav'); ?>
   <li><a href="<?php echo e(url('myself')); ?>" >我的信息</a></li>
               
                <li><a href="/" class='selected' >我是作者</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="height: 700px;">
    <div class="ly-wrap">
        <div class="ly-fl charts-box">
            <div class="ly-fl charts-nav">
                <ul>
                    <li><a href="<?php echo e(url('author')); ?>" class="selected">我的作品</a></li>
                    <li><a href="<?php echo e(url('au_add')); ?>" >新建作品</a></li>
                    <li><a href="https://www.hbooker.com/reader/get_message_list">我的消息</a></li>
                    <li><a href="<?php echo e(url('au_purse')); ?>">我的收入</a></li>
                    <li><a href="https://www.hbooker.com/reader/my_info">基本资料</a></li>
                   
                </ul>
            </div>
            
        </div>
        
        <div class="ly-fl bookshelf" style="width: 80%">
     
          

                
                          

<form class="layui-form" action="">
  <div class="layui-form-item">
    <label class="layui-form-label">章节名</label>
    <div class="layui-input-block">
      <input type="text" name="title" lay-verify="title" autocomplete="off" placeholder="请输入" class="layui-input">
    </div>
  </div>
  
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">内容</label>
    <div class="layui-input-block"  >
        <textarea placeholder="请输入内容" class="layui-textarea"  style="min-height: 200px"></textarea>
    </div>
  </div>
<div class="layui-form-item layui-form-text">
    <label class="layui-form-label">备注</label>
    <div class="layui-input-block"  >
        <textarea placeholder="说点什么吧" class="layui-textarea"  style="min-height: 100px"></textarea>
    </div>
  </div>


  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit="" lay-filter="demo1">立即发布
      </button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
  
</form>
             
           
        </div>

        <!--我的关注,我的粉丝 start-->
        <div class="ly-side" style="display: none">
            <div class="mod-box fans">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的关注</span></h3>
                </div>
            </div>

            <div class="mod-box fans ly-mt45">
                <div class="mod-tit1">
                    <h3><i></i><span class="selected">我的粉丝</span></h3>
                </div>
            </div>
        </div>
        <!--我的关注,我的粉丝 end-->

    </div>

  
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>